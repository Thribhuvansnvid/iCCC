import { Injectable } from '@angular/core'
import {
  HttpInterceptor,
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpResponse,
} from '@angular/common/http'
import { take, exhaustMap, tap, finalize } from 'rxjs/operators'
import { AuthService } from './login/services/auth.service'
import { Observable } from 'rxjs'

@Injectable()
export class AppInterceptorService implements HttpInterceptor {
  constructor(private authService: AuthService) {}

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    let modifiedReq: any
    const startTime = Date.now()
    let status: string

    return this.authService.user.pipe(
      take(1),
      exhaustMap((user) => {
        if (!user) {
          return next.handle(req)
        }

        // if (req.url.includes('api.belsmartcity.in/api')) {
        if (req.url.includes('/api/smartcity')) {
          modifiedReq = req.clone({
            setHeaders: { Authorization: `${user.token}` },
          })
        } else {
          modifiedReq = req.clone()
        }

        // return next.handle(modifiedReq);

        return next.handle(modifiedReq).pipe(
          tap(
            (event) => {
              status = ''
              if (event instanceof HttpResponse) {
                status = 'succeeded'
              }
            },
            (error) => (status = 'failed')
          ),
          finalize(() => {
            const elapsedTime = Date.now() - startTime

            const message =
              'interceptor log-----> ' +
              req.method +
              ' ' +
              req.urlWithParams +
              ' ' +
              status +
              ' in ' +
              elapsedTime +
              'ms'

            if (modifiedReq.url.includes('http')) {
              this.logDetails(message)
            }
          })
        )
      })
    )
  }

  // intercept1(req: HttpRequest<any>, next: HttpHandler) {
  //   const startTime = Date.now();
  //   let status: string;

  //   return next.handle(req).pipe(
  //       tap(
  //         event => {
  //           status = '';
  //           if (event instanceof HttpResponse) {
  //             status = 'succeeded';
  //           }
  //         },
  //         error => status = 'failed'
  //       ),
  //       finalize(() => {
  //         const elapsedTime = Date.now() - startTime;
  //         const message = req.method + " " + req.urlWithParams +" "+ status
  //         + " in " + elapsedTime + "ms";

  //         this.logDetails(message);
  //       })
  //   );
  // }

  private logDetails(msg: string) {
    console.log(msg)
  }
}
