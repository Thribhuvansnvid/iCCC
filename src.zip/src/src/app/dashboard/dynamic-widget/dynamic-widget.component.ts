import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  OnInit,
  Renderer,
  ViewEncapsulation,
} from "@angular/core";

import {
  CompactType,
  DisplayGrid,
  GridsterConfig,
  GridsterItem,
  GridType,
} from "angular-gridster2";
import { AnyAaaaRecord } from "dns";
import { ToastrService } from "ngx-toastr";
import { LoadingScreenService } from "../../login/services/loadingscreen";
import { MatDialog } from "@angular/material";
import { NewDashboardNameDialogComponent } from "../dialogs/new-dashboard-name/new-dashboard-name.dialog.component";
import { DashboardService } from "../services/dashboard.services";
import { stringify } from "@angular/compiler/src/util";
import { Subscription } from "rxjs";
import { Store } from "@ngrx/store";
import * as fromApp from "../../store/app.reducer";
import { User } from "src/app/login/models/user.model";

@Component({
  selector: "app-dynamic-widget",
  templateUrl: "./dynamic-widget.component.html",
  styleUrls: ["./dynamic-widget.component.scss"],
  // changeDetection: ChangeDetectionStrategy.OnPush,
  // encapsulation: ViewEncapsulation.None,
})
export class DynamicWidgetComponent implements OnInit {
  options: GridsterConfig;

  dashboard: Array<GridsterItem> = [];
  // public classReference = DynamicWidgetComponent;
  dashboardSelected: string = "Default Dashboard";
  WidgetType: any;
  userRole: string = "";
  widgetsSelection: any[] = [];

  loadingWidgets: boolean = false;
  errorWhileFetchingWidgets = false;
  // userId = "civilian";
  loggedInUser: User = null;
  savedDashboardList = [];
  defaultDashboard = "";
  components: any = [];
  verticalNames: any[] = [];

  subs: Subscription[] = [];

  subscription1: Subscription = null;
  subscription2: Subscription = null;
  subscription3: Subscription = null;
  subscription4: Subscription = null;
  subscription5: Subscription = null;

  isMenuOpened = false;
  constructor(
    private toastr: ToastrService,
    public dialog: MatDialog,
    private _dashboardService: DashboardService,
    private store: Store<fromApp.AppState>
  ) {
    this.getOptions();
    console.log(`dynamic widget component`);
  }

  // public components = [
  //   //0
  //   {
  //     vertical: "ENV",
  //     icon: "env",
  //     widgets: [
  //       {
  //         attributes: {
  //           id: "envSensorsCount",
  //           name: "Env Sensors Count",
  //           cols: 2,
  //           rows: 1,
  //           y: 3,
  //           x: 11,
  //           minItemRows: 1,
  //           minItemCols: 2,
  //           widget: "smartEnvSensorsAndAqis",
  //           component: "EnvSensorsAndTopAqisComponent",
  //           displaying: false,
  //         },
  //       },

  //       {
  //         attributes: {
  //           id: "envCurrentData",
  //           name: "Env Current Data",
  //           cols: 3,
  //           rows: 3,
  //           y: 0,
  //           x: 10,
  //           minItemRows: 3,
  //           minItemCols: 3,
  //           widget: "EnvCurrentDataComponent",
  //           component: "EnvCurrentDataComponent",
  //           displaying: false,
  //         },
  //       },

  //       {
  //         attributes: {
  //           id: "envTopAqisComponent",
  //           name: "Top Aqis",
  //           cols: 3,
  //           rows: 2,
  //           y: 3,
  //           x: 8,
  //           minItemRows: 2,
  //           minItemCols: 3,
  //           widget: "EnvTopAqisComponent",
  //           component: "EnvTopAqisComponent",
  //           displaying: false,
  //         },
  //       },
  //     ],
  //   },
  //   //1
  //   {
  //     vertical: "STREET LIGHTS",
  //     icon: "streetlight",
  //     widgets: [
  //       {
  //         attributes: {
  //           id: "streetlights",
  //           name: "Street Lights Status",
  //           cols: 4,
  //           rows: 3,
  //           y: 0,
  //           x: 0,
  //           minItemRows: 1,
  //           minItemCols: 3,
  //           widget: "smartlighting",
  //           component: "KpiStreelightsStatusComponent",
  //           displaying: false,
  //         },
  //       },
  //     ],
  //   },
  //   //2
  //   {
  //     vertical: "PARKING",
  //     icon: "parking",
  //     widgets: [
  //       {
  //         attributes: {
  //           id: "parking",
  //           name: "Parking",
  //           cols: 3,
  //           rows: 1,
  //           y: 0,
  //           x: 0,
  //           minItemRows: 1,
  //           minItemCols: 3,
  //           widget: "smartparking",
  //           component: "SmartParkingSummaryComponent",
  //           displaying: false,
  //         },
  //       },
  //     ],
  //   },
  //   //3
  //   {
  //     vertical: "TRANSPORT",
  //     icon: "transport",
  //     widgets: [
  //       {
  //         attributes: {
  //           id: "transportDetails",
  //           name: "Transport Details",
  //           cols: 3,
  //           rows: 1,
  //           y: 1,
  //           x: 7,
  //           minItemRows: 1,
  //           minItemCols: 3,
  //           widget: "smarttransport",
  //           component: "SmartTransportSummaryComponent",
  //           displaying: false,
  //         },
  //       },
  //     ],
  //   },
  //   //4
  //   {
  //     vertical: "SWM",
  //     icon: "bin",
  //     widgets: [
  //       {
  //         attributes: {
  //           id: "binStatus",
  //           name: "Bin Status",
  //           cols: 3,
  //           rows: 3,
  //           y: 0,
  //           x: 0,
  //           minItemRows: 3,
  //           minItemCols: 3,
  //           widget: "smartbin",
  //           component: "SmartBinSummaryComponent",
  //           displaying: false,
  //         },
  //       },

  //       {
  //         attributes: {
  //           id: "garbageCollection",
  //           name: "Garbage Collection Status",
  //           cols: 4,
  //           rows: 2,
  //           y: 3,
  //           x: 4,
  //           minItemRows: 2,
  //           minItemCols: 4,
  //           widget: "SwmWasteCollection",
  //           component: "SwmKpiGarbageCollectionComponent",
  //           displaying: false,
  //         },
  //       },
  //     ],
  //   },
  //   //5
  //   {
  //     vertical: "WATER",
  //     icon: "water",
  //     widgets: [
  //       {
  //         attributes: {
  //           id: "water",
  //           name: "Water",
  //           cols: 4,
  //           rows: 2,
  //           y: 0,
  //           x: 0,
  //           minItemRows: 2,
  //           minItemCols: 4,
  //           widget: "smartwater",
  //           component: "SmartwatersummaryComponent",
  //           displaying: false,
  //         },
  //       },
  //     ],
  //   },
  //   //6
  //   {
  //     vertical: "ENERGY",
  //     icon: "energy",
  //     widgets: [
  //       {
  //         attributes: {
  //           id: "energy",
  //           name: "Energy",
  //           cols: 4,
  //           rows: 2,
  //           y: 0,
  //           x: 0,
  //           minItemRows: 2,
  //           minItemCols: 4,
  //           widget: "smartenergy",
  //           component: "SmartenergysummaryComponent",
  //           displaying: false,
  //         },
  //       },
  //     ],
  //   },
  //   //7
  //   {
  //     vertical: "VMD",
  //     icon: "vmd",
  //     widgets: [
  //       {
  //         attributes: {
  //           id: "vmd",
  //           name: "VMD",
  //           cols: 4,
  //           rows: 2,
  //           y: 0,
  //           x: 0,
  //           minItemRows: 2,
  //           minItemCols: 4,
  //           widget: "vmd",
  //           component: "VmdsummaryComponent",
  //           displaying: false,
  //         },
  //       },
  //     ],
  //   },
  //   //8
  //   {
  //     vertical: "VMS",
  //     icon: "cctv",
  //     widgets: [
  //       {
  //         attributes: {
  //           id: "cameraStatus",
  //           name: "Camera Status",
  //           cols: 3,
  //           rows: 1,
  //           y: 0,
  //           x: 7,
  //           minItemRows: 1,
  //           minItemCols: 3,
  //           widget: "vmsva",
  //           component: "SummaryVaVmsComponent",
  //           displaying: false,
  //         },
  //       },
  //     ],
  //   },
  //   //9
  //   {
  //     vertical: "ATCS",
  //     icon: "atcs",
  //     widgets: [
  //       {
  //         attributes: {
  //           id: "junctionStatus",
  //           name: "Junction Status",
  //           cols: 3,
  //           rows: 1,
  //           y: 2,
  //           x: 7,
  //           minItemRows: 1,
  //           minItemCols: 3,
  //           widget: "atcs",
  //           component: "AtcssummaryComponent",
  //           displaying: false,
  //         },
  //       },

  //       {
  //         attributes: {
  //           id: "powerSource",
  //           name: "Power Source",
  //           cols: 4,
  //           rows: 3,
  //           y: 2,
  //           x: 3,
  //           minItemRows: 3,
  //           minItemCols: 4,
  //           widget: "atcspowersource",
  //           component: "AtcsKpiPowerSourceChartComponent",
  //           displaying: false,
  //         },
  //       },

  //       {
  //         attributes: {
  //           id: "modeOfOperation",
  //           name: "Mode Of Operation",
  //           cols: 4,
  //           rows: 3,
  //           y: 0,
  //           x: 3,
  //           minItemRows: 3,
  //           minItemCols: 4,
  //           widget: "atcsmodeofoperation",
  //           component: "AtcsKpiModeOfOperationChartComponent",
  //           displaying: false,
  //         },
  //       },
  //     ],
  //   },
  //   //10
  //   {
  //     vertical: "ITMS",
  //     icon: "itms",
  //     widgets: [
  //       {
  //         attributes: {
  //           id: "itmsStatus",
  //           name: "ITMS Status",
  //           cols: 4,
  //           rows: 3,
  //           y: 3,
  //           x: 0,
  //           minItemRows: 3,
  //           minItemCols: 4,
  //           widget: "itms",
  //           component: "ItmsViolationsStatsComponent",
  //           displaying: false,
  //         },
  //       },
  //     ],
  //   },
  // ];

  ngOnInit() {
    this.store.select("auth").subscribe(({ user }) => {
      this.loggedInUser = user;
      if(user){
        this.getComponentWidgets();
      }
    });
  }

  getComponentWidgets() {
    this.subscription5 = this._dashboardService.getComponentWidgets().subscribe(
      (res: any) => {
        this.components = res.components;
        this.verticalNames = res.verticals;

        this.fetchDashboardList();
      },
      (err) => {
        console.log(err);
      }
    );
  }
  ngOnDestroy(): void {
    this.subscription1 && this.subscription1.unsubscribe();
    this.subscription2 && this.subscription2.unsubscribe();
    this.subscription3 && this.subscription3.unsubscribe();
    this.subscription4 && this.subscription4.unsubscribe();
    this.subscription5 && this.subscription5.unsubscribe();
    // this.subs.map((s) => s.unsubscribe)
  }

  fetchDashboardDetails(dashboardName: string) {
    this.loadingWidgets = true;
    this.errorWhileFetchingWidgets = false;
    this.dashboardSelected = dashboardName;

    if (dashboardName === "policy" || dashboardName === '') {
      // const params = {
      //   state_name: "Karnataka",
      //   district_city: "Belagavi",
      //   policy_type: "KPI_DISPLAY",
      //   // smart_vertical: "All",
      //   user_role: "ADMIN",
      //   apply_criteria: true,
      // };

      const params = {
        stateName: this.loggedInUser.state,
        districtCity: this.loggedInUser.districtCity,
        policyType: "KPI_DISPLAY",
        // smart_vertical: "All",
        // userRole: this.loggedInUser.role,
        applyCriteria: true,
      };

      this._dashboardService
        .getDashboardWithAppliedPolicies(params)
        .then((polcies: string[]) => {
          var policyComponents = [];

          if(polcies.length){
            polcies.forEach((item) => {
              let comps = this.components.filter((widget) => {
                // let index = widget.policies.indexOf(item)
                let index = widget.policies.split(",").indexOf(item);
                if (index >= 0) {
                  return true;
                } else {
                  return false;
                }
              });
  
              policyComponents = policyComponents.concat(comps);
            });

          this.setDashboardWidgets(policyComponents);

          }


          this.loadingWidgets = false;
          this.errorWhileFetchingWidgets = false;
        })
        .catch((error) => {
          this.loadingWidgets = false;
          this.errorWhileFetchingWidgets = true;
          console.log(error);
        });
    } else {
      // this.subs.push(
      this.subscription1 = this._dashboardService
        .getDashboardsDetails(this.loggedInUser.userId, dashboardName)
        .subscribe(
          (res: any) => {
            const widgets = res.widgets.map((item) => {
              const widgetItem = item.attributes;
              widgetItem.x = Number(widgetItem.x);
              widgetItem.y = Number(widgetItem.y);
              widgetItem.cols = Number(widgetItem.cols);
              widgetItem.rows = Number(widgetItem.rows);
              widgetItem.minItemRows = Number(widgetItem.minItemRows);
              widgetItem.minItemCols = Number(widgetItem.minItemCols);
              widgetItem.mouseOver = false;
              return widgetItem;
            });

            // this.dashboard = [];
            // this.dashboard = widgets;

            // this.dashboard.forEach((item) => {
            //   const index = this.components.findIndex(
            //     (x) => x.id === item.id
            //   );
            //   if (index >= 0) {
            //     this.components[index].displaying = true;
            //   }
            // });
            this.setDashboardWidgets(widgets);
            this.loadingWidgets = false;
            this.errorWhileFetchingWidgets = false;
          },
          (err) => {
            this.loadingWidgets = false;
            this.errorWhileFetchingWidgets = true;
            console.log(err);
          }
        );
      // )
    }
  }

  private setDashboardWidgets(widgets) {
    this.dashboard = [];
    this.dashboard = widgets;

    this.dashboard.forEach((item) => {
      const index = this.components.findIndex((x) => x.id === item.id);
      if (index >= 0) {
        this.components[index].displaying = true;
      }
    });
  }
  public getWidgetsOfVertical(vertical: string) {
    // console.log(`-----getWidgetsOfVertical----`);
    // console.log(vertical);
    return this.components.filter((item) => item.vertical === vertical);
  }

  private fetchDashboardList() {
    // this.subs.push(
    this.subscription2 = this._dashboardService
      .getDashboardsList(this.loggedInUser.userId)
      .subscribe(
        (res: any) => {
          if(res.length){
            this.savedDashboardList = res;
            const defaultWidget = this.savedDashboardList.find(
              (item) => item.defaultDashboard === true
            );
  
            this.defaultDashboard = defaultWidget
              ? defaultWidget.dashboardName
              : "";
  
            this.fetchDashboardDetails(this.defaultDashboard);
            // console.log(this.defaultDashboard);
          }
        },
        (err) => {
          console.log(err);
        }
      );
    // )
    // .catch((err) => {
    //   console.log(err);
    // });
  }

  changedOptions() {
    if (this.options.api && this.options.api.optionsChanged) {
      this.options.api.optionsChanged();
    }
  }

  // addSmartCityWidgets(veticalName: string, widgetName: string) {
  addSmartCityWidgets(widgetName: string) {
    if (this.dashboard.some((e) => e.name === widgetName)) {
      this.toastr.info("Widget already exists in dashboard", "Dashboard");
    } else {
      const index = this.components.findIndex((x) => x.name === widgetName);
      if (index >= 0) {
        this.components[index].displaying = true;
        this.dashboard.push(this.components[index]);
      }

      // this.components.forEach((vertical, index) => {
      //   vertical.widgets.forEach((element, i) => {
      //     if (element.attributes.name == widgetName) {
      //       this.components[index].widgets[i].attributes.displaying = true;

      //       this.dashboard.push(this.components[index].widgets[i].attributes);
      //     }
      //   });
      // });
    }
  }

  onSelectionDashboard(dashboardName: string) {
    // const params = {
    //   state_name: "Karnataka",
    //   district_city: "Belagavi",
    //   policy_type: "KPI_DISPLAY",
    //   smart_vertical: "SWM",
    //   user_role: "ADMIN",
    //   apply_criteria: true,
    // };
    // if (dashboardName === "policy") {
    //   this._dashboardService
    //     .getDashboardWithAppliedPolicies(params)
    //     .then((polcies: string[]) => {
    //       var policyComponents = [];

    //       polcies.forEach((item) => {
    //         let comps = this.components.filter((widget) => {
    //           let index = widget.policies.indexOf(item);
    //           if (index >= 0) {
    //             return true;
    //           } else {
    //             return false;
    //           }
    //         });
    //         policyComponents = policyComponents.concat(comps);
    //       });

    //       console.log(policyComponents);
    //     })
    //     .catch((error) => {
    //       console.log(error);
    //     });
    // } else {
    //   if (this.dashboardSelected != dashboardName) {
    //     this.dashboardSelected = dashboardName;
    //     this.resetDashboard();
    //     this.fetchDashboardDetails(dashboardName);
    //   }
    // }

    if (this.dashboardSelected != dashboardName) {
      this.dashboardSelected = dashboardName;
      this.resetDashboard();
      this.fetchDashboardDetails(dashboardName);
    }
  }

  widgetAddOrRemove($event: any, remove: boolean, widgetName: string) {
    $event.stopPropagation();
    if (remove) {
      this.removeItem(widgetName);
    } else {
      this.addSmartCityWidgets(widgetName);
    }
  }

  removeItem(widgetName: string) {
    // console.log("deleting widget");
    // $event.preventDefault();
    // $event.stopPropagation();
    // console.log(`close btn clicked`)
    const index = this.dashboard.findIndex((x) => x.name === widgetName);
    if (index >= 0) {
      this.dashboard.splice(index, 1);

      const ind = this.components.findIndex((x) => x.name === widgetName);
      if (ind >= 0) {
        this.components[ind].displaying = false;
      }

      // this.components.forEach((vertical, index) => {
      //   vertical.widgets.forEach((element, i) => {
      //     if (element.attributes.name == widgetName) {
      //       this.components[index].widgets[i].attributes.displaying = false;
      //     }
      //   });
      // });
    }
  }

  addItem() {
    this.dashboard.push({
      x: 0,
      y: 0,
      cols: 4,
      rows: 3,
      type: this.WidgetType,
    });
  }

  deleteDashboard(dashboardName: String) {
    this._dashboardService
      .deleteDashboard(this.loggedInUser.userId, dashboardName)
      .then((res) => {
        // console.log(`Dashboard ${dashboardName} deleted.`)
        this.fetchDashboardList();
        this.toastr.info(`Dashboard ${dashboardName} deleted.`, "Dashboard");
      })
      .catch((err) => {
        // console.log(`Error while deleting dashboard ${dashboardName}.`)
        this.toastr.error(
          `Error while deleting dashboard ${dashboardName}.`,
          "Dashboard"
        );
      });
  }
  createNewDashboard() {
    const dialogRef = this.dialog.open(NewDashboardNameDialogComponent, {
      data: {},
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result != "" && result) {
        this.dashboard = [];
        this.resetDashboard();

        this.dashboardSelected = result;
      }
    });
  }

  resetDashboard() {
    this.components.forEach((element, index) => {
      this.components[index].displaying = false;
    });

    // this.components.forEach((item, verticalIndex) => {
    //   item.widgets.forEach((widget, widgetIndex) => {
    //     this.components[verticalIndex].widgets[
    //       widgetIndex
    //     ].attributes.displaying = false;
    //   });
    // });
  }

  getDashboardItems() {
    if (this.dashboard) {
      return this.dashboard;
    } else {
      return null;
    }
  }

  saveDashboard() {
    let widgets = this.dashboard.map((item) => {
      delete item.mouseOver;
      return {
        attributes: item,
      };
    });

    let params = {
      userId: this.loggedInUser.userId,
      // default_dashboard_name: null,
      dashboards: [
        {
          dashboardName: this.dashboardSelected,
          widgets: widgets,
        },
      ],
    };

    // console.log(JSON.stringify(params))
    // this.subs.push(
    this.subscription3 = this._dashboardService.saveDashboard(params).subscribe(
      (res) => {
        this.toastr.info(`Dashboard saved.`, "Dashboard");
        this.fetchDashboardList();
      },
      (err) => {
        this.toastr.error(`Error while saving dashboard.`, "Dashboard");
      }
      // )
    );
    // .catch((err) => {
    //   this.toastr.error(`Error while saving dashboard.`, "Dashboard");
    // });

    // console.log(this.dashboard);
  }

  setAsDefaultDashboard(dashboardName: String) {
    let params = {
      userId: this.loggedInUser.userId,
      defaultDashboardName: dashboardName,
      // dashboards: null
    };

    // this.subs.push(
    this.subscription4 = this._dashboardService.saveDashboard(params).subscribe(
      (res) => {
        this.toastr.info(
          `Dashboard ${dashboardName} set as default.`,
          "Dashboard"
        );
        this.fetchDashboardList();
      },
      (err) => {
        this.toastr.error(
          `Error while setting ${dashboardName} as default dashboard.`,
          "Dashboard"
        );
      }
      // )
    );
    // .catch((err) => {
    //   this.toastr.error(
    //     `Error while setting ${dashboardName} as default dashboard.`,
    //     "Dashboard"
    //   );
    // });

    // console.log(this.dashboard);
  }

  static itemChange(item, itemComponent) {
    // console.info("itemChanged", item, itemComponent);
    // const index = this.dashboard.findIndex((x) => x.name === item.name);
    // if (index >= 0) {
    //   this.dashboard[index] = item
    // }
    // console.log(this.dashboard)
  }

  static itemResize(item, itemComponent) {
    // console.info("itemResized", item, itemComponent);
  }

  changeStyle($event) {
    // // event.target.classList = $event.type == 'mouseenter'
    // event.target.classList.add('highlighted');
    // if($event.type == 'mouseenter') {
    //   // event.target.classList.add('mouse-enter-widget')
    //   this.render.removeClass(event.target, class);
    // } else {
    //   // event.target.classList.add('mouse-leave-widget')
    //   this.render.addClass(event.target, class);
    // }
  }

  public getOptions() {
    this.options = {
      itemChangeCallback: DynamicWidgetComponent.itemChange,
      itemResizeCallback: DynamicWidgetComponent.itemResize,
      gridType: GridType.Fixed,
      // compactType: CompactType.None,
      compactType: CompactType.CompactUpAndLeft,
      margin: 5,
      outerMargin: true,
      outerMarginTop: 10,
      outerMarginRight: 10,
      outerMarginBottom: 10,
      outerMarginLeft: 10,
      useTransformPositioning: true,

      mobileBreakpoint: 640,
      minCols: 12,
      maxCols: 12,
      minRows: 20,
      maxRows: 20,
      maxItemCols: 100,
      minItemCols: 1,
      maxItemRows: 100,
      minItemRows: 1,
      maxItemArea: 2500,
      minItemArea: 1,
      defaultItemCols: 1,
      defaultItemRows: 1,
      fixedColWidth: 118,
      fixedRowHeight: 105,

      keepFixedHeightInMobile: false,
      keepFixedWidthInMobile: false,
      scrollSensitivity: 10,
      scrollSpeed: 20,
      enableEmptyCellClick: false,
      enableEmptyCellContextMenu: false,
      enableEmptyCellDrop: false,
      enableEmptyCellDrag: false,
      emptyCellDragMaxCols: 50,
      emptyCellDragMaxRows: 50,
      ignoreMarginInRow: false,
      draggable: {
        enabled: true,
      },
      resizable: {
        enabled: false,
      },
      swap: false,
      pushItems: true,
      disablePushOnDrag: false,
      disablePushOnResize: false,
      pushDirections: { north: true, east: true, south: true, west: true },
      pushResizeItems: false,
      displayGrid: DisplayGrid.None,
      disableWindowResize: false,
      disableWarnings: false,
      scrollToNewItems: false,
    };

    // this.options = {
    //   itemChangeCallback: VmsGridsterComponent.itemChange,
    //   itemResizeCallback: VmsGridsterComponent.itemResize,
    //   gridType: GridType.Fit,
    //   compactType: CompactType.CompactUpAndLeft,
    //   displayGrid: DisplayGrid.None,
    //   margin: 10,
    //   outerMargin: true,
    //   outerMarginTop: null,
    //   outerMarginRight: null,
    //   outerMarginBottom: null,
    //   outerMarginLeft: null,
    //   useTransformPositioning: true,
    //   mobileBreakpoint: 600,

    //   minCols: this.no_cols,
    //   maxCols: this.no_cols,
    //   minRows: this.no_rows,
    //   maxRows: this.no_rows,

    //   maxItemCols: 1,
    //   minItemCols: 1,
    //   maxItemRows: 1,
    //   minItemRows: 1,
    //   maxItemArea: 2000,

    //   minItemArea: 1,
    //   defaultItemCols: 1,
    //   defaultItemRows: 1,
    //   fixedColWidth: 200,
    //   fixedRowHeight: 200,

    //   keepFixedHeightInMobile: false,
    //   keepFixedWidthInMobile: false,
    //   scrollSensitivity: 10,
    //   scrollSpeed: 2,
    //   enableEmptyCellClick: false,
    //   enableEmptyCellContextMenu: false,
    //   enableEmptyCellDrop: false,
    //   enableEmptyCellDrag: false,
    //   emptyCellDragMaxCols: 50,
    //   emptyCellDragMaxRows: 50,
    //   ignoreMarginInRow: false,
    //   draggable: {
    //     enabled: true,
    //   },
    //   resizable: {
    //     enabled: false,
    //   },
    //   swap: false,
    //   pushItems: true,
    //   disablePushOnDrag: false,
    //   disablePushOnResize: false,
    //   pushDirections: { north: true, east: true, south: true, west: true },
    //   pushResizeItems: false,
    //   disableWindowResize: false,
    //   disableWarnings: false,
    //   scrollToNewItems: false,
    // };
  }
}
