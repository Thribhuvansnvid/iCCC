import { Component, OnInit } from '@angular/core';
// import { CustomMatIconService } from '../../shared/services/custom-icon.service';

@Component({
  selector: 'app-dashboard-widget',
  templateUrl: './dashboard-widget.component.html',
  styleUrls: ['./dashboard-widget.component.scss']
})
export class DashboardWidgetComponent implements OnInit {

  constructor(
    // private customMatIconService:CustomMatIconService
    ) {
    // customMatIconService.init();
   }

  ngOnInit() {
  }

}
