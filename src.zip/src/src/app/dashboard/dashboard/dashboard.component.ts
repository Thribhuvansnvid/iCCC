import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  ViewEncapsulation,
} from '@angular/core'
//import { GridsterConfig, GridsterItem } from 'angular-gridster2';
//import { DynamicWidgetService } from '../services/dynamic-widget.service';
//import { GisServerMapsComponent } from '../gis-server-maps/gis-server-maps.component'
import {
  CompactType,
  DisplayGrid,
  GridsterConfig,
  GridsterItem,
  GridType,
} from 'angular-gridster2'
import { AnyAaaaRecord } from 'dns'
import { ToastrService } from 'ngx-toastr'

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
})
export class DashboardComponent implements OnInit {
  options: GridsterConfig
  dashboard: Array<GridsterItem>
  WidgetType: any
  userRole = ''
  widgetsSelection: any[] = []

  constructor() {}

  public components = {
    environment: [
      {
        name: 'Smart Env',
        widget: 'smartenv',
        component: 'SmartEnvSummaryComponent',
      },
      {
        name: 'Smart Env Map',
        widget: 'smartenvmap',
        component: 'SmartenvmapComponent',
      },
    ],

    streetlights: [
      {
        name: 'Smart Street Light',
        widget: 'smartlighting',
        component: 'SmartLightingSummaryComponent',
      },
      {
        name: 'Smart Lights Map',
        widget: 'smartlightingmap',
        component: 'StreetlightmapComponent',
      },
    ],

    parking: [
      {
        name: 'Smart Parking',
        widget: 'smartparking',
        component: 'SmartParkingSummaryComponent',
      },
      {
        name: 'Smart Parking Map',
        widget: 'smartparkingmap',
        component: 'SmartparkingmapComponent',
      },
    ],

    transport: [
      {
        name: 'Smart Transport',
        widget: 'smarttransport',
        component: 'SmartTransportSummaryComponent',
      },
      {
        name: 'Smart Transport Map',
        widget: 'smarttransportmap',
        component: 'SmarttransportmapComponent',
      },
    ],

    bin: [
      {
        name: 'Smart Bin',
        widget: 'smartbin',
        component: 'SmartBinSummaryComponent',
      },
      {
        name: 'Smart Bin Map',
        widget: 'smartbinmap',
        component: 'SmartbinmapComponent',
      },
    ],

    water: [
      {
        name: 'Smart Water',
        widget: 'smartwater',
        component: 'SmartwatersummaryComponent',
      },
      {
        name: 'Smart Water Map',
        widget: 'smartwatermap',
        component: 'SmartwatermapComponent',
      },
    ],

    energy: [
      {
        name: 'Smart Energy',
        widget: 'smartenergy',
        component: 'SmartenergysummaryComponent',
      },
      {
        name: 'Smart Energy Map',
        widget: 'smartenergymap',
        component: 'SmartenergymapComponent',
      },
    ],

    vmd: [
      {
        name: 'VMD',
        widget: 'vmd',
        component: 'VmdsummaryComponent',
      },
      {
        name: 'VMD Map',
        widget: 'vmdmap',
        component: 'VmdmapComponent',
      },
    ],

    vms: [
      {
        name: 'VMS VA',
        widget: 'vmsva',
        component: 'SummaryVaVmsComponent',
      },
      {
        name: 'VMS Map',
        widget: 'vmsvamap',
        component: 'VmsvamapComponent',
      },
    ],

    atcs: [
      {
        name: 'ATCS',
        widget: 'atcs',
        component: 'AtcssummaryComponent',
      },
      {
        name: 'ATCS Map',
        widget: 'atcsmap',
        component: 'ATCSMapComponent',
      },
    ],
  }

  public widgetsConfig = {
    smartenv: {
      cols: 4,
      rows: 2,
      y: 0,
      x: 0,
      minItemRows: 2,
      minItemCols: 3,
      link: '/auth/smartenv',
    },
    smartwater: {
      cols: 4,
      rows: 2,
      y: 0,
      x: 0,
      minItemRows: 2,
      minItemCols: 3,
      link: '/auth/smartenv',
    },

    smartlighting: {
      cols: 4,
      rows: 2,
      y: 0,
      x: 3,
      minItemRows: 2,
      minItemCols: 3,
      link: '/auth/smartstreetlight',
    },
    smartenergy: {
      cols: 4,
      rows: 2,
      y: 0,
      x: 0,
      minItemRows: 2,
      minItemCols: 3,
      link: '/auth/smartstreetlight',
    },

    smartparking: {
      cols: 4,
      rows: 2,
      y: 0,
      x: 6,
      minItemRows: 2,
      minItemCols: 3,
      link: '/auth/smartparking',
    },

    smartbin: {
      cols: 4,
      rows: 2,
      y: 0,
      x: 0,
      minItemRows: 2,
      minItemCols: 3,
      link: '/auth/smartbin',
    },

    vmd: {
      cols: 4,
      rows: 2,
      y: 0,
      x: 0,
      minItemRows: 2,
      minItemCols: 3,
      link: '/auth/vmd',
    },

    atcs: {
      cols: 4,
      rows: 2,
      y: 0,
      x: 0,
      minItemRows: 2,
      minItemCols: 3,
      link: '/auth/atcs',
    },

    vms: {
      cols: 4,
      rows: 2,
      y: 0,
      x: 0,
      minItemRows: 2,
      minItemCols: 3,
      link: '/auth/atcs',
    },
  }

  ngOnInit() {
    console.log('OnInit dynamic widget')

    this.getOptions()

    //All widgets
    this.dashboard = [
      this.widgetsConfig['vms'],
      this.widgetsConfig['atcs'],
      this.widgetsConfig['vmd'],
      this.widgetsConfig['smartbin'],
      this.widgetsConfig['smartparking'],
      this.widgetsConfig['smartenergy'],
      this.widgetsConfig['smartlighting'],
      this.widgetsConfig['smartwater'],
      this.widgetsConfig['smartenv'],
    ]

    console.log(`dashboard.component component len ${this.dashboard.length}`)
  }

  changedOptions() {
    if (this.options.api && this.options.api.optionsChanged) {
      this.options.api.optionsChanged()
    }
  }

  addSmartCityWidgets() {
    console.log(
      'dynamic-widget.component addSmartCityWidgets widgettype-->' +
        this.WidgetType
    )
    console.log(
      'dynamic-widget.component addSmartCityWidgets compo details-->' +
        this.widgetsConfig[this.WidgetType]
    )

    if (this.dashboard.some((item) => item.widget === this.WidgetType)) {
      console.log(
        'dynamic-widget.component addSmartCityWidgets widget already in dashboard'
      )
    } else {
      this.dashboard.push(this.widgetsConfig[this.WidgetType])
    }

    //this.dashboard.push({cols: 4, rows: 3, y: 0, x: 0, minItemRows: 2, minItemCols: 3, component:this.components[this.WidgetType],name:'Smart Env'});
  }

  removeItem($event, item) {
    console.log('deleting widget')
    $event.preventDefault()
    $event.stopPropagation()
    this.dashboard.splice(this.dashboard.indexOf(item), 1)
  }

  addItem() {
    this.dashboard.push({ x: 0, y: 0, cols: 4, rows: 3, type: this.WidgetType })
  }

  public getOptions() {
    this.options = {
      gridType: GridType.Fixed,
      compactType: CompactType.None,
      margin: 15,
      outerMargin: true,
      outerMarginTop: null,
      outerMarginRight: null,
      outerMarginBottom: null,
      outerMarginLeft: null,
      useTransformPositioning: true,
      mobileBreakpoint: 640,
      minCols: 1,
      maxCols: 12,
      minRows: 1,
      maxRows: 100,
      maxItemCols: 12,
      minItemCols: 1,
      maxItemRows: 100,
      minItemRows: 1,
      maxItemArea: 2500,
      minItemArea: 1,
      defaultItemCols: 1,
      defaultItemRows: 1,
      fixedColWidth: 105,
      fixedRowHeight: 105,
      keepFixedHeightInMobile: false,
      keepFixedWidthInMobile: false,
      scrollSensitivity: 10,
      scrollSpeed: 20,
      enableEmptyCellClick: false,
      enableEmptyCellContextMenu: false,
      enableEmptyCellDrop: false,
      enableEmptyCellDrag: false,
      emptyCellDragMaxCols: 50,
      emptyCellDragMaxRows: 50,
      ignoreMarginInRow: false,
      draggable: {
        enabled: true,
      },
      resizable: {
        enabled: true,
      },
      swap: false,
      pushItems: true,
      disablePushOnDrag: false,
      disablePushOnResize: false,
      pushDirections: { north: true, east: true, south: true, west: true },
      pushResizeItems: false,
      displayGrid: DisplayGrid.Always,
      disableWindowResize: false,
      disableWarnings: false,
      scrollToNewItems: false,
    }
  }
}
