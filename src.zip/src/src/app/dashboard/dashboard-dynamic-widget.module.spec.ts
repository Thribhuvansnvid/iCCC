import { DashboardDynamicWidgetModule } from './dashboard-dynamic-widget.module';

describe('DashboardDynamicWidgetModule', () => {
  let dashboardDynamicWidgetModule: DashboardDynamicWidgetModule;

  beforeEach(() => {
    dashboardDynamicWidgetModule = new DashboardDynamicWidgetModule();
  });

  it('should create an instance', () => {
    expect(dashboardDynamicWidgetModule).toBeTruthy();
  });
});
