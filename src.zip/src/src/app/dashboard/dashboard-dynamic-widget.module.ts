import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GridsterModule } from 'angular-gridster2';
import { DynamicWidgetComponent } from './dynamic-widget/dynamic-widget.component'
import { CoreModule } from '../core/core.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { DashboardDynamicWidgetRouterModule } from './dashboard-dynamic-widget.routes';
import { FlexLayoutModule } from "@angular/flex-layout";

import { SmartcityComponent } from './smartcity/smartcity.component'
// import { SmartBinModule } from '../smartcity-verticals/smartbin/smartbin.module'
// import { SmartEnvModule } from '../smartcity-verticals/smartenv/smartenv.module'

import { SummarynmapModule } from '../smartcity-verticals/summarynmap/summarynmap.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { DashboardWidgetComponent } from './dashboard-widget/dashboard-widget.component';
import { MaterialModule } from '../shared/material/material.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
// import { KpiModule } from '../kpi/kpi.module';
import { MainPageComponent } from './main-page/main-page.component';
import { NewDashboardNameDialogComponent } from './dialogs/new-dashboard-name/new-dashboard-name.dialog.component';
import { DashboardService } from './services/dashboard.services';

@NgModule({
  imports: [

    CommonModule,
    GridsterModule,
    CoreModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    FlexLayoutModule,
    DashboardDynamicWidgetRouterModule,
    SummarynmapModule,
    MaterialModule,
    NgbModule,

  ],
  declarations: [
    DynamicWidgetComponent,
    SmartcityComponent,
    DashboardComponent,
    DashboardWidgetComponent,
    MainPageComponent,
    NewDashboardNameDialogComponent
  ],
  exports:[
    DashboardWidgetComponent
  ],
  	entryComponents: [	
		NewDashboardNameDialogComponent
	  ],
  providers: [
    DashboardService
  ],
})
export class DashboardDynamicWidgetModule { }
