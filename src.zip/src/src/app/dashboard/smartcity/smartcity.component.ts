import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-smartcity',
  templateUrl: './smartcity.component.html',
  styleUrls: ['./smartcity.component.scss']
})
export class SmartcityComponent implements OnInit {

  @Input()
  widgettype;
  constructor( private router: Router) { }

  ngOnInit() {
    // console.log(this.widgettype)
  }

  goToRespectiveVertical(link:string){
    this.router.navigate([link]);
  }

}
