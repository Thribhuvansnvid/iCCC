import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DynamicWidgetComponent } from './dynamic-widget/dynamic-widget.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { DashboardWidgetComponent } from './dashboard-widget/dashboard-widget.component';
import { MainPageComponent } from './main-page/main-page.component';
//import { GisOlComponent } from './gis-ol/gis-ol.component';
//import { MapComponent } from './map/map.component'

const DynamicDashboardRoutes: Routes = [

  { path: '', component: DynamicWidgetComponent},
//   { path: '', component: MainPageComponent}
];

@NgModule({
	imports: [
		RouterModule.forChild(DynamicDashboardRoutes),
	],
	exports: [
		RouterModule
	]
})
export class DashboardDynamicWidgetRouterModule { }
