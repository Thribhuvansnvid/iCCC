import { Injectable, SkipSelf } from '@angular/core'
import {
  BehaviorSubject,
  Observable,
  of,
  Subject,
  throwError,
  timer,
} from 'rxjs'
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
} from '@angular/common/http'
import { AppConfigService } from '../../shared/configs-loader/app.config.service'
import { map, catchError, tap } from 'rxjs/operators'

// @Injectable({
//   providedIn: "root",
// })

@Injectable()
export class DashboardService {
  BASE_URL = ''
  policyBaseUrl = ''
  constructor(
    @SkipSelf() private httpClient: HttpClient,
    // private httpClient: HttpClient,
    private appConfigService: AppConfigService
  ) {
    this.BASE_URL = this.appConfigService.getConfig().API_BASE_URL + '/sc/dashboard'
    this.policyBaseUrl = this.appConfigService.getConfig().API_BASE_URL + '/sc/policies'
  }

  errorHandler(error: HttpErrorResponse) {
    return Observable.throw(error.message || 'server error.')
  }

  getDashboardsList(userId: String): Observable<any> {
    const endpoint = `${this.BASE_URL}/getnames/${userId}`
    return this.httpClient.get(endpoint).pipe(
      map((res: any) => {
        let dashboardList = res.map((item) => {
          return {
            dashboardName: item.dashboardName,
            defaultDashboard: item.isDefault,
          }
        })

        return dashboardList
      }),
      catchError(this.errorHandler)
    )

    // let promise = new Promise((resolve, reject) => {
    //   const endpoint = `${this.BASE_URL}/getnames/${userId}`;
    //   this.httpClient
    //     .get(endpoint)
    //     .toPromise()
    //     .then(
    //       (res: any) => {
    //         let dashboardList = res.map((item) => {
    //           return {
    //             dashboardName: item.dashboard_name,
    //             defaultDashboard: item.is_default,
    //           };
    //         });
    //         resolve(dashboardList);
    //       },
    //       (msg) => {
    //         // Error
    //         reject(msg);
    //       }
    //     );
    // });
    // return promise;
  }

  getDashboardsDetails(userId: String, dashboardName: String): Observable<any> {
    const endpoint = `${this.BASE_URL}/getlayout/${userId}/${dashboardName}`

    return this.httpClient.get(endpoint).pipe(
      tap((res) => {
        console.log(`fetchDashboardDetails response`)
      })
    )

    // let promise = new Promise((resolve, reject) => {
    //   const endpoint = `${this.BASE_URL}/getlayout/${userId}/${dashboardName}`;
    //   this.httpClient
    //     .get(endpoint)
    //     .toPromise()
    //     .then(
    //       (res) => {
    //         console.log(`getDashboardsDetails--->${res}`);
    //         resolve(res);
    //       },
    //       (msg) => {
    //         // Error
    //         console.log(`getDashboardsDetails error--->${msg}`);
    //         reject(msg);
    //       }
    //     );
    // });

    // return promise;
  }

  getDashboardWithAppliedPolicies(params) {
    const endpoint = `${this.policyBaseUrl}/filterpolicies`
    let promise = new Promise((resolve, reject) => {
      this.httpClient
        .post(endpoint, params)
        .toPromise()
        .then(
          (res: any) => {
            let  policies = []
            if(res.totalCount > 0){
              res.map((item) => item.policyName)
            }
            // console.log('policies are 1', policies)
            // policies.push('itms')
            // console.log('policies are ', policies)
            resolve(policies)
          },
          (msg) => {
            // Error
            reject(msg)
          }
        )
    })
    return promise
  }

  // getGarbageCollectionData(params: any) {
  //   let promise = new Promise((resolve, reject) => {
  //     const endpoint = `${this.BASE_URL}/garbagecollection/getGarbageCollectionData`;
  //     this.httpClient
  //       .post(endpoint, params)
  //       .toPromise()
  //       .then(
  //         (res: any) => {
  //           resolve(res);
  //         },
  //         (msg) => {
  //           reject(msg);
  //         }
  //       );
  //   });
  //   return promise;
  // }

  saveDashboard(params): Observable<any> {
    const endpoint = `${this.BASE_URL}/update`
    console.log(JSON.stringify(params))

    return this.httpClient.post(endpoint, params)
    // let promise = new Promise((resolve, reject) => {
    //   const endpoint = `${this.BASE_URL}/update`;
    //   this.httpClient
    //     .post(endpoint, params)
    //     .toPromise()
    //     .then(
    //       (res: any) => {
    //         resolve(res);
    //       },
    //       (msg) => {
    //         // Error
    //         reject(msg);
    //       }
    //     );
    // });
    // return promise;
  }

  deleteDashboard(userId: String, dashboardName: String) {
    const options = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
      body: {
        user_id: userId,
        dashboard_names: [dashboardName],
      },
    }

    let promise = new Promise((resolve, reject) => {
      const endpoint = `${this.BASE_URL}/delete`
      this.httpClient
        .delete(endpoint, options)
        .toPromise()
        .then(
          (res: any) => {
            resolve(res)
          },
          (msg) => {
            // Error
            reject(msg)
          }
        )
    })
    return promise
  }

  getComponentWidgets() {

    const endpoint = '/assets/config/widgets.json'

    return this.httpClient.get(endpoint).pipe(
      tap((res) => {
        console.log(`component widgets fetched`)
      })
    )

    // let promise = new Promise((resolve, reject) => {
      
    //   this.httpClient
    //     .get(endpoint)
    //     .toPromise()
    //     .then(
    //       (res: any) => {
    //         resolve(res)
    //       },
    //       (msg) => {
    //         // Error
    //         reject(msg)
    //       }
    //     )
    // })
    // return promise
  }
}
