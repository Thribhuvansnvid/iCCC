import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material/dialog";
import { Component, Inject } from "@angular/core";
import { FormControl, Validators } from "@angular/forms";
import { MatCarousel, MatCarouselComponent } from "@ngmodule/material-carousel";

@Component({
  // selector: 'app-add.dialog',
  templateUrl: "./new-dashboard-name.dialog.html",
  styleUrls: ["./new-dashboard-name.dialog.scss"],
})
export class NewDashboardNameDialogComponent {
  newDashboardName: string = "";
  constructor(
    public dialogRef: MatDialogRef<NewDashboardNameDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    console.log("new dashboard");
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  onClickOk(): void {
    if(this.newDashboardName == ""){
      return;
    }
    this.dialogRef.close(this.newDashboardName);
    // this.dataService.deleteUser(this.data.userid);
  }
}
