import { Injectable } from '@angular/core'
import { HttpClient } from '@angular/common/http'
import { Subject } from 'rxjs'
import { environment } from '../environments/environment'
import * as Stomp from 'stompjs'
import * as SockJS from 'sockjs-client'
//const SERVER_URL = 'http://localhost:5001/subscription';
//const SERVER_URL = 'http://localhost:6200/subscribe';
const SERVER_URL = 'http://192.168.25.10:6200/subscribe'

@Injectable({
  providedIn: 'root',
})
export class PushNotificationService {
  onWebSocketAlertRcvd = new Subject<any>()
  public stompClient: any
  private URL = ''
  alertdetails: any
  constructor(private http: HttpClient) {
    this.stompClient = this.connect()
    this.stompClient.connect({}, (frame) => {
      this.stompClient.subscribe('/topic/alertinfo', (notifications) => {
        // Update notifications attribute with the recent messsage sent from the server

        this.alertdetails = JSON.parse(notifications.body)
        console.log('notification body' + this.alertdetails.AlertID)
        this.onWebSocketAlertRcvd.next(notifications.body)
      })
    })
  }

  public sendSubscriptionToTheServer(subscription: PushSubscription) {
    console.log('sent subscription')
    //alert('sent subscription')
    console.log(subscription.endpoint)
    //console.log(subscription.getKey)
    //console.log(subscription.expirationTime)
    console.log(subscription.getKey('auth'))
    console.log(subscription.getKey('p256dh'))
    return this.http.post(SERVER_URL, subscription)
  }

  public connect() {
    let socket = new SockJS(this.URL + '/socket') // new SockJs(`http://localhost:8086/ws`);

    let stompClient = Stomp.over(socket)

    return stompClient
  }
  public subscribeWebSocketAlert() {
    this.stompClient = this.connect()
    this.stompClient.connect({}, (frame) => {
      this.stompClient.subscribe('/topic/alertinfo', (notifications) => {
        // Update notifications attribute with the recent messsage sent from the server

        this.alertdetails = JSON.parse(notifications.body)
        console.log('notification body' + this.alertdetails.AlertID)
        this.onWebSocketAlertRcvd.next(notifications.body)
        //this.vehicleGPSRecvd.vehc_no=this.vehicledetails.VehcID;
        //this.vehicleGPSRecvd.gpslocation=this.vehicledetails.GPSCordn;
      })
    })
  }
}
export class AlertNotification {
  notification: string
  title: string
}
