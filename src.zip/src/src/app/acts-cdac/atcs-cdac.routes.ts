import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AtcsCdacContainerComponent } from "./atcs-cdac-container/atcs-cdac-container.component";

const pagesRoutes: Routes = [
  {
    path: "",
    component: AtcsCdacContainerComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(pagesRoutes)],
  exports: [RouterModule],
})
export class AtcsCdacRoutes {}
