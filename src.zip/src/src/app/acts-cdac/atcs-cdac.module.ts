import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { SharedModule } from '../shared/shared.module';
import { AtcsCdacContainerComponent } from "./atcs-cdac-container/atcs-cdac-container.component";
import { AtcsCdacRoutes } from "./atcs-cdac.routes";


@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    AtcsCdacRoutes
  ],
  declarations: [
    AtcsCdacContainerComponent
  ],
	providers: [
	],
  entryComponents: [],
})
export class AtcsCdacModule {}
