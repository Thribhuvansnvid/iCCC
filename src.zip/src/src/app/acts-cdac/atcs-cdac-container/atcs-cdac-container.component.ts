import { Component, OnInit, ViewEncapsulation } from '@angular/core'
import { AppConfigService } from 'src/app/shared/configs-loader/app.config.service'

@Component({
  selector: 'hexagon-container',
  templateUrl: './atcs-cdac-container.component.html',
  styleUrls: ['./atcs-cdac-container.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class AtcsCdacContainerComponent implements OnInit {
  public Url = ''

  constructor(private _configs: AppConfigService) {
    this.Url = this._configs.getConfig().atcsCdac
    console.log(`emergency url ${this.Url}`)
  }

  ngOnInit() {}
}
