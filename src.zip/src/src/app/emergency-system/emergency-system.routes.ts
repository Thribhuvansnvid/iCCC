import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { EmergencySystemContainerComponent } from './emergency-system-container/emergency-system-container.component';

const pagesRoutes: Routes = [
  {
    path: "",
    component: EmergencySystemContainerComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(pagesRoutes)],
  exports: [RouterModule],
})
export class EmergencySystemRoutes {}
