import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { SharedModule } from '../shared/shared.module';
import { EmergencySystemContainerComponent } from './emergency-system-container/emergency-system-container.component';
import { EmergencySystemRoutes } from './emergency-system.routes';



@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    EmergencySystemRoutes
  ],
  declarations: [
    EmergencySystemContainerComponent
  ],
	providers: [
	],
  entryComponents: [],
})
export class EmergencySystemModule {}
