import { Component, OnInit, ViewEncapsulation } from '@angular/core'
import { AppConfigService } from 'src/app/shared/configs-loader/app.config.service'

@Component({
  selector: 'hexagon-container',
  templateUrl: './emergency-system-container.component.html',
  styleUrls: ['./emergency-system-container.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class EmergencySystemContainerComponent implements OnInit {
  public Url = ''

  constructor(private _configs: AppConfigService) {
    this.Url = this._configs.getConfig().emergencySystem
    console.log(`emergency url ${this.Url}`)
  }

  ngOnInit() {}
}
