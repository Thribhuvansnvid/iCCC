import { Injectable } from "@angular/core";
import { Observable, of, Subject } from "rxjs";
import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import { map } from "jquery";
import { tap } from "rxjs/operators";
import { AnyAaaaRecord, AnyMxRecord } from "dns";

@Injectable({
  providedIn: "root",
})
export class GISService {
  private coordinate = {};
  private alertData = {};
  private highlightData = {};
  private swmData = {};
  private atcsData = {};
  private atcsLineData = {};
  private vmsData = {};
  private milestoneVMSData = {};
  private googleURLGeoCooding = "https://maps.googleapis.com/maps/api/geocode/json";
  private googleKey = "AIzaSyCeRYHgTpeSCyjFyp0vhFxqsubWdR3qC8U";

  constructor(private httpClient: HttpClient) {}
  _onPickLocation = new Subject<any>()

  getAlertData(): Observable<any> {
    return of(this.alertData);
  }

  setAlertData(data: any) {
    this.alertData = data;
  }

  getHighlightData(): Observable<any> {
    return of(this.highlightData);
  }

  setHighlightData(data: any) {
    this.highlightData = data;
  }

  getSWMData(): Observable<any> {
    return of(this.swmData);
  }

  setSWMData(data: any) {
    this.swmData = data;
  }

  getATCSData(): Observable<any> {
    return of(this.atcsData);
  }

  setATCSData(data: any) {
    this.atcsData = data;
  }

  getATCSLineData(): Observable<any> {
    return of(this.atcsLineData);
  }

  setATCSLineData(data: any) {
    this.atcsLineData = data;
  }

  getVMSData(): Observable<any> {
    return of(this.vmsData);
  }

  setVMSData(data: any) {
    this.vmsData = data;
  }

  getMileStoneVMSData(): Observable<any> {
    return of(this.milestoneVMSData);
  }

  setMileStoneVMSData(data: any) {
    this.milestoneVMSData = data;
  }

  getCoordinate(): Observable<any> {
    return of(this.coordinate);
  }

  setCoordinate(data: any) {
    this.coordinate = data;
  }

  onPickLocation(){
    if(this.coordinate){
      this._onPickLocation.next(this.coordinate) 
    }
  }


  getAddressFromCoordinate(data: any) {
    let latlng = `${data["latitude"]},${data["longitude"]}`;
    let httpParams = new HttpParams();
    httpParams.append("latlng", latlng);
    httpParams.append("key", this.googleKey);
    const endpoint =
      this.googleURLGeoCooding + "?latlng=" + latlng + "&key=" + this.googleKey;

    let promise = new Promise((resolve, reject) => {
      this.httpClient
        .get(endpoint, {})
        .toPromise()
        .then(
          (res: any) => {
            let address;
            if (res["status"] == "OK") {
              address = res["results"][0]["formatted_address"];
            }

            resolve(address);
          },
          (msg) => {
            // Error
            reject(msg);
          }
        );
    });
    return promise;
  }
}
