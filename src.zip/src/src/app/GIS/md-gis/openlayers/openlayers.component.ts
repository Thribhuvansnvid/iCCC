import { Component, OnInit } from "@angular/core";
import Map from "ol/Map";
import Tile from "ol/layer/Tile";
import OSM from "ol/source/OSM";
import View from "ol/View";
import FullScreen from 'ol/control/FullScreen';
import ScaleLine from 'ol/control/ScaleLine';
import ZoomToExtent from 'ol/control/ZoomToExtent';
import ZoomSlider from 'ol/control/ZoomSlider';
import MousePosition from 'ol/control/MousePosition';
import { Coordinate, createStringXY } from "ol/coordinate";

@Component({
  selector: "app-openlayers",
  templateUrl: "./openlayers.component.html",
  styleUrls: ["./openlayers.component.css"],
})
export class OpenlayersComponent implements OnInit {
  map;
  constructor() {}

  ngOnInit() {
    this.initializeMap();
  }

  initializeMap() {
    var osmOnlineLayer = new Tile({
      zIndex: 0,
      source: new OSM(),
    });

    this.map = new Map({
      // loadTilesWhileAnimating: true,
      target: "mapid",
      layers: [osmOnlineLayer],
      view: new View({
        projection: "EPSG:4326",

        center: [77.6022222222, 12.9644444444],
        zoom: 14,
        maxZoom: 20,
      }),
    });
    let mousePosition = new MousePosition({
      coordinateFormat: createStringXY(4),
      projection: 'ESPG:4326',
      className:"ol-mouse-position",
      //target: document.getElementById('myposition'),
      undefinedHTML:"Not found",
  
    });
    this.map.addControl(mousePosition);
    //map.addControl(new ol.control.OverviewMap({}));
    this.map.addControl(new FullScreen({}));
    this.map.addControl(new ScaleLine({}));
    //map.addControl(new ol.control.Rotate({ className: "ol-rotate" }));
    this.map.addControl(new ZoomToExtent());
    this.map.addControl(new ZoomSlider());
  }
}
