import {
  Component,
  OnInit,
  OnDestroy,
  ViewChild,
  ElementRef,
} from "@angular/core";
import { loadModules } from "esri-loader";
import { GISManager } from "./datamgr/gismanager";
import { GISService } from "../intf-gis.service";
import LayerManager from "./datamgr/layer-manager";
import { CustomPopupComponent } from "./custom-popup/custom-popup.component";
import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";

@Component({
  selector: "app-arcgis",
  templateUrl: "./arcgis.component.html",
  styleUrls: [
    "./arcgis.component.css",
    //'../../../../node_modules/font-awesome/css/font-awesome.css',
  ],
})
export class ArcgisComponent implements OnInit, OnDestroy {
  constructor(private gisService: GISService) {}
  @ViewChild("mapViewNode", { static: true }) private mapViewEl: ElementRef;
  private view: any;
  private search: any;
  private layerList: any;
  private basemapGallery: any;
  private sketch: any;
  private measurement: any;
  private sketchExpand: any;
  private searchExpand: any;
  private layerlistExpand: any;
  private basemapExpand: any;
  private GisMgr: GISManager;
  private LayerManager: LayerManager;
  private CustomPopupComponent: CustomPopupComponent;
  private isToolShow = false;
  private isLayerShow = false;
  private isSearchShow = false;
  private isMapShow = false;

  displayComponent: boolean = false;

  async initializeMap() {
    try {
      // Load the modules for the ArcGIS API for JavaScript
      const [
        Map,
        MapView,
        SceneView,
        CoordinateConversion,
        LayerList,
        Search,
        BasemapGallery,
        Sketch,
        Measurement,
        Expand,
        GraphicsLayer,
        FeatureLayer,
        GeoJSONLayer,
        LabelClass,
        GroupLayer,
        Graphic,
      ] = await loadModules([
        "esri/Map",
        "esri/views/MapView",
        "esri/views/SceneView",
        "esri/widgets/CoordinateConversion",
        "esri/widgets/LayerList",
        "esri/widgets/Search",
        "esri/widgets/BasemapGallery",
        "esri/widgets/Sketch",
        "esri/widgets/Measurement",
        "esri/widgets/Expand",
        "esri/layers/GraphicsLayer",
        "esri/layers/FeatureLayer",
        "esri/layers/GeoJSONLayer",
        "esri/layers/support/LabelClass",
        "esri/layers/GroupLayer",
        "esri/Graphic",
      ]);

      // Configure the Map
      const mapProperties = {
        basemap: "streets",
        ground: "world-elevation",
      };
      const map = new Map(mapProperties);
      const mapViewProperties = {
        container: this.mapViewEl.nativeElement,
        spatialReferance: 4326,
        center: [74.797238, 34.090735], // longitude, latitude
        scale: 50000,
        map,
      };
      const view = new SceneView(mapViewProperties);
      const coordinateWidget = new CoordinateConversion({
        view: view,
      });
      view.ui.add(coordinateWidget, "bottom-right");

      await view.when(); // wait for map to load
      let layerlistElements = document.createElement("div");
      layerlistElements.style.cssText = "width: 500px";
      this.layerList = new LayerList({
        view: view,
        container: layerlistElements,
      });
      this.layerlistExpand = new Expand({
        view: view,
        content: this.layerList,
        container: "layersTouchBall",
      });
      this.search = new Search({
        view: view,
        container: document.createElement("div"),
      });
      this.searchExpand = new Expand({
        view: view,
        content: this.search,
        container: "SearchTouchBall",
      });
      this.basemapGallery = new BasemapGallery({
        view: view,
        source: {
          portal: {
            url: "https://www.arcgis.com",
            useVectorBasemaps: true, // Load vector tile basemaps
          },
        },
        container: document.createElement("div"),
      });
      this.basemapExpand = new Expand({
        view: view,
        content: this.basemapGallery,
        container: "BaseMapGallery",
      });
      const graphicLayer = new GraphicsLayer();
      map.layers.add(graphicLayer);
      this.sketch = new Sketch({
        layer: graphicLayer,
        view: this.view,
        creationMode: "update",
        container: document.createElement("div"),
      });
      this.sketchExpand = new Expand({
        view: view,
        content: this.sketch,
        container: "tools",
      });
      this.measurement = new Measurement({
        view: view,
      });
      this.LayerManager = new LayerManager(map, view);
      this.LayerManager.init(
        FeatureLayer,
        GeoJSONLayer,
        LabelClass,
        GroupLayer
      );
      this.GisMgr = new GISManager(map, view);
      this.CustomPopupComponent = new CustomPopupComponent();
      view.popup.on("trigger-action", function (event) {
        if (event.action.id === "measure-this") {
          console.log("Measure");
        }
      });
      view.on(
        "click",
        function (evt) {
          let screenPoint = evt.screenPoint;
          view.hitTest(screenPoint).then((response) => {
            if (response.results.length != 0) {
              let graphic = response.results[0].graphic;
              console.log(graphic.attributes);
              console.log(response.results[0]);
              console.log(graphic);
              this.displayComponent = true;
              // this.router.navigate(['./custom-popup/custom-popup.component']);
              // this.zone.run(() => this.router.navigate(['./custom-popup/custom-popup.component']));
            } else {
              let coordinate = {};
              coordinate["longitude"] = evt.mapPoint.longitude;
              coordinate["latitude"] = evt.mapPoint.latitude;
              this.gisService.setCoordinate(coordinate);
              view.graphics.removeAll();
              const point = {
                type: "point", // autocasts as new Point()
                longitude: coordinate["longitude"],
                latitude: coordinate["latitude"],
              };

              const markerSymbol = {
                type: "simple-marker",
                color: [226, 119, 40],
                outline: {
                  color: [255, 255, 255],
                  width: 2,
                },
              };

              const pointGraphic = new Graphic({
                geometry: point,
                symbol: markerSymbol,
              });
              view.graphics.add(pointGraphic);
            }
          });
        }.bind(this)
      );

      this.view = view;
      return this.GisMgr;
    } catch (error) {
      console.error("EsriLoader: ", error);
    }
  }

  AddUpdateAlertsOnMap = () => {
    let alertData: any;
    this.gisService.getAlertData().subscribe((data) => {
      alertData = data;
    });
    this.GisMgr.AddUpdateAlertsOnMap(alertData);
  };

  AddUpdateSWMOnMap = () => {
    let swmData: any;
    this.gisService.getSWMData().subscribe((data) => {
      swmData = data;
    });
    this.GisMgr.AddUpdateSWMOnMap(swmData);
  };

  AddUpdateATCSOnMap = () => {
    let atcsData: any;
    this.gisService.getATCSData().subscribe((data) => {
      atcsData = data;
    });
    this.GisMgr.AddUpdateATCSOnMap(atcsData);
  };

  AddUpdateATCSLineOnMap = () => {
    let atcsLineData: any;
    this.gisService.getATCSLineData().subscribe((data) => {
      atcsLineData = data;
    });
    this.GisMgr.AddUpdateATCSLineOnMap(atcsLineData);
  };

  AddUpdateVMSOnMap = () => {
    let vmsData: any;
    this.gisService.getVMSData().subscribe((data) => {
      vmsData = data;
    });
    this.GisMgr.AddUpdateVMSOnMap("SmartCamera", vmsData);
  };

  AddUpdateMileStoneVMSOnMap = () => {
    let milestoneVMSData: any;
    this.gisService.getMileStoneVMSData().subscribe((data) => {
      milestoneVMSData = data;
    });
    this.GisMgr.AddUpdateVMSOnMap("SmartMileStoneVMS", milestoneVMSData);
  };

  HighlightPointsOnMap = () => {
    let highlightData = null;
    let srid = 4326;
    this.gisService
      .getHighlightData()
      .subscribe((data) => (highlightData = data));
    if (Object.keys(highlightData).length !== 0) {
      if (highlightData.projection === "ESPG:3857") {
        srid = 3857;
      } else {
        if (highlightData.projection === "ESPG:4326") {
          srid = 4326;
        }
      }
      this.view
        .goTo(
          {
            position: {
              x: highlightData.coordinates[0],
              y: highlightData.coordinates[1],
              z: 7000,
              spatialReference: {
                wkid: srid,
              },
            },
            heading: 0,
            tilt: 0,
          },
          {
            speedFactor: 0.6,
          }
        )
        .catch(() => {});
    }
  };

  onToolsClick(): void {
    this.isToolShow = !this.isToolShow;
    if (this.isToolShow === true) {
      this.view.ui.add(this.sketch, "manual");
      this.view.ui.add(this.measurement, "bottom-trailing");
    } else {
      this.view.ui.remove(this.sketch);
      this.view.ui.remove(this.measurement);
    }
  }

  onLayersClick(): void {
    this.isLayerShow = !this.isLayerShow;
    if (this.isLayerShow === true) {
      this.view.ui.add(this.layerList, "top-left");
    } else {
      this.view.ui.remove(this.layerList);
    }
  }

  onSearchClick(): void {
    this.isSearchShow = !this.isSearchShow;
    if (this.isSearchShow === true) {
      this.view.ui.add(this.search, "top-left");
    } else {
      this.view.ui.remove(this.search);
    }
  }

  onMapClick(): void {
    this.isMapShow = !this.isMapShow;
    if (this.isMapShow === true) {
      this.view.ui.add(this.basemapGallery, "manual");
    } else {
      this.view.ui.remove(this.basemapGallery);
    }
  }

  ngOnInit(): void {
    this.initializeMap().then(() => {
      this.AddUpdateAlertsOnMap();
      this.HighlightPointsOnMap();
      this.AddUpdateSWMOnMap();
      this.AddUpdateATCSOnMap();
      this.AddUpdateATCSLineOnMap();
      this.AddUpdateVMSOnMap();
      this.AddUpdateMileStoneVMSOnMap();
    });
  }

  ngOnDestroy(): void {
    if (this.view) {
      // destroy the map view
      this.view.container = null;
    }
  }
}
