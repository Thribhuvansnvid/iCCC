export default class LayerManager {
  map: any;
  view: any;

  constructor(map: any, view: any) {
    this.map = map;
    this.view = view;
  }

  init = (
    FeatureLayer: any,
    GeoJSONLayer: any,
    LabelClass: any,
    GroupLayer: any
  ) => {
    this.CreateIndiaLayer(GeoJSONLayer);
    this.CreateWardLayer(GeoJSONLayer);
    this.CreateVMSLayer(FeatureLayer);
    this.CreateAlertsLayer(FeatureLayer);
    this.CreateEnvironmentLayer(FeatureLayer, LabelClass);
    this.CreateSolidWasteLayer(FeatureLayer);
    this.CreateParkingLayer(FeatureLayer);
    this.CreateATCSLayer(FeatureLayer, GroupLayer);
    this.CreateTransportLayer(FeatureLayer);
    this.CreateSignBoardLayer(FeatureLayer);
    this.CreateVehicleLayer(FeatureLayer);
    this.CreateComplLayer(FeatureLayer);
  };

  CreateIndiaLayer = (GeoJSONLayer: any) => {
    const lineRenderer = {
      type: "simple",
      symbol: {
        type: "simple-line",
        color: "lightblue",
        width: "5px",
      },

      label: "India boundaries",
    };
    const wardLayer = new GeoJSONLayer();
    wardLayer.id = "indiaborder";
    wardLayer.title = "India";
    wardLayer.url = "/assets/gisdata/india-land-simplified.geojson";
    wardLayer.renderer = lineRenderer;

    this.map.layers.add(wardLayer);
  };

  CreateWardLayer = (GeoJSONLayer: any) => {
    var polyRenderer = {
      type: "simple", // autocasts as new SimpleRenderer()
      symbol: {
        type: "simple-fill", // autocasts as new SimpleFillSymbol()
        style: "solid",
        color: [227, 154, 116, 0.2],

        outline: {
          width: 1,
          color: [45, 142, 106, 1],
        },
      },

      label: "Ward boundaries",
    };

    const wardLayer = new GeoJSONLayer({
    
      id: "Ward",
      title: "Bangalore ward",
      url: "/assets/gisdata/Bangalore/BBMP.GeoJSON",
      renderer: polyRenderer,
    });

    this.map.layers.add(wardLayer);
  };
  CreateEnvironmentLayer = (FeatureLayer: any, LabelClass: any) => {
    const template = {
      title: "Air Quality Index {aqi}",
      content: [
        {
          type: "fields",
          fieldInfos: [
            {
              fieldName: "deviceid",
              label: "Device ID",
            },
            {
              fieldName: "healthImpacts",
              label: "Health Impact",
            },
            {
              fieldName: "area",
              label: "Area",
            },
            {
              fieldName: "remarks",
              label: "Remarks",
            },
          ],
        },
      ],
    };
    const objectSymbol = {
      type: "point-3d", // autocasts as new PointSymbol3D()
      symbolLayers: [
        {
          type: "object", // autocasts as new ObjectSymbol3DLayer()
          width: 100.0,
          material: { color: "white" },
          resource: { primitive: "cylinder" },
        },
      ],
    };

    const objectSymbolRenderer = {
      type: "simple", // autocasts as new SimpleRenderer()
      symbol: objectSymbol,
      visualVariables: [
        {
          type: "color",
          field: "aqi",
          stops: [
            { value: 0, color: "#cccccc", f: "#ffffff" },
            { value: 50, color: "#00B050", f: "#ffffff" },
            { value: 100, color: "#ffff00", f: "#000000" },
            { value: 150, color: "#FFA500", f: "#000000" },
            { value: 200, color: "#FF0000", f: "#ffffff" },
            { value: 300, color: "#800080", f: "#ffffff" },
            { value: 500, color: "#800000", f: "#ffffff" },
          ],
        },
        {
          type: "size",
          field: "aqi",
          axis: "height",
          minDataValue: 0,
          maxDataValue: 500,
          maxScale: 0,
          minScale: 0,
        },
        {
          type: "size",
          axis: "width-and-depth",
          useSymbolValue: true,
        },
      ],
    };

    const labelClass = new LabelClass({
      symbol: {
        type: "label-3d", // autocasts as new LabelSymbol3D()
        symbolLayers: [
          {
            type: "text", // autocasts as new TextSymbol3DLayer()
            material: {
              color: "white",
            },
            size: 10,
          },
        ],
      },
      labelPlacement: "above-center",
      labelExpressionInfo: {
        expression: 'DefaultValue($feature.aqi, "no data")',
      },
    });

    const featureLayer = new FeatureLayer({
      id: "SmartEnv",
      objectIdField: "ObjectID",
      fields: [
        {
          name: "deviceid",
          type: "string",
        },
        {
          name: "aqi",
          type: "string",
        },
        {
          name: "color",
          type: "string",
        },
        {
          name: "area",
          type: "string",
        },
        {
          name: "healthImpacts",
          type: "string",
        },
        {
          name: "remarks",
          type: "string",
        },
      ],

      title: "Environment",
      geometryType: "point",
      source: [],
      renderer: objectSymbolRenderer,
      popupTemplate: template,
      outFields: ["*"],
      labelingInfo: [labelClass],
    });
    this.map.layers.add(featureLayer);
  };

  CreateVMSLayer = (FeatureLayer: any) => {
    const cameraRenderer = {
      type: "unique-value",
      field: "healthStatus",
      uniqueValueInfos: [
        {
          value: "healthy",
          symbol: {
            type: "picture-marker",
            url: "/assets/gisdata/images/cctv_green.svg",
            width: "64px",
            height: "64px",
          },
        },
        {
          value: "unhealthy",
          symbol: {
            type: "picture-marker",
            url: "/assets/gisdata/images/cctv_red.svg",
            width: "64px",
            height: "64px",
          },
        },
      ],
    };

    const template = [
      {
        type: "fields",
        fieldInfos: [
          {
            fieldName: "cameraName",
            label: "Camera Name",
          },
          {
            fieldName: "cameraType",
            label: "Camera Type",
          },
          {
            fieldName: "brandName",
            label: "Brand Name",
          },
          {
            fieldName: "healthStatus",
            label: "Health Status",
          },
        ],
      },
      {
        type: "media",
        mediaInfos: [
          {
            title: "<b>CCTV Camera</b>",
            type: "image",
            caption: "Camera Image",

            value: {
              sourceURL:
                "https://www.sunset.com/wp-content/uploads/96006df453533f4c982212b8cc7882f5-800x0-c-default.jpg",
            },
          },
        ],
      },
      {
        type: "attachments",
        displayType: "list",
        attachmentInfos: [
          {
            name: "View Feed",
            url: "https://www.youtube.com/watch?v=_sBcbDZKcVU",
          },
        ],
      },
    ];

    const feature = [
      {
        geometry: {
          type: "point",
          spatialReferance: 4326,
        },
        attributes: {},
      },
    ];

    const featureLayer = new FeatureLayer({
      id: "SmartMileStoneVMS",
      objectIdField: "ObjectID",
      fields: [
        {
          name: "layername",
          type: "string",
        },
        {
          name: "cameraid",
          type: "string",
        },
        {
          name: "cameraName",
          type: "string",
        },
        {
          name: "cameraType",
          type: "string",
        },
        {
          name: "brandName",
          type: "string",
        },
        {
          name: "healthStatus",
          type: "string",
        },
      ],

      title: "Mile Stone VMS",
      geometryType: "point",
      source: [],
      renderer: cameraRenderer,
      popupTemplate: template,
      outFields: ["*"],
    });

    this.map.layers.add(featureLayer);
  };

  CreateAlertsLayer = (FeatureLayer: any) => {
    const alertSimpleRenderer = {
      type: "unique-value",
      field: "type",
      uniqueValueInfos: [
        {
          value: "RL",
          symbol: {
            type: "picture-marker",
            url: "assets/gisdata/images/parking.svg",
            width: "32px",
            height: "32px",
          },
        },
        {
          value: "SP",
          symbol: {
            type: "picture-marker",
            url: "assets/gisdata/images/parking(1).svg",
            width: "32px",
            height: "32px",
          },
        },
        {
          value: "OT",
          symbol: {
            type: "picture-marker",
            url: "assets/gisdata/images/parking(2).svg",
            width: "32px",
            height: "32px",
          },
        },
      ],
    };

    const template = {
      title: "Properties for Alerts {type}",
      content: [
        {
          type: "fields",
          fieldInfos: [
            {
              fieldName: "type",
              label: "Type",
            },
            {
              fieldName: "speed",
              label: "Speed",
            },
          ],
        },
      ],
    };
    const feature = [
      {
        geometry: {
          type: "point",
          spatialReferance: 4326,
        },
        attributes: {},
      },
    ];
    const featureLayer = new FeatureLayer({
      id: "SmartAlert",
      objectIdField: "ObjectID",
      fields: [
        {
          name: "layername",
          type: "string",
        },
        {
          name: "Type",
          type: "string",
        },
        {
          name: "Speed",
          type: "string",
        },
      ],

      title: "Alerts",
      geometryType: "point",
      source: [],
      renderer: alertSimpleRenderer,
      popupTemplate: template,
      outFields: ["*"],
    });
    this.map.layers.add(featureLayer);
  };

  CreateSolidWasteLayer = (FeatureLayer: any) => {
    var measureThisAction = {
      title: "Measure Length",
      id: "measure-this",
      
    };
    const swmRenderFont = {
      // .flaticon-rubbish-bin-1
      type: "unique-value",
      field: "id",
      uniqueValueInfos: [
        {
          value: "1",
          symbol: {
            type: "text",
            color: "#ff0000",
            text: "\ue677",
            font: {
              size: 20,
              family: "CalciteWebCoreIcons",
            },
          },
        },
        {
          value: "2",
          symbol: {
            type: "text",
            color: "#00FF00",
            text: "\ue677",
            font: {
              size: 20,
              family: "CalciteWebCoreIcons",
            },
          },
        },
        {
          value: "3",
          symbol: {
            type: "text",
            color: "#808080",
            text: "\ue677",
            font: {
              size: 20,
              family: "CalciteWebCoreIcons",
            },
          },
        },
      ],
      
    };
    const template = {
      title: "Properties for {tagno}",
      outFields: ["*"],
      content: [
        {
          type: "fields",
          fieldInfos: [
            {
              fieldName: "area",
              label: "Area",
            },
            {
              fieldName: "tdate",
              label: "Date",
            },
            {
              fieldName: "city",
              label: "City",
            },
            {
              fieldName: "name",
              label: "Name",
            },
            {
              fieldName: "region_name",
              label: "Region Name",
            },
            {
              fieldName: "readerid",
              label: "Reader ID",
            },
            {
              fieldName: "propertyid",
              label: "Property ID",
            },
            {
              fieldName: "contactno",
              label: "Contact No",
            },
          ],
        },
      ],
      actions: [measureThisAction]
    };
    const featureLayer = new FeatureLayer({
      id: "smartSWMLayer",
      objectIdField: "ObjectID",
      fields: [
        {
          name: "layername",
          type: "string",
        },
        {
          name: "area",
          type: "string",
        },
        {
          name: "tdate",
          type: "string",
        },
        {
          name: "city",
          type: "string",
        },
        {
          name: "name",
          type: "string",
        },
        {
          name: "region_name",
          type: "string",
        },
        {
          name: "id",
          type: "string",
        },
        {
          name: "tagno",
          type: "string",
        },
        {
          name: "readerid",
          type: "string",
        },
        {
          name: "propertyid",
          type: "string",
        },
        {
          name: "contactno",
          type: "string",
        },
      ],

      title: "Solid Waste Management",
      geometryType: "point",
      source: [],
      renderer: swmRenderFont,
      popupTemplate: template,
      outFields: ["*"],
    });
    this.map.layers.add(featureLayer);
  };

  CreateParkingLayer = (FeatureLayer: any) => {
    const symbolRenderer = {
      type: "unique-value",
      field: "Free",
      uniqueValueInfos: [
        {
          value: "A",
          symbol: {
            type: "picture-marker",
            url: "assets/gisdata/images/parking.svg",
            width: "32px",
            height: "32px",
          },
        },
        {
          value: "NA",
          symbol: {
            type: "picture-marker",
            url: "assets/gisdata/images/parking(1).svg",
            width: "32px",
            height: "32px",
          },
        },
        {
          value: "P",
          symbol: {
            type: "picture-marker",
            url: "assets/gisdata/images/parking(2).svg",
            width: "32px",
            height: "32px",
          },
        },
      ],
    };
    const template = {
      title: "Properties for Parking at {Mall Name}",
      outFields: ["*"],
      content: [
        {
          type: "fields",
          fieldInfos: [
            {
              fieldName: "id",
              label: "id",
            },
            {
              fieldName: "Mall Name",
              label: "Mall Name",
            },
            {
              fieldName: "Free",
              label: "Free",
            },
            {
              fieldName: "Occupied",
              label: "Occupied",
            },
            {
              fieldName: "Has Camera",
              label: "Has Camera",
            },
            {
              fieldName: "Has Led",
              label: "Has Led",
            },
            {
              fieldName: "Lot Code",
              label: "Lot Code",
            },
            {
              fieldName: "Street",
              label: "Street",
            },
            {
              fieldName: "Sub Zone",
              label: "Sub Zone",
            },
            {
              fieldName: "City",
              label: "City",
            },
            {
              fieldName: "Pin Code",
              label: "Pin Code",
            },
            {
              fieldName: "Spot_name",
              label: "Spot_name",
            },
            {
              fieldName: "Lastintime",
              label: "Lastintime",
            },
            {
              fieldName: "Lastouttime",
              label: "Lastouttime",
            },
            {
              fieldName: "Sensor_id",
              label: "Sensor_id",
            },

            {
              fieldName: "Spot_online",
              label: "Spot_online",
            },
            {
              fieldName: "StartTime",
              label: "StartTime",
            },
          ],
        },
      ],
    };
    const featureLayer = new FeatureLayer({
      id: "SmartParking",
      objectIdField: "ObjectID",
      fields: [
        {
          name: "layername",
          type: "string",
        },
        {
          name: "id",
          type: "string",
        },
        {
          name: "Free",
          type: "string",
        },
        {
          name: "End Time",
          type: "string",
        },
        {
          name: "Bay Count",
          type: "string",
        },
        {
          name: "Occupied",
          type: "string",
        },
        {
          name: "Has Camera",
          type: "string",
        },
        {
          name: "Has Led",
          type: "string",
        },
        {
          name: "Lot Code",
          type: "string",
        },
        {
          name: "Mall Name",
          type: "string",
        },
        {
          name: "Street",
          type: "string",
        },
        {
          name: "Sub Zone",
          type: "string",
        },
        {
          name: "City",
          type: "string",
        },
        {
          name: "Pin Code",
          type: "string",
        },
        {
          name: "Spot_name",
          type: "string",
        },
        {
          name: "Lastintime",
          type: "string",
        },

        {
          name: "Lastouttime",
          type: "string",
        },
        {
          name: "Sensor_id",
          type: "string",
        },
        {
          name: "Spot_online",
          type: "string",
        },
        {
          name: "StartTime",
          type: "string",
        },
      ],

      title: "Parking",
      geometryType: "point",
      source: [],
      renderer: symbolRenderer,
      popupTemplate: template,
      outFields: ["*"],
      featureReduction: {
        type: "cluster",
        clusterRadius: "100px",
      },
    });
    this.map.layers.add(featureLayer);
  };

  CreateATCSLayer = (FeatureLayer: any, GroupLayer: any) => {
    const atcsRenderer = {
      type: "unique-value",
      field: "signal",
      uniqueValueInfos: [
        {
          value: "Red",
          symbol: {
            type: "picture-marker",
            url: "assets/gisdata/images/traffic_red.svg",
            width: "32px",
            height: "32px",
          },
        },
        {
          value: "Green",
          symbol: {
            type: "picture-marker",
            url: "assets/gisdata/images/traffic_green.svg",
            width: "32px",
            height: "32px",
          },
        },
        {
          value: "Yellow",
          symbol: {
            type: "picture-marker",
            url: "assets/gisdata/images/traffic_yellow.svg",
            width: "32px",
            height: "32px",
          },
        },
      ],
    };

    const template = {
      title: "Properties for Traffic Signals",
      content: [
        {
          type: "fields",
          fieldInfos: [
            {
              fieldName: "Junction_name",
              label: "Junction name",
            },
            {
              fieldName: "signal",
              label: "Signal",
            },
            {
              fieldName: "health_status",
              label: "Health Status",
            },
            {
              fieldName: "connectivity_Status",
              label: "Connectivity Status",
            },
            {
              fieldName: "occupancy_level",
              label: "Occupancy Level",
            },
            {
              fieldName: "faulty_timer",
              label: "Faulty Timer",
            },
            {
              fieldName: "mode_of_operation",
              label: "Mode of Operation",
            },
          ],
        },
      ],
      outFields: ["*"],
    };

    const atcsPoint = new FeatureLayer({
      id: "SmartATCS",
      objectIdField: "ObjectID",
      fields: [
        {
          name: "layername",
          type: "string",
        },
        {
          name: "id",
          type: "string",
        },
        {
          name: "Junction_name",
          type: "string",
        },
        {
          name: "signal",
          type: "string",
        },
        {
          name: "health_status",
          type: "string",
        },
        {
          name: "connectivity_Status",
          type: "string",
        },
        {
          name: "occupancy_level",
          type: "string",
        },
        {
          name: "faulty_timer",
          type: "string",
        },
        {
          name: "mode_of_operation",
          type: "string",
        },
      ],

      title: "Traffic Signals",
      geometryType: "point",
      source: [],
      renderer: atcsRenderer,
      popupTemplate: template,
      outFields: ["*"],
    });

    // const features =
    //   {
    //     geometry: {
    //       type: 'polyline',
    //      paths: [[-0.178, 51.48791, 0],
    //      [-0.178, 51.48791, 1000]]
    //     },
    //     attributes: {
    //       ObjectID: 1,
    //       DepArpt: 'KATL',
    //       MsgTime: Date.now(),
    //       FltId: 'UAL1'
    //     }
    //   };

    const atcsLine = new FeatureLayer({
      id: "SmartATCSLine",
      objectIdField: "ObjectID",
      fields: [
        {
          name: "layername",
          type: "string",
        },
        {
          name: "id",
          type: "string",
        },
        {
          name: "direction",
          type: "string",
        },
        {
          name: "occupancy",
          type: "string",
        },
      ],

      title: "Route Occupancy",
      geometryType: "polyline",
      source: [],

      renderer: {
        type: "simple",
        symbol: {
          type: "simple-line",
          color: "green",
          width: "5px",
        },
      },
    });

    const atcsLayer = new GroupLayer({
      title: "ATCS",
      visible: true,
      visibilityMode: "independent",
      layers: [atcsPoint, atcsLine],
      opacity: 0.75,
    });
    this.map.layers.add(atcsLayer);
  };

  CreateTransportLayer = (FeatureLayer: any) => {
    const vehicleRenderer = {
      type: "unique-value",
      field: "vehicletype",
      uniqueValueInfos: [
        {
          value: "Car",
          symbol: {
            type: "picture-marker",
            url: "images/gisdata/vehicle.png",
            width: "24px",
            height: "32px",
          },
        },
        {
          value: "Truck",
          symbol: {
            type: "picture-marker",
            url: "images/gisdata/truck.png",
            width: "24px",
            height: "32px",
          },
        },
        {
          value: "Bus",
          symbol: {
            type: "picture-marker",
            url: "images/gisdata/bus(2).svg",
            width: "16px",
            height: "16px",
          },
        },
      ],
      visualVariables: [
        {
          type: "rotation",
          field: "orientation",
          rotationType: "geographic",
        },
      ],
    };

    const template = {
      title: "Properties for Vehicle {vehicleName}",
      content: [
        {
          type: "fields",
          fieldInfos: [
            {
              fieldName: "vehicletype",
              label: "Type of Vehicle",
            },
          ],
        },
      ],
    };
    const feature = [
      {
        geometry: {
          type: "point",
          spatialReferance: 4326,
        },
        attributes: {},
      },
    ];
    const featureLayer = new FeatureLayer({
      id: "SmartVehicle",
      objectIdField: "ObjectID",
      fields: [
        {
          name: "layername",
          type: "string",
        },
        {
          name: "vehicleName",
          type: "string",
        },
        {
          name: "orientation",
          type: "string",
        },
        {
          name: "vehicletype",
          type: "string",
        },
      ],

      title: "Vehicle",
      geometryType: "point",
      source: [],
      renderer: vehicleRenderer,
      popupTemplate: template,
      outFields: ["*"],
    });
    this.map.layers.add(featureLayer);
  };

  CreateSignBoardLayer = (FeatureLayer: any) => {
    const signBoardRenderer = {
      type: "unique-value",
      field: "path",
      uniqueValueInfos: [
        {
          value: "1",
          symbol: {
            type: "picture-marker",
            url: "/assets/gisdata/images/hotel(1).svg",
            width: "64px",
            height: "64px",
          },
        },
        {
          value: "2",
          symbol: {
            type: "picture-marker",
            url: "/assets/gisdata/images/hotel(2).svg",
            width: "64px",
            height: "64px",
          },
        },
        {
          value: "3",
          symbol: {
            type: "picture-marker",
            url: "/assets/gisdata/images/hotel(3).svg",
            width: "64px",
            height: "64px",
          },
        },
        {
          value: "4",
          symbol: {
            type: "picture-marker",
            url: "/assets/gisdata/images/hotel(4).svg",
            width: "64px",
            height: "64px",
          },
        },
        {
          value: "5",
          symbol: {
            type: "picture-marker",
            url: "/assets/gisdata/images/hotel(5).svg",
            width: "64px",
            height: "64px",
          },
        },
      ],
    };

    const template = {
      title: "Properties for Sign Board {vmdid}",
      content: [
        {
          type: "fields",
          fieldInfos: [
            {
              fieldName: "vmdid",
              label: "Vmd ID",
            },
            {
              fieldName: "messageDisplayed",
              label: "Message Displayed",
            },
            {
              fieldName: "areaname",
              label: "Area Name",
            },
          ],
        },
      ],
    };
    
    var featureLayer = new FeatureLayer({
      id: "SmartSignBoard",
      objectIdField: "ObjectID",
      fields: [
        {
          name: "vmdid",
          type: "string",
        },
        {
          name: "messageDisplayed",
          type: "string",
        },
        {
          name: "path",
          type: "string",
        },
        {
          name: "areaname",
          type: "string",
        },
      ],

      title: "Sign Board",
      geometryType: "point",
      source: [],
      renderer: signBoardRenderer,
      popupTemplate: template,
      outFields: ["*"],
      featureReduction: {
        type: "selection",
      },
    });
    this.map.layers.add(featureLayer);
  };

  CreateVehicleLayer = (FeatureLayer: any) => {
    const vehicleRenderer = {
      type: "unique-value",
      field: "vehicletype",

      uniqueValueInfos: [
        {
          value: "Car",
          symbol: {
            type: "picture-marker",
            url: "/assets/gisdata/images/vehicle.png",
            width: "24px",
            height: "32px",
          },
        },
        {
          value: "Truck",
          symbol: {
            type: "picture-marker",
            url: "/assets/gisdata/images/tipper_truck.png",
            width: "24px",
            height: "32px",
          },
        },
        {
          value: "Bus",
          symbol: {
            type: "picture-marker",
            url: "/assets/gisdata/images/bus(2).svg",
            width: "32px",
            height: "32px",
          },
        },
      ],
      visualVariables: [
        {
          type: "rotation",
          field: "orientation",
          rotationType: "geographic",
        },
      ],
    };

    const template = {
      title: "Properties for Vehicle {vehicleName}",
      content: [
        {
          type: "fields",
          fieldInfos: [
            {
              fieldName: "vehicletype",
              label: "Type of Vehicle",
            },
            {
              fieldName: "orientation",
              label: "orientation",
            },
          ],
        },
      ],
    };
    

    const featureLayer = new FeatureLayer({
      id: "SmartVehicle",
      objectIdField: "ObjectID",
      fields: [
        {
          name: "vehicleName",
          type: "string",
        },
        {
          name: "orientation",
          type: "string",
        },
        {
          name: "vehicletype",
          type: "string",
        },
      ],

      title: "Vehicle",
      geometryType: "point",
      source: [],
      renderer: vehicleRenderer,
      popupTemplate: template,
      outFields: ["*"],
      featureReduction: {
        type: "selection",
      },
     
    });
    this.map.layers.add(featureLayer);
  };

  CreateComplLayer = (FeatureLayer: any) => {
    const compSimpleRenderer = {
      type: "unique-value",
      field: "severity",
      uniqueValueInfos: [
        {
          value: "high",
          symbol: {
            type: "picture-marker",
            url: "images/comp_red.svg",
            width: "32px",
            height: "32px",
          },
        },
        {
          value: "medium",
          symbol: {
            type: "picture-marker",
            url: "images/comp_yellow.svg",
            width: "32px",
            height: "32px",
          },
        },
        {
          value: "low",
          symbol: {
            type: "picture-marker",
            url: "images/comp_green.svg",
            width: "32px",
            height: "32px",
          },
        },
        {
          value: "HIGH",
          symbol: {
            type: "picture-marker",
            url: "images/comp_red.svg",
            width: "32px",
            height: "32px",
          },
        },
        {
          value: "MEDIUM",
          symbol: {
            type: "picture-marker",
            url: "images/comp_yellow.svg",
            width: "32px",
            height: "32px",
          },
        },
        {
          value: "LOW",
          symbol: {
            type: "picture-marker",
            url: "images/comp_green.svg",
            width: "32px",
            height: "32px",
          },
        },
        {
          value: "NA",
          symbol: {
            type: "picture-marker",
            url: "images/alert.jpg",
            width: "32px",
            height: "32px",
          },
        },
      ],
    };

    const template = {
      title: "Properties for Complaint",
      content: [
        {
          type: "fields",
          fieldInfos: [
            {
              fieldName: "state_name",
              label: "State Name",
            },
            {
              fieldName: "district_city",
              label: "District City",
            },
            {
              fieldName: "ward_name",
              label: "Ward Name",
            },
            {
              fieldName: "area_village",
              label: "Area Village",
            },
            {
              fieldName: "complaint_id",
              label: "Complaint ID",
            },
            {
              fieldName: "smart_vertical",
              label: "Smart Vertical",
            },
            {
              fieldName: "complaint_status",
              label: "Complaint Status",
            },
            {
              fieldName: "description",
              label: "Description",
            },
            {
              fieldName: "received_time",
              label: "Received Time",
            },
            {
              fieldName: "severity",
              label: "Severity",
            },
            {
              fieldName: "sop_status",
              label: "SOP Status",
            },
          ],
        },
      ],
    };
    
    const featureLayer = new FeatureLayer({
      id: "SmartComp",
      objectIdField: "ObjectID",
      fields: [
        {
          name: "state_name",
          type: "string",
        },
        {
          name: "district_city",
          type: "string",
        },
        {
          name: "ward_name",
          type: "string",
        },
        {
          name: "area_village",
          type: "string",
        },
        {
          name: "complaint_id",
          type: "string",
        },
        {
          name: "smart_vertical",
          type: "string",
        },
        {
          name: "complaint_status",
          type: "string",
        },
        {
          name: "description",
          type: "string",
        },
        {
          name: "received_time",
          type: "string",
        },
        {
          name: "severity",
          type: "string",
        },
        {
          name: "sop_status",
          type: "string",
        },
      ],

      title: "Complaint",
      geometryType: "point",
      source: [],
      renderer: compSimpleRenderer,
      popupTemplate: template,
      outFields: ["*"],
      featureReduction: {
        type: "selection",
      },
    });
    this.map.layers.add(featureLayer);
  };
}
