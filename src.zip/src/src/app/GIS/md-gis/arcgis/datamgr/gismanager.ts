export class GISManager {
  view: any;
  map: any;

  constructor(map: undefined, view: undefined) {
    this.map = map;
    this.view = view;
  }

  AddUpdateAlertsOnMap = (data: any) => {
    if (Object.keys(data).length !== 0) {
      const layer = this.map.findLayerById("SmartAlert");
      const featuresAdd = data.features.map((feature, i) => {
        return {
          geometry: {
            type: "point",
            spatialReference: 4326,
            x: feature.geometry.coordinates[0],
            y: feature.geometry.coordinates[1],
          },
          attributes: {
            layername: "SmartAlert",
            type: feature.properties.type,
            speed: feature.properties.speed,
          },
        };
      });

      const addEdits = {
        addFeatures: featuresAdd,
      };

      layer
        .applyEdits(addEdits)
        .then((editsResult) => {
          console.log("Features Added in " + layer.title + " layer.");
        })
        .catch((error) => {
          console.log("===============================================");
          console.error(
            "[ applyEdits ] FAILURE: ",
            error.code,
            error.name,
            error.message
          );
          console.log("error = ", error);
        });
    }
  };

  AddUpdateSWMOnMap = (data: any) => {
    if (Object.keys(data).length !== 0) {
      const layer = this.map.findLayerById("smartSWMLayer");
      const featuresAdd = data.features.map((feature, i) => {
        return {
          geometry: {
            type: "point",
            spatialReference: 4326,
            x: feature.geometry.coordinates[0],
            y: feature.geometry.coordinates[1],
          },
          attributes: {
            layername: "smartSWMLayer",
            area: feature.properties.area,
            tdate: feature.properties.tdate,
            city: feature.properties.city,
            name: feature.properties.name,
            region_name: feature.properties.region_name,
            id: feature.properties.id,
            tagno: feature.properties.tagno,
            readerid: feature.properties.readerid,
            propertyid: feature.properties.propertyid,
            contactno: feature.properties.contactno,
          },
        };
      });

      const addEdits = {
        // deleteFeatures: removeFeatures,
        addFeatures: featuresAdd,
      };

      layer
        .applyEdits(addEdits)
        .then((editsResult) => {
          console.log("Features Added in " + layer.title + " layer.");
        })
        .catch((error) => {
          console.log("===============================================");
          console.error(
            "[ applyEdits ] FAILURE: ",
            error.code,
            error.name,
            error.message
          );
          console.log("error = ", error);
        });
    }
  };

  AddUpdateATCSOnMap = (data: any) => {
    if (Object.keys(data).length !== 0) {
      const layer = this.map.findLayerById("SmartATCS");
      const featuresAdd = data.features.map((feature, i) => {
        if (feature.properties.projection === "ESPG:3857") {
          feature.properties.projection = 3857;
        } else {
          if (feature.properties.projection === "ESPG:4326") {
            feature.properties.projection = 4326;
          }
        }

        return {
          geometry: {
            type: "point",
            spatialReference: { wkid: feature.properties.projection },
            x: feature.geometry.coordinates[0],
            y: feature.geometry.coordinates[1],
          },
          attributes: {
            layername: "SmartATCS",
            id: feature.properties.id,
            Junction_name: feature.properties.Junction_name,
            signal: feature.properties.signal,
            health_status: feature.properties.health_status,
            connectivity_Status: feature.properties.connectivity_Status,
            occupancy_level: feature.properties.occupancy_level,
            faulty_timer: feature.properties.faulty_timer,
            mode_of_operation: feature.properties.mode_of_operation,
          },
        };
      });

      const addEdits = {
        // deleteFeatures: removeFeatures,
        addFeatures: featuresAdd,
      };

      layer
        .applyEdits(addEdits)
        .then((editsResult) => {
          console.log("Features Added in " + layer.title + " layer.");
        })
        .catch((error) => {
          console.log("===============================================");
          console.error(
            "[ applyEdits ] FAILURE: ",
            error.code,
            error.name,
            error.message
          );
          console.log("error = ", error);
        });
    }
  };

  AddUpdateATCSLineOnMap = (data) => {
    if (Object.keys(data).length !== 0) {
      const layer = this.map.findLayerById("SmartATCSLine");
      const featuresAdd = data.features.map((feature, i) => {
        if (feature.geometry.projection === "ESPG:3857") {
          feature.geometry.projection = 3857;
        } else {
          if (feature.geometry.projection === "ESPG:4326") {
            feature.geometry.projection = 4326;
          }
        }
        return {
          geometry: {
            type: "polyline",
            spatialReference: { wkid: feature.geometry.projection },
            paths: feature.geometry.coordinates,
          },
          attributes: {
            layername: "SmartATCSLine",
            id: feature.properties.id,
            direction: feature.properties.direction,
            occupancy: feature.properties.occupancy,
          },
        };
      });
      const addEdits = {
        // deleteFeatures: removeFeatures,
        addFeatures: featuresAdd,
      };

      layer
        .applyEdits(addEdits)
        .then((editsResult) => {
          console.log("Features Added in " + layer.title + " layer.");
        })
        .catch((error) => {
          console.log("===============================================");
          console.error(
            "[ applyEdits ] FAILURE: ",
            error.code,
            error.name,
            error.message
          );
          console.log("error = ", error);
        });
    }
  };
  AddUpdateVMSOnMap = (layerName: any, data: any) => {
    if (Object.keys(data).length !== 0) {
      const layer = this.map.findLayerById(layerName);
      const query = layer.createQuery();

      $.each(data.vmsCctv, function (ind, feature) {
        query.where = "cameraid = '" + feature.cameraid + "'";
        query.outFields = ["*"];

        layer.queryFeatures(query).then(function (results) {
          console.log("Features existing: " + results.features.length);
          let pos = JSON.parse("[" + feature.position + "]");
          const featuresAdd = [];
          const featuresUpdate = [];

          const graphic = {
            geometry: {
              type: "point",
              x: pos[0],
              y: pos[1],
            },
            attributes: {
              layername: layerName,
              cameraid: feature.cameraid,
              cameraName: feature.cameraName,
              cameraType: feature.cameraType,
              brandName: feature.brandName,
              healthStatus: feature.healthStatus,
            },
          };
          console.log(graphic);
          if (results.features.length == 0) {
            console.log("NS");
            featuresAdd.push(graphic);
          } else {
            console.log("Updating features");
            results.features[0].geometry.x = pos[0];
            results.features[0].geometry.y = pos[1];
            results.features[0].attributes.cameraName = feature.cameraName;
            results.features[0].attributes.cameraType = feature.cameraType;
            results.features[0].attributes.brandName = feature.brandName;
            results.features[0].attributes.healthStatus = feature.healthStatus;
            featuresUpdate.push(results.features[0]);
          }

          const addEdits = {
            //updateFeatures: featuresUpdate,
            addFeatures: featuresAdd,
          };

          layer
            .applyEdits(addEdits)
            .then(function (editsResult) {
              console.log("Features Added in " + layer.title + " layer.");
            })
            .catch(function (error) {
              console.log("===============================================");
              console.error(
                "[ applyEdits ] FAILURE: ",
                error.code,
                error.name,
                error.message
              );
              console.log("error = ", error);
            });
        });
      });
    }
  };
}
