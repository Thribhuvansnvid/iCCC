// import { TestBed } from '@angular/core/testing';

// import { ArcGISService } from './intf-gis.service';

// describe('arcgisService', () => {
//   let service: ArcGISService;

//   beforeEach(() => {
//     TestBed.configureTestingModule({});
//     service = TestBed.inject(ArcGISService);
//   });

//   it('should be created', () => {
//     expect(service).toBeTruthy();
//   });
// });
