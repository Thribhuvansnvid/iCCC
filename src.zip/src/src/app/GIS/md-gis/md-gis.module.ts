import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ArcgisComponent } from './arcgis/arcgis.component';
import { CustomPopupComponent } from './arcgis/custom-popup/custom-popup.component';
import { OpenlayersComponent } from './openlayers/openlayers.component';



@NgModule({
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  declarations:[ArcgisComponent, CustomPopupComponent, OpenlayersComponent],
  exports:[ArcgisComponent, OpenlayersComponent]
})
export class MdGisModule {}
