import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ComplaintCitizenListComponent } from './complaint-citizen-list.component';

describe('ComplaintCitizenListComponent', () => {
  let component: ComplaintCitizenListComponent;
  let fixture: ComponentFixture<ComplaintCitizenListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ComplaintCitizenListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComplaintCitizenListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
