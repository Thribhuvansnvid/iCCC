import { Component, OnDestroy, OnInit, ViewChild } from "@angular/core";
import { Router } from "@angular/router";
import { Subscription } from "rxjs";
import { Store } from "@ngrx/store";
import * as fromApp from "../../../store/app.reducer";
import { Complaint } from "../../models/complaint.model";
import * as ComplaintsActions from "../../store/complaint.actions";

import { FormGroup, FormControl, FormBuilder } from "@angular/forms";
import { SpinnerOverlayService } from "src/app/shared/spinner-overlay/spinner-overlay.service";
import { User } from "src/app/login/models/user.model";
import { ComplaintStatusDisplayed, ComplaintStatusList } from "../../models/constants";
import { MatTabGroup } from "@angular/material";
import { ComplaintListFilters } from "../../models/complaint.list.filters";

@Component({
  selector: "app-complaint-citizen-list",
  templateUrl: "./complaint-citizen-list.component.html",
  styleUrls: ["./complaint-citizen-list.component.scss"]
})
export class ComplaintCitizenListComponent implements OnInit, OnDestroy {
  private storeSub1: Subscription;
  private storeSub2: Subscription;
  private storeSub3: Subscription;

  loading: boolean = true;
  error: string = "";

  selectedTabIndex = 0;

  _complaintListFilters = new ComplaintListFilters()

  constructor(
    private store: Store<fromApp.AppState>,
    private _router: Router,
    private spinnerOverlayService: SpinnerOverlayService,

  ) { }
  complaints: any[] = [];

  @ViewChild(MatTabGroup, { static: true }) tabGroup: MatTabGroup;
  loggedInUser: User = null
  ngOnInit() {

    this.storeSub1 = this.store
      .select("complaints")
      .subscribe(({ complaints, loading, error, filters }) => {
        this.spinnerOverlayService.hide();
        this.loading = loading;
        this.error = error;
        this._complaintListFilters = filters;
        this.complaints = complaints;
      });

    this.storeSub3 = this.store
      .select("deleteComplaint")
      .subscribe(({ success, loading, error }) => {
        if (success) {
          this.fetchComplaints();
        }
      });
  }

  fetchComplaints() {
    this.spinnerOverlayService.show();
    // this.complaints = []
    this.store.dispatch(
      new ComplaintsActions.ComplaintsFetchStart(this._complaintListFilters)
    );
  }

  onClickComplaint(complaintId) {
    this._router.navigate(["/auth/cg/details", complaintId]);
  }

  ngOnDestroy() {
    this.spinnerOverlayService.hide();
    if (this.storeSub1) {
      this.storeSub1.unsubscribe();
    }
    if (this.storeSub2) {
      this.storeSub2.unsubscribe();
    }
    if (this.storeSub3) {
      this.storeSub3.unsubscribe();
    }
  }

  onClickDeleteComplaint($event, complaintId) {
    $event.stopPropagation();
    this.store.dispatch(
      new ComplaintsActions.ComplaintDeleteStart(complaintId)
    );
  }

  getMessage() {
    return `NO ${this._complaintListFilters.complaintStatusSelected} COMPLAINTS`;
  }

  onTabChanged() {
    if (this.selectedTabIndex === 0) {
      this._complaintListFilters.complaintStatusSelected = ComplaintStatusDisplayed.ALL
    } else if (this.selectedTabIndex === 1) {
      this._complaintListFilters.complaintStatusSelected = ComplaintStatusDisplayed.OPEN
    } else if (this.selectedTabIndex === 2) {
      this._complaintListFilters.complaintStatusSelected = ComplaintStatusDisplayed.CLOSED
    }

    this.fetchComplaints()

  }
}
