import { Component, OnDestroy, OnInit, ViewChild } from "@angular/core";
import { Router } from "@angular/router";
import { Subscription } from "rxjs";
import { Store } from "@ngrx/store";
import * as fromApp from "../../../store/app.reducer";
import { Complaint } from "../../models/complaint.model";
import * as ComplaintsActions from "../../store/complaint.actions";
import { MatDialog, MatTabChangeEvent, MatTabGroup } from "@angular/material";
import { SpinnerOverlayService } from "src/app/shared/spinner-overlay/spinner-overlay.service";
import { ComplaintListFilters } from "../../models/complaint.list.filters";
import { ComplaintStatusDisplayed} from '../../models/constants';
@Component({
  selector: "app-complaints-list",
  templateUrl: "./complaints-list.component.html",
  styleUrls: ["./complaints-list.component.scss"],
})
export class ComplaintsListComponent implements OnInit, OnDestroy {
  private storeSub1: Subscription;
  private storeSub2: Subscription;
  private storeSub3: Subscription;

  loading: boolean = true;
  error: string = "";
  displayingFilters = true;
  selectedTabIndex = 0;

  _complaintListFilters = new ComplaintListFilters()

  constructor(
    private store: Store<fromApp.AppState>,
    private _router: Router,
    private spinnerOverlayService: SpinnerOverlayService,

  ) { }
  complaints: any[] = [];

  @ViewChild(MatTabGroup, { static: true }) tabGroup: MatTabGroup;

  ngOnInit() {
    this.storeSub1 = this.store
      .select("complaints")
      .subscribe(({ complaints, loading, error, filters }) => {
        this.spinnerOverlayService.hide();
        this.loading = loading;
        this.error = error;
        this._complaintListFilters = filters;
        this.complaints = complaints;
      });

    this.storeSub3 = this.store
      .select("deleteComplaint")
      .subscribe(({ success, loading, error }) => {
        if (success) {
          this.fetchComplaints();
        }
      });
  }

  fetchComplaints() {
    this.spinnerOverlayService.show();
    // this.complaints = []
    this.store.dispatch(
      new ComplaintsActions.ComplaintsFetchStart(this._complaintListFilters)
    );
  }

  onClickComplaint(complaintId) {
    this._router.navigate(["/auth/cg/details", complaintId]);
  }

  ngOnDestroy() {
    this.spinnerOverlayService.hide();
    if (this.storeSub1) {
      this.storeSub1.unsubscribe();
    }
    if (this.storeSub2) {
      this.storeSub2.unsubscribe();
    }
    if (this.storeSub3) {
      this.storeSub3.unsubscribe();
    }
  }

  onClickDeleteComplaint($event, complaintId) {
    $event.stopPropagation();
    this.store.dispatch(
      new ComplaintsActions.ComplaintDeleteStart(complaintId)
    );
  }

  getMessage() {
    return `NO ${this._complaintListFilters.complaintStatusSelected} COMPLAINTS`;
  }

  onTabChanged() {
    if (this.selectedTabIndex === 0) {
      this._complaintListFilters.complaintStatusSelected = ComplaintStatusDisplayed.ALL
    }else
    if (this.selectedTabIndex === 1) {
      this._complaintListFilters.complaintStatusSelected = ComplaintStatusDisplayed.UNASSIGNED
    } else if (this.selectedTabIndex === 2) {
      this._complaintListFilters.complaintStatusSelected = ComplaintStatusDisplayed.ASSIGNED
    } else if (this.selectedTabIndex === 3) {
      this._complaintListFilters.complaintStatusSelected = ComplaintStatusDisplayed.CLOSED
    } 

    this.fetchComplaints()

  }

}
