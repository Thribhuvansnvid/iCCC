import { Component, OnDestroy, OnInit } from '@angular/core'
import { ActivatedRoute, Router } from '@angular/router'
import * as fromApp from '../../../store/app.reducer'
import { Store } from '@ngrx/store'
import { Subscription } from 'rxjs'
import { User } from 'src/app/login/models/user.model'

@Component({
  // selector: 'app-complaint-resolved-acknowledge',
  templateUrl: './complaint-resolved-acknowledge.component.html',
  styleUrls: ['./complaint-resolved-acknowledge.component.scss']
})
export class ComplaintResolvedAcknowledgeComponent implements OnInit {

  complaintId: string = ''
  loggedInUser: User = null
  constructor(
    private _activatedRoute: ActivatedRoute,
    
    private store: Store<fromApp.AppState>,
    private _router: Router
  ) {}
  storeSub1: Subscription = null

  ngOnInit() {
    this.storeSub1 = this.store.select('auth').subscribe(({ user }) => {
      if (user) {
        this.loggedInUser = user
      }
    })

    this._activatedRoute.params.subscribe((params) => {
      this.complaintId = params['complaintId']
    })
  }

  ngOnDestroy() {
    this.storeSub1 && this.storeSub1.unsubscribe()
  }

  onClickContinue() {
    if (this.loggedInUser.role.includes('GRO') || this.loggedInUser.role.includes('RO')) {
      this._router.navigate(['/auth/cg/employee/home'])
    } else {
      this._router.navigate(['/auth/cg/citizen/home'])
    }
  }

}
