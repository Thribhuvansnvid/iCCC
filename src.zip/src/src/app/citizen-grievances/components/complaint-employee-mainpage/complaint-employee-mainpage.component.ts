import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { User } from 'src/app/login/models/user.model';
import { Store } from "@ngrx/store";
import * as fromApp from "../../../store/app.reducer";
import { ComplaintService } from '../../services/citizen.grievance.service';

@Component({
  selector: 'cg-mainpage',
  templateUrl: './complaint-employee-mainpage.component.html',
  styleUrls: ['./complaint-employee-mainpage.component.scss']
})
export class ComplaintEmployeeMainpageComponent implements OnInit, OnDestroy {
  userRole:string[] = [];
  private storeSub1: Subscription;
  private storeSub2: Subscription;
  loggedInUser:User = null;

  total: number = 0
  totalOpen: number = 0
  totalClosed: number = 0
  totalAssigned: number = 0
  totalRejected:number = 0
  totalReopened:number = 0

  loadingData:boolean = true;

  constructor(private store: Store<fromApp.AppState>,private _complaintService: ComplaintService) { 
    console.log('home')
  }

  ngOnInit() {
    this.storeSub2 = this.store.select("auth").subscribe(({ user }) => {
      this.loggedInUser = user;
      if(user){
        this.fetchReportData()
      }
    });
  }

  ngOnDestroy(){
    this.storeSub1 && this.storeSub1.unsubscribe()
    this.storeSub2 && this.storeSub2.unsubscribe()
  }

  fetchReportData(){
    let params = {
      stateName: this.loggedInUser.state,
      districtCity: this.loggedInUser.districtCity,
      countParam:['STATUS_WISE']
    }

    this.loadingData = true
    this.storeSub1 = this._complaintService
      .getComplaintKpi(params)
      .subscribe(
        (res) => {
          this.loadingData = false
          if (res) {
            this.totalRejected = +(res.STATUS_WISE.Rejected)
            this.totalReopened = +(res.STATUS_WISE.Reopened)
            this.totalOpen = +(res.STATUS_WISE.Open + this.totalReopened)
            this.totalClosed = +(res.STATUS_WISE.Closed + this.totalRejected) 
            this.totalAssigned = +(res.STATUS_WISE.Assigned)

            this.total = this.totalOpen + this.totalClosed + this.totalAssigned

              
          }
          // this.loading = false
          // this.error = false
        },
        (err) => {
          this.loadingData = false
          // this.loading = false
          // this.error = true

          // console.log(err)
        }
      )
  }

}
