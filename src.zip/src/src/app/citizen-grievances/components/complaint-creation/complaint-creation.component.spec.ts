import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ComplaintCreationComponent } from './complaint-creation.component';

describe('ComplaintCreationComponent', () => {
  let component: ComplaintCreationComponent;
  let fixture: ComponentFixture<ComplaintCreationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ComplaintCreationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComplaintCreationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
