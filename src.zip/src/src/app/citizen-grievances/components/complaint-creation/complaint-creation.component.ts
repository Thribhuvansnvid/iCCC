import { Component, OnDestroy, OnInit } from "@angular/core";
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from "@angular/forms";
import { Router } from "@angular/router";
import { Store } from "@ngrx/store";
import { Subscription } from "rxjs";
import { ConfigSharedService } from "src/app/shared/services/config.service";
import * as fromApp from "../../../store/app.reducer";
import * as ComplaintsActions from "../../store/complaint.actions";
import { NgxImageCompressService } from "ngx-image-compress";
import { User } from "src/app/login/models/user.model";
import { SpinnerOverlayService } from 'src/app/shared/spinner-overlay/spinner-overlay.service';
import { GISService } from "src/app/GIS/md-gis/intf-gis.service";

@Component({
  selector: "app-complaint-creation",
  templateUrl: "./complaint-creation.component.html",
  styleUrls: ["./complaint-creation.component.scss"],
})
export class ComplaintCreationComponent implements OnInit, OnDestroy {
  hideRequiredControl = new FormControl(false);
  floatLabelControl = new FormControl("always");

  complaintForm: FormGroup;
  verticals: string[] = [];
  selectedFile: File = null;

  displayMap: boolean = false;
  imgURL: any = [];
  images: any = [];

  coordinate: { longitude: string, latitude: string } = null;
  address: string = "";

  loading: boolean = false;
  error: string = "";

  private storeSub1: Subscription;
  private storeSub2: Subscription;
  private storeSub3: Subscription;

  loggedInUser: User = null;

  constructor(
    private formBuilder: FormBuilder,
    private _configSharedService: ConfigSharedService,
    private store: Store<fromApp.AppState>,
    private _router: Router,
    private imageCompress: NgxImageCompressService,
    private spinnerOverlayService: SpinnerOverlayService,
    private gisService: GISService
  ) { }

  ngOnInit() {
    this.store.dispatch(
      new ComplaintsActions.ComplaintClearCreatedata()
    );

    this.storeSub2 = this.store.select("auth").subscribe(({ user }) => {
      if (user) {
        this.loggedInUser = user;
      }
    });

    this._configSharedService
      .getVerticalNames()
      .then((res: any) => {
        this.verticals = res;
      })
      .catch((err) => {
        console.log(err);
      });

    this.storeSub3 = this.store
      .select("createComplaint")
      .subscribe(({ success, loading, error, createdComplaintId }) => {
        this.loading = loading;
        this.error = error;
        // this.spinnerOverlayService.hide()

        if (success && createdComplaintId) {
          if (this.images.length > 0) {
            const formData = new FormData();
            for (let img of this.images) {
              formData.append("files", img);
            }
            formData.append("complaintId", createdComplaintId);
            formData.append("complaintStatus", "Open");

            this.store.dispatch(
              new ComplaintsActions.ComplaintUploadFilesStart(formData)
            );
          }
          this._router.navigate([
            "/auth/cg/complaint-submitted",
            createdComplaintId,
          ]);
        }
      });

    this.storeSub1 = this.store
      .select("uploadFilesComplaint")
      .subscribe(({ success, loading, error }) => {
        this.loading = loading;
        this.error = error;
        this.spinnerOverlayService.hide()
        if (success) {
        }
      });

    this.complaintForm = this.formBuilder.group({

      complaintType: ["", Validators.required],
      complaintDetails: [""],
      complaintLocation: [""],
      wardName: ["", [Validators.required]],
      zone: [""],
      pincode: [""],
      houseNoAndStreetName: ["", Validators.required],
      landMark: [""],
    });

    // this.gisService._onPickLocation.subscribe((data) => {
    //   this.coordinate = data;
    //   if (this.coordinate.longitude) {
    //     this.displayMap = false;

    //     this.gisService
    //       .getAddressFromCoordinate(this.coordinate)
    //       .then((res: string) => {
    //         console.log(res);
    //         console.log(this.coordinate)

    //         this.complaintForm.patchValue({
    //           complaintLocation: res,
    //         });
    //       })
    //       .catch((error) => {
    //         console.log(error);
    //       })
    //   }

    // });

    this.gisService.getCoordinate().subscribe((data) => {
      this.coordinate = data;
      if (this.coordinate.longitude) {
        this.displayMap = false;

        this.gisService
          .getAddressFromCoordinate(this.coordinate)
          .then((res: string) => {
            console.log(res);
            console.log(this.coordinate)

            this.complaintForm.patchValue({
              complaintLocation: res,
            });
          })
          .catch((error) => {
            console.log(error);
          })
      }

    });


  }

  onClickCancel() {
    if (!this.loggedInUser.role) {
      this._router.navigate(["/auth/cg/citizen/home"]);
    } else {
      this._router.navigate(["/auth/cg/employee/home"]);
    }
  }

  ngOnDestroy() {
    this.store.dispatch(
      new ComplaintsActions.ComplaintClearCreatedata()
    );

    this.storeSub1 && this.storeSub1.unsubscribe();
    this.storeSub2 && this.storeSub2.unsubscribe();
    this.storeSub3 && this.storeSub3.unsubscribe();
  }

  onSubmit() {
    if (this.complaintForm.valid) {
      let complaint = {
        stateName: this.loggedInUser.state,
        districtCity: this.loggedInUser.districtCity,

        wardName: this.complaintForm.value.wardName,
        areaVillage: this.complaintForm.value.houseNoAndStreetName,
        zone: this.complaintForm.value.zone,
        landmark: this.complaintForm.value.landMark,
        pinCode: this.complaintForm.value.pincode,
        // geometry: this.coordinate ? {"type":"Point","coordinates":[this.coordinate.longitude,this.coordinate.latitude]} : {},
        geometry: {},


        description: this.complaintForm.value.complaintDetails,
        complaintType: this.complaintForm.value.complaintType,
        departmentId: 'SWM',
        // departmentId: this.loggedInUser.departmentId, //complaint register not accepting user.departmentId (civilian)

        userId: this.loggedInUser.userId,
        complaintSource: "WEB",
      };
      this.spinnerOverlayService.show()
      this.store.dispatch(
        new ComplaintsActions.ComplaintCreateStart({ complaint: complaint })
      );
    }
  }

  onFileSelected(event) {
    // this.selectedFile = <File>event.target.files[0];
    // console.log(this.selectedFile)

    const files: File[] = event.target.files;
    if (files.length === 0) return;

    for (let file of files) {
      let mimeType = file.type;
      if (mimeType.match(/image\/*/) == null) {
        console.log("Only images are supported.");
        return;
      }
    }

    for (let file of files) {
      this.images.push(file);

      const fileName = file["name"];

      let reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (event) => {
        this.imgURL.push(reader.result);
        // const localUrl = event.target.result;
        // this.compressFile( localUrl, fileName);
      };
    }

    console.log(`images length ${this.imgURL.length}`);

    // var mimeType = files[0].type;
    // if (mimeType.match(/image\/*/) == null) {
    //   console.log('Only images are supported.')
    //   return;
    // }

    // var reader = new FileReader();
    // // this.imagePath = files;
    // reader.readAsDataURL(files[0]);
    // reader.onload = (_event) => {
    //   this.imgURL = reader.result;
    // }
  }

  onClickBtn() {
    console.log(`btn clicked`);
  }

  removeImage(index) {
    if (index > -1) {
      this.imgURL.splice(index, 1);
      this.images.splice(index, 1);
    }

    // array = [2, 9]
    // console.log(array);
  }

  compressFile(image, fileName) {
    var orientation = -1;
    // var sizeOfOriginalImage =
    //   this.imageCompress.byteCount(image) / (1024 * 1024);

    this.imageCompress
      .compressFile(image, orientation, 50, 50)
      .then((result) => {
        // this.imgResultAfterCompress = result;
        // this.localCompressedURl = result;
        // var sizeOFCompressedImage =
        //   this.imageCompress.byteCount(result) / (1024 * 1024);

        //   this.filesDetails.push({
        //     'fileName': fileName,
        //     'sizeBeforeCompression':` ${sizeOfOriginalImage.toFixed(2)} MB`,
        //     'sizeAfterCompression':`${sizeOFCompressedImage.toFixed(2)} MB`,
        //   })
        // const imageName = fileName;
        // const imageBlob = this.dataURItoBlob(
        //   this.imgResultAfterCompress.split(",")[1]
        // );
        const imageFile = new File([result], fileName, { type: "image/jpeg" });

        // this.multipleImages.push(imageFile)
        this.images.push(imageFile);
      });
  }

  dataURItoBlob(dataURI) {
    const byteString = window.atob(dataURI);
    const arrayBuffer = new ArrayBuffer(byteString.length);
    const int8Array = new Uint8Array(arrayBuffer);
    for (let i = 0; i < byteString.length; i++) {
      int8Array[i] = byteString.charCodeAt(i);
    }
    const blob = new Blob([int8Array], { type: "image/jpeg" });
    return blob;
  }

  onClickMyLoc(): void {
    this.displayMap = true;
  }

}
