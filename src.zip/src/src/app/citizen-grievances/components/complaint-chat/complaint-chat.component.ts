import { Component, Input, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { Store } from "@ngrx/store";
import { Subscription } from "rxjs";
import * as fromApp from "../../../store/app.reducer";
import * as ComplaintsActions from "../../store/complaint.actions";

@Component({
  selector: "complaint-chat",
  templateUrl: "./complaint-chat.component.html",
  styleUrls: ["./complaint-chat.component.scss"],
})
export class ComplaintChatComponent implements OnInit {
  constructor(
    private store: Store<fromApp.AppState>,
    private _router: Router
  ) {}

  @Input() comments: any[] = [];
  @Input() complaintId: string = "";

  storeSub: Subscription = null;

  messageTyped = "";
  userId = "rajani";

  ngOnInit() {
    console.log(this.comments);

    this.storeSub = this.store
      .select("complaintChatMsgSend")
      .subscribe(({ success, loading, error }) => {
        if (success) {
          this.messageTyped = "";
          // this._router.navigate(["/auth/cg/list", this.complaintId]);
          // this._router.navigate(["/auth/cg/details", this.complaintId]);
        }
      });
  }

  sendMessage() {
    if (this.messageTyped) {
      const data = {
        complaintId: this.complaintId,
        complaintUpdatedBy: this.userId,
        comments: this.messageTyped,
      };
      this.store.dispatch(
        new ComplaintsActions.ComplaintChatMsgSendStart(data)
      );
    }
  }
}
