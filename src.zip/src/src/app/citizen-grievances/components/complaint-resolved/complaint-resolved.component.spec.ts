import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ComplaintResolvedComponent } from './complaint-resolved.component';

describe('ComplaintResolvedComponent', () => {
  let component: ComplaintResolvedComponent;
  let fixture: ComponentFixture<ComplaintResolvedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ComplaintResolvedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComplaintResolvedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
