import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { AppConfigService } from 'src/app/shared/configs-loader/app.config.service';

@Component({
  selector: 'complaints-map-view',
  templateUrl: './complaints-map-view.component.html',
  styleUrls: ['./complaints-map-view.component.scss']
})
export class ComplaintsMapViewComponent implements OnInit {
  gisUrl:string = "";
  floatLabelControl = new FormControl("always");

  constructor(private _configs: AppConfigService) { 
    this.gisUrl =
    this._configs.getConfig().API_BASE_URL +
    '/gis/arcgis?service=SmartComp+login=citizengrievances'
  }

  ngOnInit() {
  }

  iframeLoadEvent() {
    // this._complaintService
    //   .drawComplaintsOnMap({
    //     state_name: this.state_name,
    //     district_city: this.district_city,
    //   })
    //   .then((res) => {
    //     console.log('Successfully drawn complaints on map')
    //   })
    //   .catch((error) => {
    //     console.log('Error while drawing complaints on map')
    //   })
  }

}
