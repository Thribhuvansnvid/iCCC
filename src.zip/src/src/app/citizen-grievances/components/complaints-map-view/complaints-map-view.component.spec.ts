import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ComplaintsMapViewComponent } from './complaints-map-view.component';

describe('ComplaintsMapViewComponent', () => {
  let component: ComplaintsMapViewComponent;
  let fixture: ComponentFixture<ComplaintsMapViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ComplaintsMapViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComplaintsMapViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
