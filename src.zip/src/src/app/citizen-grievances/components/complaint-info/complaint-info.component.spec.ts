import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ComplaintInfoComponent } from './complaint-info.component';

describe('ComplaintInfoComponent', () => {
  let component: ComplaintInfoComponent;
  let fixture: ComponentFixture<ComplaintInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ComplaintInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComplaintInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
