import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { SpinnerOverlayService } from 'src/app/shared/spinner-overlay/spinner-overlay.service';
import { ComplaintStatus } from '../../models/constants';

@Component({
  selector: 'complaint-info',
  templateUrl: './complaint-info.component.html',
  styleUrls: ['./complaint-info.component.scss']
})
export class ComplaintInfoComponent implements OnInit, OnDestroy {

  constructor(private spinnerOverlayService: SpinnerOverlayService) { }
  _complaintStatusEnum = ComplaintStatus;

  @Input() complaint: any = null;
  complaintOpenEvent:any = null
  ngOnInit() {
    // console.log(this.complaint)
    this.complaintOpenEvent = this.complaint.eventList.find(event=>event.eventType === 'Open')
    console.log(this.complaintOpenEvent)
  }

  ngOnDestroy(){
    
  }
  onClickImage(event,images, index){
    // (click)="onClickImage($event, complaint.attachments.Open,count)"
    event.stopPropagation();
    this.spinnerOverlayService.showImages(images,index);
  }

}
