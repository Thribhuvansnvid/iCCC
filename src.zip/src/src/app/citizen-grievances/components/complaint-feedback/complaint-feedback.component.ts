import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { Store } from "@ngrx/store";
import * as fromApp from "../../../store/app.reducer";
import { Subscription } from "rxjs";
import { User } from "src/app/login/models/user.model";
import * as ComplaintsActions from "../../store/complaint.actions";
import { StarRatingComponent } from 'ng-starrating';

@Component({
  selector: "app-complaint-feedback",
  templateUrl: "./complaint-feedback.component.html",
  styleUrls: ["./complaint-feedback.component.scss"]
})
export class ComplaintFeedbackComponent implements OnInit {
  service: boolean = false;
  resolutionTime: boolean = false;
  qow: boolean = false;
  ratingvalue:string = '1'
  // others1:boolean = false;
  // others2:boolean = false;
  // others3:boolean = false;

  remarks: string = "";

  constructor(
    private _activatedRoute: ActivatedRoute,
    private store: Store<fromApp.AppState>,
    private _router: Router
  ) {}

  comments: string = "";
  complaintId: string = "";

  loggedInUser: User = null;

  storeSub1: Subscription = null;
  storeSub2: Subscription = null;

  storeSub: Subscription = null;
  ngOnInit() {
    this._activatedRoute.params.subscribe(params => {
      this.complaintId = params["complaintId"];
    });

    this.storeSub2 = this.store.select("auth").subscribe(({ user }) => {
      this.loggedInUser = user;
    });

    this.storeSub1 = this.store
      .select("complaintFeedback")
      .subscribe(({ success, loading, error }) => {
        if (success) {
          this._router.navigate(["/auth/cg/details", this.complaintId]);
          // this._router.navigate(["/auth/cg/gro/list"]);
        }
      });
  }

  ngOnDestroy() {
    this.storeSub1 && this.storeSub1.unsubscribe();
    this.storeSub2 && this.storeSub2.unsubscribe();
  }

  onRate($event:{oldValue:number, newValue:number, starRating:StarRatingComponent}) {
    this.ratingvalue = String($event.newValue)
    // alert(`Old Value:${$event.oldValue}, 
    //   New Value: ${$event.newValue}, 
    //   Checked Color: ${$event.starRating.checkedcolor}, 
    //   Unchecked Color: ${$event.starRating.uncheckedcolor}`);
  }

  onClickCancel() {
    this._router.navigate(["/auth/cg/details", this.complaintId]);
  }

  onClickSubmit() {
    // let data = {
    //   complaintId: this.complaintId,
    //   complaintUpdatedBy: this.loggedInUser,
    //   complaintStatus: "Feedback",
    //   remarks: this.remarks,
    // };

    let feedback: string[] = [];
    if (this.service) {
      feedback.push("Service");
    } else if (this.resolutionTime) {
      feedback.push("Resolution Time");
    } else if (this.resolutionTime) {
      feedback.push("Quality of work");
    }

    let data = {
      complaintId: this.complaintId,
      complaintUpdatedBy: this.loggedInUser.userId,
      feedbackParams: feedback,
      feedbackRating: Number(this.ratingvalue),
      feedbackDescription: this.remarks
    };
    this.store.dispatch(new ComplaintsActions.ComplaintFeedbackStart(data));
  }
}
