import { Component, ViewChild } from "@angular/core";
import {
  ApexAxisChartSeries,
  ApexChart,
  ChartComponent,
  ApexDataLabels,
  ApexPlotOptions,
  ApexYAxis,
  ApexLegend,
  ApexStroke,
  ApexXAxis,
  ApexFill,
  ApexTooltip,
  ApexTheme
} from "ng-apexcharts";

export type ChartOptions = {
  series: ApexAxisChartSeries;
  chart: ApexChart;
  dataLabels: ApexDataLabels;
  plotOptions: ApexPlotOptions;
  yaxis: ApexYAxis;
  xaxis: ApexXAxis;
  fill: ApexFill;
  tooltip: ApexTooltip;
  stroke: ApexStroke;
  legend: ApexLegend;
  theme: ApexTheme

};

@Component({
  selector: 'complaint-status-line-chart',
  templateUrl: './complaint-status-line-chart.component.html',
  styleUrls: ['./complaint-status-line-chart.component.scss'],
})
export class ComplaintStatusLineChartComponent {
  @ViewChild("chart",{static:true}) chart: ChartComponent;
  public chartOptions: Partial<ChartOptions>;

  constructor() {
    const theme = localStorage.getItem('pxTheme');

    this.chartOptions = {
      theme: {
        mode: theme === 'light-theme' ? 'light' : 'dark',
        palette: 'palette1',
        monochrome: {
          enabled: false,
          color: '#255aee',
          shadeTo: 'light',
          shadeIntensity: 0.65
        },
      },
      series: [
        {
          name: "Closed",
          data: [44, 55, 57, 56, 61, 58, 63, 60, 66]
        },
        {
          name: "Assigned",
          data: [76, 85, 101, 98, 87, 105, 91, 114, 94]
        },
        {
          name: "Open",
          data: [35, 41, 36, 26, 45, 48, 52, 53, 41]
        }
      ],
      chart: {
        type: "bar",
        height: 350
      },
      plotOptions: {
        bar: {
          horizontal: false,
          columnWidth: "55%",
          endingShape: "rounded"
        }
      },
      dataLabels: {
        enabled: false
      },
      stroke: {
        show: true,
        width: 2,
        colors: ["transparent"]
      },
      xaxis: {
        categories: [
          "Feb",
          "Mar",
          "Apr",
          "May",
          "Jun",
          "Jul",
          "Aug",
          "Sep",
          "Oct"
        ]
      },
      yaxis: {
        title: {
          text: "complaints"
        }
      },
      fill: {
        opacity: 1
      },
      tooltip: {
        y: {
          formatter: function(val) {
            return "" + val + " complaints";
          }
        }
      }
      
    };
  }
}

