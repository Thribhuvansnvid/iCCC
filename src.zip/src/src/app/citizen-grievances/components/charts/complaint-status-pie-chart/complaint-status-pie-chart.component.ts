import { Component, Input, OnInit, ViewChild } from "@angular/core";
import { ApexTheme, ChartComponent } from "ng-apexcharts";

import {
  ApexNonAxisChartSeries,
  ApexResponsive,
  ApexChart
} from "ng-apexcharts";

export type ChartOptions = {
  series: ApexNonAxisChartSeries;
  chart: ApexChart;
  responsive: ApexResponsive[];
  labels: any;
  theme: ApexTheme
};

@Component({
  selector: 'complaint-status-pie-chart',
  templateUrl: './complaint-status-pie-chart.component.html',
  styleUrls: ['./complaint-status-pie-chart.component.scss'],
})
export class ComplaintStatusPieChartComponent implements OnInit{

  @ViewChild("chart",{static:true}) chart: ChartComponent;
  public chartOptions: Partial<ChartOptions>;

  @Input() Assigned: number = 0;
  @Input() Closed: number = 0;
  @Input() Open: number = 0;
  @Input() Rejected: number = 0;
  @Input() ReOpened: number = 0;

  constructor() {

  }

  ngOnInit() {
    this.renderChart()
  }

  renderChart(){
    const theme = localStorage.getItem('pxTheme');

    this.chartOptions = {
      series: [this.Open, this.Closed, this.Assigned, this.Rejected, this.ReOpened],
      chart: {
        width: 350,
        type: "pie"
      },
      labels: ["Open", "Closed", "Assigned", "Rejected", "Re-Opened"],
      responsive: [
        {
          breakpoint: 480,
          options: {
            chart: {
              width: 200
            },
            legend: {
              position: "bottom"
            }
          }
        }
      ],
      theme: {
        mode: theme === 'light-theme' ? 'light' : 'dark',
        palette: 'palette1',
        monochrome: {
          enabled: false,
          color: '#255aee',
          shadeTo: 'light',
          shadeIntensity: 0.65
        },
      }
    };
  }
}
