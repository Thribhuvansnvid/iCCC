import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ComplaintReopenAcknowledgeComponent } from './complaint-reopen-acknowledge.component';

describe('ComplaintReopenAcknowledgeComponent', () => {
  let component: ComplaintReopenAcknowledgeComponent;
  let fixture: ComponentFixture<ComplaintReopenAcknowledgeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ComplaintReopenAcknowledgeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComplaintReopenAcknowledgeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
