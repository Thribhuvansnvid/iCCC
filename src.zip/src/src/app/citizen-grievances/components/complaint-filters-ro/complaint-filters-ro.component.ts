import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { User } from 'src/app/login/models/user.model';
import { SpinnerOverlayService } from 'src/app/shared/spinner-overlay/spinner-overlay.service';
import * as fromApp from "../../../store/app.reducer";
import { ComplaintListFilters } from '../../models/complaint.list.filters';
import * as ComplaintsActions from "../../store/complaint.actions";
import {
  DateTimeAdapter,
  OWL_DATE_TIME_FORMATS,
  OWL_DATE_TIME_LOCALE,
} from 'ng-pick-datetime'
import * as moment from 'moment'
export const MY_CUSTOM_FORMATS = {
  fullPickerInput: 'YYYY-MM-DD HH:mm:ss',
  parseInput: 'YYYY-MM-DD HH:mm:ss',
  datePickerInput: 'YYYY-MM-DD HH:mm:ss',
  timePickerInput: 'LT',
  monthYearLabel: 'MMM YYYY',
  dateA11yLabel: 'LL',
  monthYearA11yLabel: 'MMMM YYYY',
}
import { MomentDateTimeAdapter } from 'ng-pick-datetime/date-time/adapter/moment-adapter/moment-date-time-adapter.class'

@Component({
  selector: 'complaint-filters-ro',
  templateUrl: './complaint-filters-ro.component.html',
  styleUrls: ['./complaint-filters-ro.component.scss'],
  providers: [
    {
      provide: DateTimeAdapter,
      useClass: MomentDateTimeAdapter,
      deps: [OWL_DATE_TIME_LOCALE],
    },
    { provide: OWL_DATE_TIME_FORMATS, useValue: MY_CUSTOM_FORMATS },
  ],
})
export class ComplaintFiltersRoComponent implements OnInit {
  hideRequiredControl = new FormControl(false);
  floatLabelControl = new FormControl("always");
  storeSub1:Subscription = null;

  selectable = true;
  removable = true;
  addOnBlur = true;

  fromDateTime = "";
  toDateTime = "";
  selectedFilterOptions: any[] = [];

  departmentList = [
    { name: 'SWM', value: false },
    { name: 'VMD', value: false },
    { name: 'VMS', value: false },
    { name: 'REVENUE', value: false }
  ]

  timeLineList = [
    { name: 'Last 7 Hours', value: 0 },
    { name: 'Last 1 Day', value: 1 },
    { name: 'Last 3 Days', value: 2 },
    { name: 'Last 1 Week', value: 3 },
    { name: 'Last 1 Month', value: 4 },
    { name: 'Select Date', value: 5 },
  ]
  timeLineSelected = 0;

  ROList = [
    { name: 'RO1', value: false },
    { name: 'RO2', value: false },
    { name: 'RO3', value: false },
    { name: 'RO4', value: false },
    { name: 'RO5', value: false }
  ]
  searchText = ""
  loggedInUser:User = null;
  _complaintListFilters = new ComplaintListFilters('RO')

  constructor(private store: Store<fromApp.AppState>,private spinnerOverlayService: SpinnerOverlayService) { }

  ngOnInit() {
    
    this.storeSub1 = this.store
    .select("auth")
    .subscribe(({ user }) => {
      this.loggedInUser = user;

      this._complaintListFilters.stateName = this.loggedInUser.state
      this._complaintListFilters.districtCity = this.loggedInUser.districtCity

      if (user) {
        
        this.fetchComplaints();
      }
    });

    // this.searchForm = this.formBuilder.group({
    //   mobileNumber: [""],
    //   complaintNumber: [""],
    // });
  }

  fetchComplaints() {
    this.spinnerOverlayService.show();
    this.store.dispatch(
      new ComplaintsActions.ComplaintsFetchStart(this._complaintListFilters)
    );
  }

  removeSelection(event, index){
    if(event.type === 'Department'){
      let itemIndex = this.departmentList.findIndex(item => item.name === event.name)
      this.departmentList[itemIndex].value = false
    }

    if(event.type === 'RoList'){
      let itemIndex = this.ROList.findIndex(item => item.name === event.name)
      this.ROList[itemIndex].value = false
    }

    this.selectedFilterOptions.splice(index, 1);

  }


  onChangeDepartmentSelection(index) {
    this.departmentList[index].value = !this.departmentList[index].value

    if (this.departmentList[index].value) {
      this.selectedFilterOptions.push({
        type: "Department",
        name: this.departmentList[index].name
      })
    } else {
      let itemIndex = this.selectedFilterOptions.findIndex(item => item.type === 'Department' && item.name === this.departmentList[index].name);
      if (itemIndex > -1) {
        this.selectedFilterOptions.splice(itemIndex, 1);
      }
    }
    console.log(this.selectedFilterOptions)
  }

  onChangeRoSelection(index) {
    this.ROList[index].value = !this.ROList[index].value

    if (this.ROList[index].value) {
      this.selectedFilterOptions.push({
        type: "RoList",
        name: this.ROList[index].name
      })
    } else {
      let itemIndex = this.selectedFilterOptions.findIndex(item => item.type === 'RoList' && item.name === this.departmentList[index].name);
      if (itemIndex > -1) {
        this.selectedFilterOptions.splice(itemIndex, 1);
      }
    }
  }

  formatDates() {
    this.fromDateTime = moment(
      this.fromDateTime
    ).format('YYYY-MM-DD HH:mm:ss')
    
    this.toDateTime = moment(
      this.toDateTime
    ).format('YYYY-MM-DD HH:mm:ss')
  }


  resetAllFilter(){
    this.selectedFilterOptions = [];

    this.departmentList = [
      { name: 'SWM', value: false },
      { name: 'VMD', value: false },
      { name: 'VMS', value: false },
      { name: 'REVENUE', value: false }
    ]
    
  
    this.ROList = [
      { name: 'RO1', value: false },
      { name: 'RO2', value: false },
      { name: 'RO3', value: false },
      { name: 'RO4', value: false },
      { name: 'RO5', value: false }
    ]

  }
}
