import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ComplaintCitizenMainpageComponent } from './complaint-citizen-mainpage.component';

describe('ComplaintCitizenMainpageComponent', () => {
  let component: ComplaintCitizenMainpageComponent;
  let fixture: ComponentFixture<ComplaintCitizenMainpageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ComplaintCitizenMainpageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComplaintCitizenMainpageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
