import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-complaint-citizen-mainpage',
  templateUrl: './complaint-citizen-mainpage.component.html',
  styleUrls: ['./complaint-citizen-mainpage.component.scss']
})
export class ComplaintCitizenMainpageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
