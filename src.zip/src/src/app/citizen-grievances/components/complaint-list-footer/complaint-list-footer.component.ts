import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { tap } from 'rxjs/operators';
import { ComplaintListFilters } from '../../models/complaint.list.filters';
import * as fromApp from '../../../store/app.reducer'
import * as ComplaintsActions from "../../store/complaint.actions";

@Component({
  selector: 'complaint-list-footer',
  templateUrl: './complaint-list-footer.component.html',
  styleUrls: ['./complaint-list-footer.component.scss']
})
export class ComplaintListFooterComponent implements OnInit {
  private storeSub1: Subscription
  constructor(private store: Store<fromApp.AppState>) { }
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator

  totalComplaints: number = 0;
  _complaintListFilters: ComplaintListFilters = null;

  ngOnInit() {

    this.storeSub1 = this.store
      .select("complaints")
      .subscribe(({ filters, totalCount }) => {
        this.totalComplaints = totalCount
        this._complaintListFilters = filters
      });

  }

  ngAfterViewInit() {
    this.paginator.page
      .pipe(
        tap(() => {
          this._complaintListFilters.pageIndex = this.paginator.pageIndex
          this._complaintListFilters.pageSize = this.paginator.pageSize,

            this.store.dispatch(
              new ComplaintsActions.ComplaintsFetchStart(this._complaintListFilters)
            );

        })
      )
      .subscribe()
  }

  ngOnDestroy() {
    this.storeSub1 && this.storeSub1.unsubscribe()
  }

}
