import { Component, OnInit, ViewChild } from "@angular/core";
import { MatStepper } from "@angular/material";
import { STEPPER_GLOBAL_OPTIONS } from "@angular/cdk/stepper";
import { ActivatedRoute, Router } from "@angular/router";
import { Store } from "@ngrx/store";
import * as fromApp from "../../../store/app.reducer";
import * as ComplaintsActions from "../../store/complaint.actions";
import { Subscription } from "rxjs";
import { User } from "src/app/login/models/user.model";
import { SpinnerOverlayService } from "src/app/shared/spinner-overlay/spinner-overlay.service";
import { ComplaintStatus } from "../../models/constants";

@Component({
  selector: "app-complaint-details",
  templateUrl: "./complaint-details.component.html",
  styleUrls: ["./complaint-details.component.scss"],
  providers: [
    {
      provide: STEPPER_GLOBAL_OPTIONS,
      useValue: { displayDefaultIndicatorType: false },
    },
  ],
})
export class ComplaintDetailsComponent implements OnInit {
  @ViewChild("stepper", { static: true }) stepper: MatStepper;

  constructor(
    private _activatedRoute: ActivatedRoute,
    private store: Store<fromApp.AppState>,
    private _router: Router,
    private spinnerOverlayService: SpinnerOverlayService
  ) {}
  completed = true;
  editable = false;
  events: any[] = [];
  private storeSub1: Subscription;
  private storeSub2: Subscription;
  private storeSub3: Subscription;

  displayActionBtns: boolean = true;

  complaint: any = null;
  displayImageViewr = false;
  complaintId: string = "";
  // userRole:string = "";

  loggedInUser: User = null;

  ngOnInit() {
    // this.stepper.selectedIndex = 0;

    this.storeSub2 = this.store.select("auth").subscribe(({ user }) => {
      if (user) {
        this.loggedInUser = user;

        this._activatedRoute.params.subscribe((params) => {
          this.complaintId = params["complaintId"];

          this.fetchComplaintDetails();
        });
      }
    });

    this.storeSub1 = this.store
      .select("complaintChatMsgSend")
      .subscribe(({ success, loading, error }) => {
        if (success) {
          this.fetchComplaintDetails();
        }
      });

    this.storeSub3 = this.store
      .select("complaintDetails")
      .subscribe(({ success, complaint }) => {
        this.spinnerOverlayService.hide();
        if (success) {
          this.complaint = complaint;
          console.log(this.complaint)
          if (
            !this.loggedInUser.role ||
            this.complaint.complaintStatus === ComplaintStatus.CLOSED ||
            this.complaint.complaintStatus === ComplaintStatus.REJECTED
          ) {
            //for citizen role is undefined
            this.displayActionBtns = false;
          }
        }
      });
  }

  fetchComplaintDetails() {
    this.complaint = null;
    this.spinnerOverlayService.show();
    this.store.dispatch(
      new ComplaintsActions.ComplaintViewDetailsStart({
        stateName: this.loggedInUser.state,
        districtCity: this.loggedInUser.districtCity,
        pageIndex: 0,
        pageSize: 50,
        sortBy: "complaintRegistrationDate",
        complaintId: this.complaintId,
      })
    );
  }

  getDisplayActionBtns() {
    let displayActionBtns = true;
    if (!this.loggedInUser.role) {
      //for citizen role is undefined
      displayActionBtns = false;
    }
    return displayActionBtns;
  }

  ngOnDestroy() {
    this.spinnerOverlayService.hide();
    this.storeSub1 && this.storeSub1.unsubscribe();
    this.storeSub2 && this.storeSub2.unsubscribe();
    this.storeSub3 && this.storeSub3.unsubscribe();
  }

  onClickBack() {
    if (!this.loggedInUser.role) {
      this._router.navigate(["/auth/cg/citizen/list"]);
    } else {
      if (this.loggedInUser.role.includes("GRO")) {
        this._router.navigate(["/auth/cg/gro/list"]);
      } else if (this.loggedInUser.role.includes("RO")) {
        this._router.navigate(["/auth/cg/ro/list"]);
      }
    }
  }

  onClickImage() {
    this.displayImageViewr = true;
  }

  onClickAssign() {
    if (this.complaintId) {
      // this.store.dispatch(
      //   new ComplaintsActions.ComplaintViewDetails(this.complaintId)
      // );
      this._router.navigate(["/auth/cg/assign-complaint", this.complaintId]);
    }
  }
  onClickReAssign() {
    if (this.complaintId) {
      this._router.navigate(["/auth/cg/assign-complaint", this.complaintId]);
    }
  }

  onClickReject() {
    if (this.complaintId) {
      this._router.navigate(["/auth/cg/complaint-reject", this.complaintId]);
    }
  }

  onClickMarkResolved() {
    if (this.complaintId) {
      this._router.navigate(["/auth/cg/complaint-resolved", this.complaintId]);
    }
  }

  onClickRequestReAssign() {
    if (this.complaintId) {
      this._router.navigate([
        "/auth/cg/complaint-request-re-assign",
        this.complaintId,
      ]);
    }
  }
}
