import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ComplaintTimelineComponent } from './complaint-timeline.component';

describe('ComplaintTimelineComponent', () => {
  let component: ComplaintTimelineComponent;
  let fixture: ComponentFixture<ComplaintTimelineComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ComplaintTimelineComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComplaintTimelineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
