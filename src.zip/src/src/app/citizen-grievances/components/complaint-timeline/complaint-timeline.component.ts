import { Component, OnInit, Input } from '@angular/core'
import { ActivatedRoute, Router } from '@angular/router'
import * as fromApp from '../../../store/app.reducer'
import { Store } from '@ngrx/store'
import { Subscription } from 'rxjs'
import { User } from 'src/app/login/models/user.model'
import { SpinnerOverlayService } from 'src/app/shared/spinner-overlay/spinner-overlay.service'
import { ComplaintStatus } from '../../models/constants'

@Component({
  selector: 'complaint-timeline',
  templateUrl: './complaint-timeline.component.html',
  styleUrls: ['./complaint-timeline.component.scss'],
})
export class ComplaintTimelineComponent implements OnInit {
  @Input() value: any[] = []
  @Input() user: User = null
  @Input() complaintId: string = ''
  complaintClosed:boolean = false;
  // storeSub: Subscription = null
  // loggedInUser: User = null
  // complaintId: string = ''

  constructor(
    private _router: Router,
    private spinnerOverlayService: SpinnerOverlayService
    // private store: Store<fromApp.AppState>,
    // private _activatedRoute: ActivatedRoute
  ) {}

  ngOnInit(): void {
    // if(this.value){
    //   this.value = this.value.reverse()
    // }

    // this.storeSub = this.store.select('auth').subscribe(({ user }) => {
    //   if (user) {
    //     this.loggedInUser = user
    //   }
    // })

    // this._activatedRoute.params.subscribe((params) => {
    //   this.complaintId = params['complaintId']
    // })
    this.complaintClosed = this.value.some(item=>item.eventType === ComplaintStatus.CLOSED)
    // console.log(this.value)
    // console.log(this.user)
    // console.log(this.complaintId)


  }

  getFeedbackString(feedbackParams:string[]){
    let returnStr = ""
    if(feedbackParams.length){
      returnStr = ` (${feedbackParams.join()})`;
    }
    else{
      returnStr = ""
    }
    return returnStr;
    
  }

  onClickRate() {
    this._router.navigate(['/auth/cg/complaint-feedback',  this.complaintId])
  }

  onClickReOpen() {
    this._router.navigate(['/auth/cg/complaint-reopen',  this.complaintId])
  }

  onClickImage(event,images, index){
    // (click)="onClickImage($event, complaint.attachments.Open,count)"
    event.stopPropagation();
    this.spinnerOverlayService.showImages(images,index);
  }

}
