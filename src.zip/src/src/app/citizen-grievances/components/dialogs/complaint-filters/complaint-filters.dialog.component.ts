import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog'
import { Component, Inject, OnInit } from '@angular/core'
import { FormControl } from '@angular/forms';

@Component({
  // selector: 'app-add.dialog',
  templateUrl: './complaint-filters.dialog.html',
  styleUrls: ['./complaint-filters.dialog.scss'],
})
export class ComplaintFiltersDialogComponent implements OnInit {
  itemList = [];
  selectedItems = [];
  settings = {};

  toppings = new FormControl();
  toppingList: string[] = ['Extra cheese', 'Mushroom', 'Onion', 'Pepperoni', 'Sausage', 'Tomato'];

  ngOnInit() {

    

    this.settings = {
      text: "Select Countries",
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      classes: "myclass custom-class"
    };


    this.itemList = [
      { "id": 1, "itemName": "India" },
      { "id": 2, "itemName": "Singapore" },
      { "id": 3, "itemName": "Australia" },
      { "id": 4, "itemName": "Canada" },
      { "id": 5, "itemName": "South Korea" },
      { "id": 6, "itemName": "Brazil" }
    ];

    this.selectedItems = [
      { "id": 1, "itemName": "India" },
      { "id": 2, "itemName": "Singapore" },
      { "id": 3, "itemName": "Australia" },
      { "id": 4, "itemName": "Canada" }];

  }
  onItemSelect(item: any) {
    console.log(item);
    console.log(this.selectedItems);
  }
  OnItemDeSelect(item: any) {
    console.log(item);
    console.log(this.selectedItems);
  }
  onSelectAll(items: any) {
    console.log(items);
  }
  onDeSelectAll(items: any) {
    console.log(items);
  }

  constructor(
    public dialogRef: MatDialogRef<ComplaintFiltersDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
  }

  confirmLogout() {
    this.dialogRef.close()
  }

  cancelLogout() {
    this.dialogRef.close()
  }

}
