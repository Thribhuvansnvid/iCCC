import { Component, Input, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { Subscription } from "rxjs";
import { Store } from "@ngrx/store";
import * as fromApp from "../../../store/app.reducer";
import { User } from "src/app/login/models/user.model";
// import { SpinnerOverlayService } from "src/app/shared/spinner-overlay/spinner-overlay.service";
// import { ComplaintImageViewerOverlayService } from '../complaint-image-viewer-overlay/complaint-image-viewer.service';
import * as ComplaintsActions from '../../store/complaint.actions'
import { SpinnerOverlayService } from 'src/app/shared/spinner-overlay/spinner-overlay.service';
import { ComplaintStatus } from '../../models/constants';

@Component({
  selector: "complaint-list-item",
  templateUrl: "./complaint-list-item.component.html",
  styleUrls: ["./complaint-list-item.component.scss"]
})
export class ComponentListItemComponent implements OnInit {
  @Input() complaint: any= [];
  storeSub: Subscription = null;
  _complaintStatusEnum = ComplaintStatus;

  loggedInUser: User = null;
  constructor(
    private _router: Router,
    private store: Store<fromApp.AppState>,
    // private complaintImageViewerOverlayService: ComplaintImageViewerOverlayService,
    private spinnerOverlayService: SpinnerOverlayService
  ) {}

  ngOnInit() {
    this.storeSub = this.store.select("auth").subscribe(({ user }) => {
      this.loggedInUser = user;
    });
  }

  onClickComplaint(complaintId) {
    this._router.navigate(["/auth/cg/details", complaintId]);
  }

  onClickDeleteComplaint($event, complaintId) {
    $event.stopPropagation()
    this.store.dispatch(new ComplaintsActions.ComplaintDeleteStart(complaintId))
  }


  onClickImage(event,images, index){
    // (click)="onClickImage($event, complaint.attachments.Open,count)"
    event.stopPropagation();
    this.spinnerOverlayService.showImages(images,index);
  }

}
