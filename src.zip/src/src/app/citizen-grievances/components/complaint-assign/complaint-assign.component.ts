import { Component, OnDestroy, OnInit } from '@angular/core'
import { ActivatedRoute, Router } from '@angular/router'
import { Store } from '@ngrx/store'
import { Subscription } from 'rxjs'
import * as fromApp from '../../../store/app.reducer'
import * as ComplaintsActions from '../../store/complaint.actions'
import { SpinnerOverlayService } from 'src/app/shared/spinner-overlay/spinner-overlay.service'
import { ComplaintStatus } from '../../models/constants'
import { User } from 'src/app/login/models/user.model'

@Component({
  selector: 'app-complaint-assign',
  templateUrl: './complaint-assign.component.html',
  styleUrls: ['./complaint-assign.component.scss'],
})
export class ComplaintAssignComponent implements OnInit, OnDestroy {
  constructor(
    private store: Store<fromApp.AppState>,
    private _router: Router,
    private _activatedRoute: ActivatedRoute,
    private spinnerOverlayService: SpinnerOverlayService
  ) {}
  
  complaintId = ''
  selectedRoName = ''
  selectedRoDepartmentName = ''

  private storeSub1: Subscription;
  private storeSub2: Subscription;
  private storeSub3: Subscription;
  loggedInUser: User = null
  RoList = [
    {
      departmentName: 'SWM',
      officers: [
        {
          name: 'swm_ro',
          designation: 'Executive Officer',
          mobileNo: '+919876543210',
        },
        {
          name: 'roofficer',
          designation: 'Executive Officer',
          mobileNo: '+919876543210',
        },
      ],
    },
    {
      departmentName: 'Health & Sanitation',
      officers: [
        {
          name: 'Ashok RO1',
          designation: 'Deputy Chief Executive Officer',
          mobileNo: '+919876543210',
        },
        {
          name: 'Ashok RO2',
          designation: 'Deputy Chief Executive Officer',
          mobileNo: '+919876543210',
        },
        {
          name: 'Ashok RO3',
          designation: 'Deputy Chief Executive Officer',
          mobileNo: '+919876543210',
        },
      ],
    },
    {
      departmentName: 'Tax Branch',
      officers: [
        {
          name: 'Ashok RO1',
          designation: 'Deputy Chief Executive Officer',
          mobileNo: '+919876543210',
        },
        {
          name: 'Ashok RO2',
          designation: 'Deputy Chief Executive Officer',
          mobileNo: '+919876543210',
        },
        {
          name: 'Ashok RO3',
          designation: 'Deputy Chief Executive Officer',
          mobileNo: '+919876543210',
        },
      ],
    },
    {
      departmentName: 'Office',
      officers: [
        {
          name: 'Ashok RO1',
          designation: 'Deputy Chief Executive Officer',
          mobileNo: '+919876543210',
        },
        {
          name: 'Ashok RO2',
          designation: 'Deputy Chief Executive Officer',
          mobileNo: '+919876543210',
        },
        {
          name: 'Ashok RO3',
          designation: 'Deputy Chief Executive Officer',
          mobileNo: '+919876543210',
        },
      ],
    },
    {
      departmentName: 'Water Department',
      officers: [
        {
          name: 'Ashok RO1',
          designation: 'Deputy Chief Executive Officer',
          mobileNo: '+919876543210',
        },
        {
          name: 'Ashok RO2',
          designation: 'Deputy Chief Executive Officer',
          mobileNo: '+919876543210',
        },
        {
          name: 'Ashok RO3',
          designation: 'Deputy Chief Executive Officer',
          mobileNo: '+919876543210',
        },
      ],
    },
    {
      departmentName: 'Information Technology',
      officers: [
        {
          name: 'Ashok RO1',
          designation: 'Deputy Chief Executive Officer',
          mobileNo: '+919876543210',
        },
        {
          name: 'Ashok RO2',
          designation: 'Deputy Chief Executive Officer',
          mobileNo: '+919876543210',
        },
        {
          name: 'Ashok RO3',
          designation: 'Deputy Chief Executive Officer',
          mobileNo: '+919876543210',
        },
      ],
    },
  ]

  complaint:any = null
  ngOnInit() {
    this.storeSub3 = this._activatedRoute.params.subscribe((params) => {
      this.complaintId = params['complaintId']
    })


    this.storeSub1 = this.store
      .select('assignComplaint')
      .subscribe(({ success, loading, error }) => {
        this.spinnerOverlayService.hide()
        if (success) {
          this._router.navigate([
            '/auth/cg/complaint-assign-ack',
            this.complaintId,
          ])
        }
      })

      // this.storeSub2 = this.store
      // .select("complaints")
      // .subscribe(({ complaint }) => {
      //   this.complaint = complaint
      // });
  }

  ngOnDestroy() {    
    this.storeSub1 && this.storeSub1.unsubscribe();
    this.storeSub2 && this.storeSub2.unsubscribe();
    this.storeSub3 && this.storeSub3.unsubscribe();
  }

  onClickCancel() {
    this._router.navigate(['/auth/cg/details', this.complaintId])
  }

  onSelectRO(selectedRoDepartmentName, SelectedRoName) {
    this.selectedRoDepartmentName = selectedRoDepartmentName
    this.selectedRoName = SelectedRoName
  }

  onClickAssign() {
    this.spinnerOverlayService.show()
    this.store.dispatch(
      new ComplaintsActions.ComplaintAssignStart({
        complaintId: this.complaintId,
        complaintUpdatedBy: this.selectedRoName,
        complaintStatus: ComplaintStatus.ASSIGNED,
        complaintAssignedTo: this.selectedRoName,
      })
    )
  }
}
