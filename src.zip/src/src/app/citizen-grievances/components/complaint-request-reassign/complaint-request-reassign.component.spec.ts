import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ComplaintRequestReassignComponent } from './complaint-request-reassign.component';

describe('ComplaintRequestReassignComponent', () => {
  let component: ComplaintRequestReassignComponent;
  let fixture: ComponentFixture<ComplaintRequestReassignComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ComplaintRequestReassignComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComplaintRequestReassignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
