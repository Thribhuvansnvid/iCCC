import { Component, OnDestroy, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { Store } from "@ngrx/store";
import * as fromApp from "../../../store/app.reducer";
import { Subscription } from "rxjs";
import * as ComplaintsActions from "../../store/complaint.actions";

@Component({
  selector: "app-complaint-request-reassign",
  templateUrl: "./complaint-request-reassign.component.html",
  styleUrls: ["./complaint-request-reassign.component.scss"],
})
export class ComplaintRequestReassignComponent implements OnInit, OnDestroy {
  complaintId:string = "";
  userId:string = ""
  roles:string[] = []
  requestReassignReasons:string[] = [
    "Not a valid complaint",
    "Not my responsibility",
    "Absent or on leave",
    "other"
  ];
  remarks:string = ''
  comments = "";

  reasonSelected:number = -1;
  storeSub1: Subscription = null;
  storeSub2: Subscription = null;

  constructor(
    private _activatedRoute: ActivatedRoute,
    private store: Store<fromApp.AppState>,
    private _router: Router
  ) {}

  ngOnInit() {
    this._activatedRoute.params.subscribe((params) => {
      this.complaintId = params["complaintId"];
    });

    
    this.storeSub2 = this.store.select("auth").subscribe(({ user }) => {
      this.userId = user.userId;
    });

    this.storeSub1 = this.store
      .select("complaintRequestReassign")
      .subscribe(({ success, loading, error }) => {
        if (success) {
          this._router.navigate(["/auth/cg/complaint-request-re-assign-ack", this.complaintId]);
        }


        // if (success) {
        //   if(this.roles.includes('GRO')){
        //     this._router.navigate(["/auth/cg/gro/list", this.complaintId]);
        //   }else if(this.roles.includes('RO')){
        //     this._router.navigate(["/auth/cg/ro/list", this.complaintId]);
        //   }
        // }
      });

  }

  ngOnDestroy() {
    this.storeSub1 && this.storeSub1.unsubscribe();
    this.storeSub2 && this.storeSub2.unsubscribe();
  }

  onClickCancel() {
    this._router.navigate(["/auth/cg/details", this.complaintId]);
  }

  onClickRequestReAssign(){
    if(this.reasonSelected === -1 && this.remarks === ""){
      return
    }
    const reason =
      this.reasonSelected > -1 ? this.requestReassignReasons[this.reasonSelected] : "";
    let data = {
      complaintId: this.complaintId,
      complaintUpdatedBy: this.userId,
      complaintStatus: "Reassign",
      reason: reason,
      remarks: this.remarks,
    };
    this.store.dispatch(new ComplaintsActions.ComplaintRequestReassignStart(data));
  }
}
