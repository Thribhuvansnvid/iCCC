import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ComplaintReopenComponent } from './complaint-reopen.component';

describe('ComplaintReopenComponent', () => {
  let component: ComplaintReopenComponent;
  let fixture: ComponentFixture<ComplaintReopenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ComplaintReopenComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComplaintReopenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
