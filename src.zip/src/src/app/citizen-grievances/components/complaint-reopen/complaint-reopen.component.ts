import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Store } from "@ngrx/store";
import { NgxImageCompressService } from 'ngx-image-compress';
import { Subscription } from 'rxjs';
import * as fromApp from "../../../store/app.reducer";
import * as ComplaintsActions from "../../store/complaint.actions";
import { ComplaintStatus } from '../../models/constants';

@Component({
  selector: 'app-complaint-reopen',
  templateUrl: './complaint-reopen.component.html',
  styleUrls: ['./complaint-reopen.component.scss']
})
export class ComplaintReopenComponent implements OnInit, OnDestroy {

  // complaintStatus:ComplaintStatus;
  reOpenReasons:string[] = [
    "No work was done",
    "Only partial work was done",
    "Employee did not turn up",
    "No permanent solution"
  ];
  reasonSelected:number = -1;
  storeSub1: Subscription = null;
  storeSub2: Subscription = null;
  storeSub3: Subscription = null;
  storeSub4: Subscription = null;


  userId:string = ""

  remarks:string = "";
  loading:boolean = null;
  error:string = ""

  imgURL: any = [];
  images: any = [];

  complaintId = "";
  constructor(
    private _activatedRoute: ActivatedRoute,
    private store: Store<fromApp.AppState>,
    private _router: Router,
    private imageCompress: NgxImageCompressService
  ) { }

  ngOnInit() {
    this._activatedRoute.params.subscribe((params) => {
      this.complaintId = params["complaintId"];
    });

    this.storeSub2 = this.store.select("auth").subscribe(({ user }) => {
      this.userId = user.userId;
    });

    this.storeSub3 = this.store
    .select("complaintReOpen")
    .subscribe(({ success, loading, error }) => {
      this.loading = loading;
      this.error = error;

      if (success) {
        if (this.images.length > 0) {
          const formData = new FormData();
          for (let img of this.images) {
            formData.append("files", img);
          }
          formData.append("complaintId", this.complaintId);
          formData.append("complaintStatus", ComplaintStatus.REOPEN);

          this.store.dispatch(
            new ComplaintsActions.ComplaintUploadReOpenFilesStart(formData)
          );
        }

        this._router.navigate(["/auth/cg/complaint-reopen-ack", this.complaintId]);

        // this._router.navigate([
        //   "/auth/cg/complaint-submitted",
        //   createdComplaintId,
        // ]);
      }
    });


    this.storeSub4 = this.store
    .select("uploadReOpenFilesComplaint")
    .subscribe(({ success, loading, error }) => {
      this.loading = loading;
      this.error = error;

      if (success) {
        // this._router.navigate(["/auth/cg/complaint-submitted", createdComplaintId]);
      }
    });

  }

  ngOnDestroy(){
    this.storeSub1 && this.storeSub1.unsubscribe();
    this.storeSub2 && this.storeSub2.unsubscribe();
    this.storeSub3 && this.storeSub3.unsubscribe();
    this.storeSub4 && this.storeSub4.unsubscribe();
  }

  onClickSumbitReOpen() {
    const reason =
      this.reasonSelected > -1 ? this.reOpenReasons[this.reasonSelected] : "";
    let data = {
      complaintId: this.complaintId,
      complaintUpdatedBy: this.userId,
      complaintStatus: ComplaintStatus.REOPEN,
      reason: reason,
      remarks: this.remarks,
    };
    this.store.dispatch(new ComplaintsActions.ComplaintReOpenStart(data));
  }

  removeImage(index) {
    if (index > -1) {
      this.imgURL.splice(index, 1);
    }
  }
  
  onClickCancel() {
    this._router.navigate(["/auth/cg/details", this.complaintId]);
  }
  
  onFileSelected(event) {
    // this.selectedFile = <File>event.target.files[0];
    // console.log(this.selectedFile)

    const files: File[] = event.target.files;
    if (files.length === 0) return;

    for (let file of files) {
      let mimeType = file.type;
      if (mimeType.match(/image\/*/) == null) {
        console.log("Only images are supported.");
        return;
      }
    }

    for (let file of files) {
      this.images.push(file);

      const fileName = file["name"];

      let reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (event) => {
        this.imgURL.push(reader.result);
        // const localUrl = event.target.result;
        // this.compressFile( localUrl, fileName);
      };
    }

    console.log(`images length ${this.imgURL.length}`);

    // var mimeType = files[0].type;
    // if (mimeType.match(/image\/*/) == null) {
    //   console.log('Only images are supported.')
    //   return;
    // }

    // var reader = new FileReader();
    // // this.imagePath = files;
    // reader.readAsDataURL(files[0]);
    // reader.onload = (_event) => {
    //   this.imgURL = reader.result;
    // }
  }

  compressFile(image, fileName) {
    var orientation = -1;
    // var sizeOfOriginalImage =
    //   this.imageCompress.byteCount(image) / (1024 * 1024);

    this.imageCompress
      .compressFile(image, orientation, 50, 50)
      .then((result) => {
        // this.imgResultAfterCompress = result;
        // this.localCompressedURl = result;
        // var sizeOFCompressedImage =
        //   this.imageCompress.byteCount(result) / (1024 * 1024);

        //   this.filesDetails.push({
        //     'fileName': fileName,
        //     'sizeBeforeCompression':` ${sizeOfOriginalImage.toFixed(2)} MB`,
        //     'sizeAfterCompression':`${sizeOFCompressedImage.toFixed(2)} MB`,
        //   })
        // const imageName = fileName;
        // const imageBlob = this.dataURItoBlob(
        //   this.imgResultAfterCompress.split(",")[1]
        // );
        const imageFile = new File([result], fileName, { type: "image/jpeg" });

        // this.multipleImages.push(imageFile)
        this.images.push(imageFile);
      });
  }

  dataURItoBlob(dataURI) {
    const byteString = window.atob(dataURI);
    const arrayBuffer = new ArrayBuffer(byteString.length);
    const int8Array = new Uint8Array(arrayBuffer);
    for (let i = 0; i < byteString.length; i++) {
      int8Array[i] = byteString.charCodeAt(i);
    }
    const blob = new Blob([int8Array], { type: "image/jpeg" });
    return blob;
  }

}
