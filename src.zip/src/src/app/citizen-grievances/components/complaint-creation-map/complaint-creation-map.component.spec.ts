import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ComplaintCreationMapComponent } from './complaint-creation-map.component';

describe('ComplaintCreationMapComponent', () => {
  let component: ComplaintCreationMapComponent;
  let fixture: ComponentFixture<ComplaintCreationMapComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ComplaintCreationMapComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComplaintCreationMapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
