import { Component, OnInit, EventEmitter, Output } from "@angular/core";
import { GISService } from "../../../GIS/md-gis/intf-gis.service";
@Component({
  selector: "app-complaint-creation-map",
  templateUrl: "./complaint-creation-map.component.html",
  styleUrls: ["./complaint-creation-map.component.css"],
})
export class ComplaintCreationMapComponent implements OnInit {
  coordinate: string = "";
  address: string = "";
  closeMap: boolean = false;
  @Output() addressEmitter: EventEmitter<any> = new EventEmitter();
  constructor(private gisService: GISService) {}

  ngOnInit() {}
  getLocation(): void {
    // this.gisService.getCoordinate().subscribe((data) => {
    //   this.coordinate = data;
    //   this.gisService
    //     .getAddressFromCoordinate(this.coordinate)
    //     .then((res) => {
    //       console.log(res);
    //       this.addressEmitter.emit("res");
    //     })
    //     .catch((error) => {
    //       console.log(error);
    //     });
    // });

    this.closeMap = true;
  }
}
