import { Component, OnDestroy, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { Store } from "@ngrx/store";
import * as fromApp from "../../../store/app.reducer";
import { Subscription } from "rxjs";
import * as ComplaintsActions from "../../store/complaint.actions";

@Component({
  selector: "app-complaint-reject",
  templateUrl: "./complaint-reject.component.html",
  styleUrls: ["./complaint-reject.component.scss"],
})
export class ComplaintRejectComponent implements OnInit, OnDestroy {
  constructor(
    private _activatedRoute: ActivatedRoute,
    private store: Store<fromApp.AppState>,
    private _router: Router
  ) {}

  remarks:string = "";
  complaintId:string = "";
  storeSub1: Subscription = null;
  storeSub2: Subscription = null;
  reasonSelected = -1;

  userId: string = "";

  rejectReasons = [
    "Not a valid complaint",
    "Out of operational scope",
    "other",
  ];

  ngOnInit() {
    this._activatedRoute.params.subscribe((params) => {
      this.complaintId = params["complaintId"];
    });

    this.storeSub2 = this.store.select("auth").subscribe(({ user }) => {
      this.userId = user.userId;
    });

    this.storeSub1 = this.store
      .select("complaintReject")
      .subscribe(({ success, loading, error }) => {
        if (success) {
          this._router.navigate(["/auth/cg/complaint-reject-ack", this.complaintId]);
          // this._router.navigate(["/auth/cg/gro/list"]);
        }
      });
  }

  ngOnDestroy() {
    this.storeSub1 && this.storeSub1.unsubscribe();
    this.storeSub2 && this.storeSub2.unsubscribe();
  }

  onClickCancel() {
    this._router.navigate(["/auth/cg/details", this.complaintId]);
  }

  onClickSumbitReject() {
    if(this.reasonSelected === -1 && this.remarks === ""){
      return
    }
    
    const reason =
      this.reasonSelected > -1 ? this.rejectReasons[this.reasonSelected] : "";
    let data = {
      complaintId: this.complaintId,
      complaintUpdatedBy: this.userId,
      complaintStatus: "Rejected",
      reason: reason,
      remarks: this.remarks,
    };
    this.store.dispatch(new ComplaintsActions.ComplaintRejectStart(data));
  }
}
