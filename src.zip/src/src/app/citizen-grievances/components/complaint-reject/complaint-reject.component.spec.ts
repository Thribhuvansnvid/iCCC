import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ComplaintRejectComponent } from './complaint-reject.component';

describe('ComplaintRejectComponent', () => {
  let component: ComplaintRejectComponent;
  let fixture: ComponentFixture<ComplaintRejectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ComplaintRejectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComplaintRejectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
