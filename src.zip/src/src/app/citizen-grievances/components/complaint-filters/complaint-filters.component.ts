import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Subscription } from 'rxjs';
import { User } from 'src/app/login/models/user.model';
import { SpinnerOverlayService } from 'src/app/shared/spinner-overlay/spinner-overlay.service';
import { Store } from '@ngrx/store';
import * as fromApp from "../../../store/app.reducer";
import { ComplaintListFilters } from '../../models/complaint.list.filters';
import * as ComplaintsActions from "../../store/complaint.actions";
import {
  DateTimeAdapter,
  OWL_DATE_TIME_FORMATS,
  OWL_DATE_TIME_LOCALE,
} from 'ng-pick-datetime'
import * as moment from 'moment'
export const MY_CUSTOM_FORMATS = {
  fullPickerInput: 'YYYY-MM-DD HH:mm:ss',
  parseInput: 'YYYY-MM-DD HH:mm:ss',
  datePickerInput: 'YYYY-MM-DD HH:mm:ss',
  timePickerInput: 'LT',
  monthYearLabel: 'MMM YYYY',
  dateA11yLabel: 'LL',
  monthYearA11yLabel: 'MMMM YYYY',
}
import { MomentDateTimeAdapter } from 'ng-pick-datetime/date-time/adapter/moment-adapter/moment-date-time-adapter.class'
import { Timeline } from '@swimlane/ngx-charts';
import { ComplaintTimeline } from '../../models/constants';

@Component({
  selector: 'complaint-filters',
  templateUrl: './complaint-filters.component.html',
  styleUrls: ['./complaint-filters.component.scss'],
  providers: [
    {
      provide: DateTimeAdapter,
      useClass: MomentDateTimeAdapter,
      deps: [OWL_DATE_TIME_LOCALE],
    },
    { provide: OWL_DATE_TIME_FORMATS, useValue: MY_CUSTOM_FORMATS },
  ],
})
export class ComplaintFiltersComponent implements OnInit {
  hideRequiredControl = new FormControl(false);
  floatLabelControl = new FormControl("always");
  storeSub1: Subscription = null;

  selectable = true;
  removable = true;
  addOnBlur = true;

  fromDateTime = "";
  toDateTime = "";
  selectedFilterOptions: any[] = [];

  departmentList = [
    { name: 'SWM', value: false },
    { name: 'VMD', value: false },
    { name: 'VMS', value: false },
    { name: 'REVENUE', value: false }
  ]

  timeLineList = [
    // { name: 'Last 7 Hours', value: 0 },
    { name: 'Live (Last 10 Hrs)', value: 0 },
    { name: 'Last 2 Days', value: 1 },
    { name: 'Last 3 Days', value: 2 },
    { name: 'Last 1 Week', value: 3 },
    { name: 'Last 1 Month', value: 4 },
    { name: 'Select Date', value: 5 },
  ]
  timeLineSelected = 4;

  ROList = [
    { name: 'RO1', value: false },
    { name: 'RO2', value: false },
    { name: 'RO3', value: false },
    { name: 'RO4', value: false },
    { name: 'RO5', value: false }
  ]
  searchText = ""
  loggedInUser: User = null;
  _complaintListFilters = new ComplaintListFilters('GRO')

  constructor(private store: Store<fromApp.AppState>, private spinnerOverlayService: SpinnerOverlayService, private ref: ChangeDetectorRef) { }

  ngOnInit() {

    this.storeSub1 = this.store
      .select("auth")
      .subscribe(({ user }) => {
        this.loggedInUser = user;

        this._complaintListFilters.stateName = this.loggedInUser.state
        this._complaintListFilters.districtCity = this.loggedInUser.districtCity

        if (user) {

          this.fetchComplaints();
        }
      });

    // this.searchForm = this.formBuilder.group({
    //   mobileNumber: [""],
    //   complaintNumber: [""],
    // });
  }

  fetchComplaints() {
    // const fromDate = '2020-02-25 00:10:00'
    // const toDate = moment().format('YYYY-MM-DD HH:mm:ss')
    this.setTimeline()
    // this._complaintListFilters.fromDate = fromDate
    // this._complaintListFilters.toDate = toDate
    // console.log(1)
    // console.log(1)
    localStorage.setItem('complaintsFilters', JSON.stringify(this._complaintListFilters))

    this.spinnerOverlayService.show();
    this.store.dispatch(
      new ComplaintsActions.ComplaintsFetchStart(this._complaintListFilters)
    );
  }

  timelineRadioChange(event){
    this.fetchComplaints();
  }

  setTimeline() {
    if(this.timeLineSelected === ComplaintTimeline.SELECT_DATE){
      return;
    }
    let toDateTime = moment(new Date()).format("YYYY-MM-DD HH:mm:ss");
    let fromDatetime = "";

    switch (this.timeLineSelected) {
      case ComplaintTimeline.LIVE: {
        fromDatetime = moment()
          .subtract(10, "h")
          .format("YYYY-MM-DD HH:mm:ss");
        break;
      }
      case ComplaintTimeline.LAST_2_DAYS: {
        fromDatetime = moment()
          .subtract(2, "d")
          .format("YYYY-MM-DD HH:mm:ss");
        break;
      }
      case ComplaintTimeline.LAST_3_DAYS: {
        fromDatetime = moment()
          .subtract(3, "d")
          .format("YYYY-MM-DD HH:mm:ss");
        break;
      }
      case ComplaintTimeline.LAST_1_WEEK: {
        fromDatetime = moment()
          .subtract(1, "week")
          .format("YYYY-MM-DD HH:mm:ss");
        break;
      }
      case ComplaintTimeline.LAST_1_MONTH: {
        fromDatetime = moment()
          .subtract(1, "month")
          .format("YYYY-MM-DD HH:mm:ss");
        break;
      }
      default : break;

    }
    this._complaintListFilters.fromDate = fromDatetime
    this._complaintListFilters.toDate = toDateTime;
    console.log(1)
  }

  onChangeDatetime(){
    this.ref.detectChanges();
    if(this.timeLineSelected === ComplaintTimeline.SELECT_DATE && (this.fromDateTime && this.toDateTime )){
      // if(this.timeLineSelected === ComplaintTimeline.SELECT_DATE ){
      this._complaintListFilters.fromDate  = moment(this.fromDateTime).format("YYYY-MM-DD HH:mm:ss");
      this._complaintListFilters.toDate = moment(this.toDateTime).format("YYYY-MM-DD HH:mm:ss");

      // if(this.fromDateTime && this.toDateTime ){
      //   this.fetchComplaints();
      // }

      if(this._complaintListFilters.fromDate && this._complaintListFilters.toDate){
        this.fetchComplaints();
      }
    }
  }

  // onChangeToDate(){
  //   if(this.timeLineSelected === ComplaintTimeline.SELECT_DATE &&(this.fromDateTime && this.toDateTime) ){
  //     this._complaintListFilters.fromDate  = moment(this.fromDateTime).format("YYYY-MM-DD HH:mm:ss");
  //     this._complaintListFilters.toDate = moment(this.toDateTime).format("YYYY-MM-DD HH:mm:ss");

  //     this.fetchComplaints();
  //   }
  // }

  removeSelection(event, index) {
    if (event.type === 'Department') {
      let itemIndex = this.departmentList.findIndex(item => item.name === event.name)
      this.departmentList[itemIndex].value = false
    }

    if (event.type === 'RoList') {
      let itemIndex = this.ROList.findIndex(item => item.name === event.name)
      this.ROList[itemIndex].value = false
    }

    this.selectedFilterOptions.splice(index, 1);

  }


  onChangeDepartmentSelection(index) {
    this.departmentList[index].value = !this.departmentList[index].value

    if (this.departmentList[index].value) {
      this.selectedFilterOptions.push({
        type: "Department",
        name: this.departmentList[index].name
      })
    } else {
      let itemIndex = this.selectedFilterOptions.findIndex(item => item.type === 'Department' && item.name === this.departmentList[index].name);
      if (itemIndex > -1) {
        this.selectedFilterOptions.splice(itemIndex, 1);
      }
    }
    console.log(this.selectedFilterOptions)
  }

  onChangeRoSelection(index) {
    this.ROList[index].value = !this.ROList[index].value

    if (this.ROList[index].value) {
      this.selectedFilterOptions.push({
        type: "RoList",
        name: this.ROList[index].name
      })
    } else {
      let itemIndex = this.selectedFilterOptions.findIndex(item => item.type === 'RoList' && item.name === this.departmentList[index].name);
      if (itemIndex > -1) {
        this.selectedFilterOptions.splice(itemIndex, 1);
      }
    }
  }

  // formatDates() {
  //   this.fromDateTime = moment(
  //     this.fromDateTime
  //   ).format('YYYY-MM-DD HH:mm:ss')

  //   this.toDateTime = moment(
  //     this.toDateTime
  //   ).format('YYYY-MM-DD HH:mm:ss')
  // }


  resetAllFilter() {
    this.selectedFilterOptions = [];

    this.departmentList = [
      { name: 'SWM', value: false },
      { name: 'VMD', value: false },
      { name: 'VMS', value: false },
      { name: 'REVENUE', value: false }
    ]


    this.ROList = [
      { name: 'RO1', value: false },
      { name: 'RO2', value: false },
      { name: 'RO3', value: false },
      { name: 'RO4', value: false },
      { name: 'RO5', value: false }
    ]

  }
}
