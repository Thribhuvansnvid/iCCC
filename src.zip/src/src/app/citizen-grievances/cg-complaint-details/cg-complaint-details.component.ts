import { Component, OnInit } from '@angular/core'
import { ActivatedRoute, Router } from '@angular/router'
// import { CustomMatIconService } from "src/app/shared/services/custom-icon.service";
import { Complaint } from '../models/complaint.model'
import { ComplaintsFilter } from '../models/complaints.filter.model'
import { ComplaintService } from '../services/citizen.grievance.service'

@Component({
  selector: 'app-cg-complaint-details',
  templateUrl: './cg-complaint-details.component.html',
  styleUrls: ['./cg-complaint-details.component.scss'],
})
export class CgComplaintDetailsComponent implements OnInit {
  state_name = ''
  district_city = ''


  _complaint: Complaint = new Complaint()
  _loadingComplaints: boolean = true
  _complaintId: number = 0
  _respondersList: any[] = null
  constructor(
    private _activatedRoute: ActivatedRoute,
    private _complaintService: ComplaintService,
    // private _customMatIconService: CustomMatIconService,
    private _router: Router
  ) {}

  ngOnInit() {


    this._activatedRoute.params.subscribe((params) => {
      this._complaintService.onChangeComplaints.subscribe((filter) => {
        this.state_name = filter.state_name
        this.district_city = filter.district_city

        this._complaintId = Number.parseInt(params['complaintId'])
        this.getResponders()
        this.loadComplaintData(this._complaintId)
      })
    })
  }

  loadComplaintData(complaintId) {
    this._loadingComplaints = true
    this._complaint = new Complaint()
    let complaintsFilter = new ComplaintsFilter()
    complaintsFilter.no_of_records = 50
    complaintsFilter.page_index = 1

    complaintsFilter.state_name = this.state_name
    complaintsFilter.district_city = this.district_city

    complaintsFilter.user_id = 'rajani'
    complaintsFilter.front_end = 'WEB'
    complaintsFilter.complaint_id = complaintId

    this._complaintService
      .getComplaintDetails(complaintsFilter)
      .then((res: { complaints: Complaint[]; totalcount: number }) => {
        if (res.totalcount) {
          this._complaint = res.complaints[0]
        } else {
        }
        this._loadingComplaints = false
      })
      .catch((error) => {
        console.log(error)
        this._loadingComplaints = false
      })
  }

  viewImages() {
    if (this._complaint.attachments) {
      this._router.navigate(['/auth/cg/images', this._complaint.complaint_id])
    }
  }

  onselectionSeverity(severity: string) {
    if (this._complaint.severity == severity) {
      return
    }

    const variable = {
      complaint_id: this._complaintId,
      user_id: 'rajani',
      severity: severity,

      // "complaint_id":81,
      // "user_id" : "rajani",
      // "severity":"LOW"
    }

    this._complaintService
      .updateComplaint(variable)
      .then((res) => {
        this.drawComplaintsOnMap()
        this.loadComplaintData(this._complaintId)
      })
      .catch((error) => {})
  }

  onselectionResponder(responder) {
    // if (!(this._respondersList.filter(item => item.staff_id === responder.staff_id).length > 0)){
    //   return;
    // }

    // if(this._respondersList.length){
    let responders = []
    if (this._complaint.responders) {
      this._complaint.responders.push(responder)
      responders = this._complaint.responders
    } else {
      responders.push(responder)
    }

    const variable = {
      complaint_id: this._complaintId,
      user_id: 'rajani',
      responders: responders,
    }

    this._complaintService
      .updateComplaint(variable)
      .then((res) => {
        this.drawComplaintsOnMap()
        this.loadComplaintData(this._complaintId)
      })
      .catch((error) => {})
    // }
    // else{

    //   const variable = {
    //     complaint_id: this._complaintId,
    //     user_id : 'rajani',
    //     responders: [responder],
    //   };

    //   this._complaintService
    //   .updateComplaint(variable)
    //   .then((res) => {
    //     this.drawComplaintsOnMap();
    //     this.loadComplaintData(this._complaintId);
    //   })
    //   .catch((error) => {});
    // }
  }

  onselectionStatus(status: string) {
    if (this._complaint.complaint_status == status) {
      return
    }

    const variable = {
      complaint_id: this._complaintId,
      user_id: 'rajani',
      complaint_status: status,
    }

    this._complaintService
      .updateComplaint(variable)
      .then((res) => {
        this.drawComplaintsOnMap()
        this.loadComplaintData(this._complaintId)
      })
      .catch((error) => {})
  }

  getResponders() {
    this._complaintService
      .getResponders(this._complaintId)
      .then((res: any) => {
        this._respondersList = res
        // this.loadComplaintData(this._complaintId);
      })
      .catch((error) => {})
  }

  drawComplaintsOnMap() {
    this._complaintService
      .drawComplaintsOnMap({
        state_name: this.state_name,
        district_city: this.district_city,
      })
      // .drawComplaintsOnMap('rajani')
      .then((res) => {
        console.log('Successfully drawn complaints on map')
      })
      .catch((error) => {
        console.log('Error while drawing complaints on map')
      })
  }
}
