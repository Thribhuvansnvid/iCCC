import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CgComplaintDetailsComponent } from './cg-complaint-details.component';

describe('CgComplaintDetailsComponent', () => {
  let component: CgComplaintDetailsComponent;
  let fixture: ComponentFixture<CgComplaintDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CgComplaintDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CgComplaintDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
