import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FlexLayoutModule } from "@angular/flex-layout";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { NgApexchartsModule } from 'ng-apexcharts'
import { SharedModule } from "../shared/shared.module";
import { MaterialModule } from "../shared/material/material.module";
import { CitizenGrievancesRoutes } from "./citizen-grievances.routes";
import { CgLayoutComponent } from "./cg-layout/cg-layout.component";
import { CgMapComponent } from "./cg-map/cg-map.component";
import { CgNavbarComponent } from "./cg-navbar/cg-navbar.component";
import { CgSideNavComponent } from "./cg-side-nav/cg-side-nav.component";
import { CgHomePageComponent } from './cg-home-page/cg-home-page.component';
import { CgMapLegendComponent } from './cg-map-legend/cg-map-legend.component';
import { CgKpiComponent } from './cg-kpi/cg-kpi.component';
import { CgComplaintsListComponent } from './cg-complaints-list/cg-complaints-list.component';
import { ComplaintService } from './services/citizen.grievance.service';
import { CgComplaintDetailsComponent } from './cg-complaint-details/cg-complaint-details.component';
import { CgComplaintImageViewerComponent } from './cg-complaint-image-viewer/cg-complaint-image-viewer.component';
import { ComplaintEmployeeMainpageComponent } from './components/complaint-employee-mainpage/complaint-employee-mainpage.component';
import { ComplaintsListComponent } from './components/complaints-list/complaints-list.component';
import { ComplaintDetailsComponent } from './components/complaint-details/complaint-details.component';

import { PerfectScrollbarModule } from "ngx-perfect-scrollbar";
import { ComplaintCreationComponent } from './components/complaint-creation/complaint-creation.component';
// import { ComplaintImageViewerComponent } from './components/complaint-image-viewer/complaint-image-viewer.component';
import { ComplaintTimelineComponent } from './components/complaint-timeline/complaint-timeline.component';
import { ComplaintChatComponent } from './components/complaint-chat/complaint-chat.component';
import { ComplaintFeedbackComponent } from './components/complaint-feedback/complaint-feedback.component';
import { ComplaintSubmittedComponent } from './components/complaint-submitted/complaint-submitted.component';
import { ComplaintResolvedComponent } from './components/complaint-resolved/complaint-resolved.component';
import { ComplaintInfoComponent } from './components/complaint-info/complaint-info.component';
import { ComplaintCitizenMainpageComponent } from './components/complaint-citizen-mainpage/complaint-citizen-mainpage.component'
import { ComplaintAssignComponent } from './components/complaint-assign/complaint-assign.component';
import { ComplaintReopenComponent } from './components/complaint-reopen/complaint-reopen.component';
import { ComplaintRequestReassignComponent } from './components/complaint-request-reassign/complaint-request-reassign.component';
import { ComplaintReopenAcknowledgeComponent } from './components/complaint-reopen-acknowledge/complaint-reopen-acknowledge.component';
import { ComplaintRejectComponent } from './components/complaint-reject/complaint-reject.component';
import {NgxImageCompressService} from 'ngx-image-compress';
import { CgReportsComponent } from './cg-reports/cg-reports.component';
import { ComplaintCitizenListComponent } from './components/complaint-citizen-list/complaint-citizen-list.component'
import { ComplaintsRoListComponent } from "./components/complaints-ro-list/complaints-ro-list.component";
import { ComponentListItemComponent } from './components/complaint-list-item/complaint-list-item.component';

import { ComplaintsMapViewComponent } from './components/complaints-map-view/complaints-map-view.component';
import { ComplaintRejectAcknowledgeComponent } from "./components/complaint-reject-acknowledge/complaint-reject-acknowledge.component";
import { ComplaintRequestReAssignAcknowledgeComponent } from "./components/complaint-request-reassign-acknowledge/complaint-request-reassign-acknowledge.component";
import { ComplaintResolvedAcknowledgeComponent } from "./components/complaint-resolved-acknowledge/complaint-resolved-acknowledge.component";
import { ComplaintAssignAcknowledgeComponent } from "./components/complaint-assign-acknowledge/complaint-assign-acknowledge.component";
import { CgMainpageComponent } from "./cg-mainpage/cg-mainpage.component";
// import { ComplaintImageViewerOverlayService } from './components/complaint-image-viewer-overlay/complaint-image-viewer.service';
// import { ComplaintImageViewerComponent } from './components/complaint-image-viewer-overlay/complaint-image-viewer.component';
import { MatCarouselModule } from '@ngmodule/material-carousel';
import { ComplaintStatusPieChartComponent } from "./components/charts/complaint-status-pie-chart/complaint-status-pie-chart.component";
import { ComplaintStatusLineChartComponent } from "./components/charts/complaint-status-line-chart/complaint-status-line-chart.component";
// import { ComplaintPieChartComponent } from './components/charts/complaint-pie-chart/complaint-pie-chart.component';
import { RatingModule } from 'ng-starrating';
import { AngularMultiSelectModule } from "angular2-multiselect-dropdown";
import { ComplaintFiltersDialogComponent } from "./components/dialogs/complaint-filters/complaint-filters.dialog.component";
import { ComplaintFiltersRoComponent } from "./components/complaint-filters-ro/complaint-filters-ro.component";
import { ComplaintListFooterComponent } from "./components/complaint-list-footer/complaint-list-footer.component";
import { ComplaintFiltersComponent } from "./components/complaint-filters/complaint-filters.component";
import { OwlDateTimeModule, OwlNativeDateTimeModule } from "ng-pick-datetime";
import { ComplaintCreationMapComponent } from "./components/complaint-creation-map/complaint-creation-map.component";
import { MdGisModule } from "../GIS/md-gis/md-gis.module";

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    FlexLayoutModule,
    MaterialModule,
    SharedModule,
    CitizenGrievancesRoutes,
    NgApexchartsModule,
    MatCarouselModule.forRoot(),
    RatingModule,
    AngularMultiSelectModule,
    OwlDateTimeModule,
    OwlNativeDateTimeModule,
    MdGisModule
    // PerfectScrollbarModule
  ],
  declarations: [
    CgLayoutComponent,
    CgMapComponent,
    CgNavbarComponent,
    CgSideNavComponent,
    CgHomePageComponent,
    CgMapLegendComponent,
    CgKpiComponent,
    CgComplaintsListComponent,
    CgComplaintDetailsComponent,
    CgComplaintImageViewerComponent,
    ComplaintEmployeeMainpageComponent,
    ComplaintsListComponent,
    ComplaintDetailsComponent,
    ComplaintCreationComponent,
    ComplaintTimelineComponent,
    ComplaintChatComponent,
    ComplaintFeedbackComponent,
    ComplaintSubmittedComponent,
    ComplaintResolvedComponent,
    ComplaintInfoComponent,
    ComplaintAssignComponent,
    ComplaintReopenComponent,
    ComplaintRequestReassignComponent,
    ComplaintReopenAcknowledgeComponent,
    ComplaintRejectComponent,
    ComplaintCitizenMainpageComponent,
    CgReportsComponent,
    ComplaintCitizenListComponent,
    ComplaintsRoListComponent,
    ComponentListItemComponent,
    CgMainpageComponent,
    ComplaintsMapViewComponent,
    ComplaintRejectAcknowledgeComponent,
    ComplaintRequestReAssignAcknowledgeComponent,
    ComplaintResolvedAcknowledgeComponent,
    ComplaintAssignAcknowledgeComponent,
    ComplaintStatusPieChartComponent, 
    ComplaintStatusLineChartComponent,

    ComplaintFiltersDialogComponent,
    ComplaintFiltersRoComponent, 
    ComplaintListFooterComponent,
    ComplaintFiltersComponent,
    ComplaintCreationMapComponent
    // ComplaintImageViewerComponent
    // ComplaintPieChartComponent
    // ChatComponent
  ],
	providers: [
		ComplaintService,
    NgxImageCompressService,
    // ComplaintImageViewerOverlayService
	],
  entryComponents: [ComplaintFiltersDialogComponent],  
  

})
export class CitizenGrievancesModule {}
