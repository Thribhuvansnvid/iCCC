import { ComplaintSortBy, ComplaintStatusDisplayed, ComplaintStatusList } from "./constants"

export class ComplaintListFilters {
    public stateName: string
    public districtCity: string
    public pageIndex: number
    public pageSize: number
    public sortBy: string
    public complaintAssignedTo: string
    public complaintStatusSelected: number
    public userId: string
    public fromDate: string
    public toDate: string

    constructor(role = 'GRO'
    ) {
        this.stateName = ''
        this.districtCity = ''
        this.pageIndex = 0;
        this.pageSize = 50;
        this.sortBy = ComplaintSortBy.REGISTRATION_DATE
        this.complaintAssignedTo = null;
        this.complaintStatusSelected = role === 'GRO' ? ComplaintStatusDisplayed.ALL : role === 'RO' ? ComplaintStatusDisplayed.ALL : role === 'CIVILIAN' ? ComplaintStatusDisplayed.ALL : 0
        this.userId = null,
        this.fromDate = "",
        this.toDate = ""
    }

    getComplaintStatuslist() {
        return ComplaintStatusList[this.complaintStatusSelected]
    }
}
