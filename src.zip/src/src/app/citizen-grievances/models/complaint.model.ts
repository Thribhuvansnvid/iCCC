export class Complaint {
  state_name: string = null;
  district_city: string = null;
  ward_name: string = null;
  area_village: string = null;
  complaint_id: number = 0;
  user_id: string = null;
  received_time: string = null;
  description: string = null;
  severity: string = null;
  geocoordinates: any = null;
  smart_vertical: string = null;
  complaint_status: string = null;
  feedback_description:string = null;
  feedback_rating:string = null;
  last_updated_by:string = null;
  last_updated_time:string = null;
  process_time:number = null;
  received_day:string = null;
  sop_id:string = null;
  sop_instanceid:string = null;
  sop_name:string = null;
  sop_status:string = null;
  users_assigned_to:string = null;
  attachments:any = null;
  closed_time:string = null;
  responders:any = null;
}


