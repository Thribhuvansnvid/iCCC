export enum ComplaintStatus {
  OPEN = "Open",
  ASSIGNED = "Assigned",
  REJECTED = "Rejected",
  CLOSED = "Closed",
  REOPEN = "Reopened",
  REASSIGN = "Reassigned",
  RESOLVED = "Resolved",
}

export enum ComplaintStatusDisplayed {
  // ALL = "All Complaints",
  // UNASSIGNED = "Unassigned",
  // ASSIGNED = "Assigned",
  // CLOSED = "Closed",
  // OPEN = "Open",

  ALL = 0,
  UNASSIGNED = 1,
  ASSIGNED = 2,
  CLOSED = 3,
  OPEN = 4,

}

export const ComplaintStatusList = {
  [ComplaintStatusDisplayed.UNASSIGNED]: [ComplaintStatus.OPEN, ComplaintStatus.REOPEN],
  [ComplaintStatusDisplayed.ASSIGNED]: [ComplaintStatus.ASSIGNED],
  [ComplaintStatusDisplayed.CLOSED]: [ComplaintStatus.CLOSED, ComplaintStatus.REJECTED],
  [ComplaintStatusDisplayed.OPEN]: [ComplaintStatus.OPEN, ComplaintStatus.REOPEN],
  [ComplaintStatusDisplayed.ALL]: [
    ComplaintStatus.OPEN,
    ComplaintStatus.REOPEN,
    ComplaintStatus.CLOSED,
    ComplaintStatus.REJECTED,
    ComplaintStatus.ASSIGNED,
  ],

  // Unassigned: [ComplaintStatus.OPEN, ComplaintStatus.REOPEN],
  // Assigned: [ComplaintStatus.ASSIGNED],
  // Closed: [ComplaintStatus.CLOSED, ComplaintStatus.REJECTED],
  // Open: [ComplaintStatus.OPEN, ComplaintStatus.REOPEN],
  // "All Complaints": [
  //   ComplaintStatus.OPEN,
  //   ComplaintStatus.REOPEN,
  //   ComplaintStatus.CLOSED,
  //   ComplaintStatus.REJECTED,
  //   ComplaintStatus.ASSIGNED,
  // ],
};


export enum ComplaintSortBy {
  REGISTRATION_DATE = "complaintRegistrationDate",
}


export enum ComplaintTimeline {
  LIVE = 0,
  LAST_2_DAYS = 1,
  LAST_3_DAYS = 2,
  LAST_1_WEEK = 3,
  LAST_1_MONTH = 4,
  SELECT_DATE = 5,
}

