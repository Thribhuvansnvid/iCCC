export class ComplaintsFilter {
  user_id: string = null;
  page_index: number = 0;
  no_of_records: number = 0;
  front_end: string = null;
  from_date: string = null;
  to_date: string = null;
  ward_name: string = null;
  area_village: string = null;
  smart_vertical: string = null;
  severity: string = null;
  complaint_id: number = null;
  complaint_status: string = null;
  state_name: string = null;
  district_city: string = null;
  SOP_STATUS: string = null;
}



