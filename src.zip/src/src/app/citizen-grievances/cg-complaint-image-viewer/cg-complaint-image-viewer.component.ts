import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
// import { CustomMatIconService } from 'src/app/shared/services/custom-icon.service';
import { Complaint } from '../models/complaint.model';
import { ComplaintsFilter } from '../models/complaints.filter.model';
import { ComplaintService } from '../services/citizen.grievance.service';

@Component({
  selector: 'app-cg-complaint-image-viewer',
  templateUrl: './cg-complaint-image-viewer.component.html',
  styleUrls: ['./cg-complaint-image-viewer.component.scss']
})
export class CgComplaintImageViewerComponent implements OnInit {

  constructor(    private _activatedRoute: ActivatedRoute,
    private _complaintService: ComplaintService,
    // private _customMatIconService: CustomMatIconService,
    private _router: Router) { }

    _complaint: Complaint = new Complaint();
    _loadingComplaints: boolean = true;
    _selectedImagesUrl = "";
  ngOnInit() {
    this._activatedRoute.params.subscribe((params) => {
      const complaintId = params["complaintId"];
      console.log(complaintId);

      this._loadingComplaints = true;
      this._complaint = new Complaint();

      let complaintsFilter = new ComplaintsFilter();

      complaintsFilter.no_of_records = 50;
      complaintsFilter.page_index = 1
      complaintsFilter.user_id = "rajani";  
      complaintsFilter.front_end = "WEB";
      complaintsFilter.complaint_id = Number.parseInt(complaintId);

      this._complaintService
        .getComplaintDetails(complaintsFilter)
        .then((res: { complaints: Complaint[]; totalcount: number }) => {
          if (res.totalcount) {
            this._complaint = res.complaints[0];
            this._selectedImagesUrl = res.complaints[0].attachments[0]
          } else {

          }
          this._loadingComplaints = false;
        })
        .catch((error) => {
          console.log(error);
          this._loadingComplaints = false;
        });
    });
  }


  close(){
    this._router.navigate(['/auth/cg/home/complaint', this._complaint.complaint_id]);
  }

  onSelectionImage(imageUrl:string){

  }
}
