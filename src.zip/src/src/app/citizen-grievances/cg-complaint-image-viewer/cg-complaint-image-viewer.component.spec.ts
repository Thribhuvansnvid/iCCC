import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CgComplaintImageViewerComponent } from './cg-complaint-image-viewer.component';

describe('CgComplaintImageViewerComponent', () => {
  let component: CgComplaintImageViewerComponent;
  let fixture: ComponentFixture<CgComplaintImageViewerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CgComplaintImageViewerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CgComplaintImageViewerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
