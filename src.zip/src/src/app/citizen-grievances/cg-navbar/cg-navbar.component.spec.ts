import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CgNavbarComponent } from './cg-navbar.component';

describe('CgNavbarComponent', () => {
  let component: CgNavbarComponent;
  let fixture: ComponentFixture<CgNavbarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CgNavbarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CgNavbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
