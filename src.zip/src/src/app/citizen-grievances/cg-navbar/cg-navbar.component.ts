import { Component, OnInit } from '@angular/core'
import { Router } from '@angular/router'
import { AppConfigService } from 'src/app/shared/configs-loader/app.config.service'
import { ComplaintsFilter } from '../models/complaints.filter.model'
import { ComplaintService } from '../services/citizen.grievance.service'

@Component({
  selector: 'cg-navbar',
  templateUrl: './cg-navbar.component.html',
  styleUrls: ['./cg-navbar.component.scss'],
})
export class CgNavbarComponent implements OnInit {
  cityName = 'Srinagar'
  stateName = 'Jammu Kashmir'
  smartVerticalSelected = 'All'
  smart_verticals = [
    'All',
    'SWM',
    'ENERGY',
    'TRANSPORT',
    'ENV',
    'TRAFFIC',
    'OTHERS',
  ]

  severitySelected = 'All'
  severityList: string[] = ['All', 'High', 'Low', 'Medium']

  complaintSatusSelected = 'All'

  constructor(
    private _configs: AppConfigService,
    private _router: Router,
    private _complaintService: ComplaintService
  ) {}

  ngOnInit() {
    this.notifySelectionChange()
  }

  getCityNames() {
    return this._configs.getCityNames()
  }

  notifyCitySelection(city: string) {
    this.cityName = city
    this.stateName = this._configs
      .getCityNames()
      .find((item) => item.city == city).state
    this.notifySelectionChange()
    // this.atcsserviceService.notifyCitySelection.next({
    //   city: city,
    //   state: stateName,
    // });

    // this._router.navigate(["/auth/atcsnew/mainpage/junctions"]);
  }

  smartVerticalSelector() {}

  severitySelector() {}

  statusSelector() {}

  notifySelectionChange() {
    let complaintsFilter = new ComplaintsFilter()
    complaintsFilter.severity =
      this.severitySelected == 'All' ? null : this.severitySelected
    complaintsFilter.complaint_status =
      this.complaintSatusSelected == 'All' ? null : this.complaintSatusSelected
    complaintsFilter.smart_vertical =
      this.smartVerticalSelected == 'All' ? null : this.smartVerticalSelected
    complaintsFilter.state_name = this.stateName
    complaintsFilter.district_city = this.cityName

    this._complaintService.onChangeComplaints.next(complaintsFilter)
  }

  resetFilters() {
    this.severitySelected = 'All'
    this.complaintSatusSelected = 'All'
    this.smartVerticalSelected = 'All'

    this.notifySelectionChange()
  }
}
