import { Action } from "@ngrx/store";
import { ComplaintListFilters } from "../models/complaint.list.filters";
export const COMPLAINTS_FETCH_START = "[COMPLAINTS] Fetch Start";
export const COMPLAINTS_FETCH_SUCCESS = "[COMPLAINTS] Fetched";
export const COMPLAINTS_FETCH_FAIL = "[COMPLAINTS] Fetch Fail";
export const COMPLAINTS_LIST_PAGINATION = "[COMPLAINTS] List Pagination";
export const COMPLAINT_VIEW_DETAILS = "[COMPLAINTS] View Details";
export const COMPLAINTS_SET_COMPLAINT_STATUS_SELECTED =
  "[COMPLAINTS] Set Status Selected";
  export const COMPLAINTS_SET_COMPLAINT_STATUS_SELECTED_CIVILIAN =
  "[COMPLAINTS] Set Status Selected Employee";

export const COMPLAINT_VIEW_DETAILS_START = "[COMPLAINT] View details Start";
export const COMPLAINT_VIEW_DETAILS_SUCCESS =
  "[COMPLAINT] View details success";
export const COMPLAINT_VIEW_DETAILS_FAIL = "[COMPLAINT] View details Fail";

export const COMPLAINT_CREATE_START = "[COMPLAINT] Create Start";
export const COMPLAINT_CREATE_SUCCESS = "[COMPLAINT] Created";
export const COMPLAINT_CREATE_FAIL = "[COMPLAINT] Create Fail";
export const COMPLAINT_CLEAR_CREATE_DATA = "[COMPLAINT] Clear Create Data ";

export const COMPLAINT_DELETE_START = "[COMPLAINT] Delete Start";
export const COMPLAINT_DELETE_SUCCESS = "[COMPLAINT] Deleted";
export const COMPLAINT_DELETE_FAIL = "[COMPLAINT] Delete Fail";

export const COMPLAINT_ASSIGN_START = "[COMPLAINT] Assign Start";
export const COMPLAINT_ASSIGN_SUCCESS = "[COMPLAINT] Assigned";
export const COMPLAINT_ASSIGN_FAIL = "[COMPLAINT] Assign Fail";

export const COMPLAINT_UPLOAD_FILES_START = "[COMPLAINT] Upload Files Start";
export const COMPLAINT_UPLOAD_FILES_SUCCESS = "[COMPLAINT] Files Uploaded";
export const COMPLAINT_UPLOAD_FILES_FAIL = "[COMPLAINT] Upload Files Fail";

export const COMPLAINT_REJECT_START = "[COMPLAINT] Reject Start";
export const COMPLAINT_REJECT_SUCCESS = "[COMPLAINT] Rejected";
export const COMPLAINT_REJECT_FAIL = "[COMPLAINT] Reject Fail";

export const COMPLAINT_FEEDBACK_START = "[COMPLAINT] Feedback Start";
export const COMPLAINT_FEEDBACK_SUCCESS = "[COMPLAINT] Feedback submitted";
export const COMPLAINT_FEEDBACK_FAIL = "[COMPLAINT] Feedback submission  Fail";

export const COMPLAINT_RE_OPEN_START = "[COMPLAINT] Re-Open Start";
export const COMPLAINT_RE_OPEN_SUCCESS = "[COMPLAINT] Re-Opened";
export const COMPLAINT_RE_OPEN_FAIL = "[COMPLAINT] Re-Open Fail";

export const COMPLAINT_CHAT_MSG_SEND_START = "[COMPLAINT] Chat Msg Send Start";
export const COMPLAINT_CHAT_MSG_SEND_SUCCESS = "[COMPLAINT] Chat Msg Sent";
export const COMPLAINT_CHAT_MSG_SEND_FAIL = "[COMPLAINT] Chat Msg Send Fail";

export const COMPLAINT_REQUEST_RE_ASSIGN_START =
  "[COMPLAINT] Request Re-Assign Start";
export const COMPLAINT_REQUEST_RE_ASSIGN_SUCCESS =
  "[COMPLAINT] Request Re-Assign success";
export const COMPLAINT_REQUEST_REASSIGN_FAIL =
  "[COMPLAINT] Request Re-Assign Fail";

export const COMPLAINT_MARK_RESOLVED_START = "[COMPLAINT] Mark Resolved Start";
export const COMPLAINT_MARK_RESOLVED_SUCCESS = "[COMPLAINT] Mark Resolved";
export const COMPLAINT_MARK_RESOLVED_FAIL = "[COMPLAINT] Mark Resolved Fail";

export const COMPLAINT_UPLOAD_RE_OPEN__FILES_START =
  "[COMPLAINT] Upload Re-Open Files Start";
export const COMPLAINT_UPLOAD_RE_OPEN_FILES_SUCCESS =
  "[COMPLAINT] Re-Open Files Uploaded";
export const COMPLAINT_UPLOAD_RE_OPEN_FILES_FAIL =
  "[COMPLAINT] Upload Re-Open Files Fail";

export const COMPLAINT_UPLOAD_RESOLVED__FILES_START =
  "[COMPLAINT] Upload Resolved Files Start";
export const COMPLAINT_UPLOAD_RESOLVED_FILES_SUCCESS =
  "[COMPLAINT] Resolved Files Uploaded";
export const COMPLAINT_UPLOAD_RESOLVED_FILES_FAIL =
  "[COMPLAINT] Upload Resolved Files Fail";

export class ComplaintViewDetails implements Action {
  readonly type = COMPLAINT_VIEW_DETAILS;
  constructor(public payload: string) {}
}

export class ComplaintsFetchSuccess implements Action {
  readonly type = COMPLAINTS_FETCH_SUCCESS;
  constructor(public payload: { complaints: any[]; totalCount: number }) {}
}

export class ComplaintsFetchStart implements Action {
  readonly type = COMPLAINTS_FETCH_START;
  // constructor(
  //   public payload: {
  //     stateName: string;
  //     districtCity: string;
  //     pageIndex: number;
  //     pageSize: number;
  //     sortBy: string;
  //     complaintAssignedTo: string;
  //     complaintStatusList:string[],
  //     userId:string
  //   }
  // ) {}

  constructor(
    public payload: ComplaintListFilters
  ) {}

}

export class ComplaintsFetchFail implements Action {
  readonly type = COMPLAINTS_FETCH_FAIL;
  constructor(public payload: string) {}
}

export class ComplaintsSetComplaintStatusSelected implements Action {
  readonly type = COMPLAINTS_SET_COMPLAINT_STATUS_SELECTED;
  constructor(public payload: string) {}
}

export class ComplaintsSetComplaintStatusSelectedCivilian implements Action {
  readonly type = COMPLAINTS_SET_COMPLAINT_STATUS_SELECTED_CIVILIAN;
  constructor(public payload: string) {}
}

export type ComplaintListActions =
  | ComplaintsFetchSuccess
  | ComplaintsFetchStart
  | ComplaintsFetchFail
  | ComplaintViewDetails
  | ComplaintsSetComplaintStatusSelected
  | ComplaintsSetComplaintStatusSelectedCivilian

//////////////////   COMPLAINT CREATE /////////////////////////////////////////////////
export class ComplaintViewDetailsSuccess implements Action {
  readonly type = COMPLAINT_VIEW_DETAILS_SUCCESS;
  constructor(public payload: {}) {}
}

export class ComplaintViewDetailsStart implements Action {
  readonly type = COMPLAINT_VIEW_DETAILS_START;
  constructor(
    public payload: {
      stateName: string;
      districtCity: string;
      pageIndex: number;
      pageSize: number;
      sortBy: string;
      complaintId: string;
    }
  ) {}
}

export class ComplaintViewDetailsFail implements Action {
  readonly type = COMPLAINT_VIEW_DETAILS_FAIL;
  constructor(public payload: string) {}
}

export type ComplaintViewDetailsActions =
  | ComplaintViewDetailsSuccess
  | ComplaintViewDetailsStart
  | ComplaintViewDetailsFail;

//////////////////   COMPLAINT CREATE /////////////////////////////////////////////////
export class ComplaintCreateSuccess implements Action {
  readonly type = COMPLAINT_CREATE_SUCCESS;
  constructor(public payload: string) {}
}

export class ComplaintCreateStart implements Action {
  readonly type = COMPLAINT_CREATE_START;

  constructor(public payload: { complaint: any }) {}
}

export class ComplaintClearCreatedata implements Action {
  readonly type = COMPLAINT_CREATE_FAIL;
  constructor() {}
}

export class ComplaintCreateFail implements Action {
  readonly type = COMPLAINT_CLEAR_CREATE_DATA;
  constructor(public payload: string) {}
}

export type ComplaintCreateActions =
  | ComplaintCreateSuccess
  | ComplaintCreateStart
  | ComplaintCreateFail
  | ComplaintClearCreatedata;

//////////////////   COMPLAINT DELETE /////////////////////////////////////////////////
export class ComplaintDeleteSuccess implements Action {
  readonly type = COMPLAINT_DELETE_SUCCESS;
  constructor() {}
}

export class ComplaintDeleteStart implements Action {
  readonly type = COMPLAINT_DELETE_START;
  constructor(public payload: string) {}
}

export class ComplaintDeleteFail implements Action {
  readonly type = COMPLAINT_DELETE_FAIL;
  constructor(public payload: string) {}
}

//////////////////   COMPLAINT ASSIGN /////////////////////////////////////////////////
export class ComplaintAssignSuccess implements Action {
  readonly type = COMPLAINT_ASSIGN_SUCCESS;
  constructor() {}
}

export class ComplaintAssignStart implements Action {
  readonly type = COMPLAINT_ASSIGN_START;
  constructor(
    public payload: {
      complaintId: string;
      complaintUpdatedBy: string;
      complaintStatus: string;
      complaintAssignedTo: string;
    }
  ) {}
}

export class ComplaintAssignFail implements Action {
  readonly type = COMPLAINT_ASSIGN_FAIL;
  constructor(public payload: string) {}
}

//////////////////   COMPLAINT UPLOAD FILES /////////////////////////////////////////////////
export class ComplaintUploadFilesSuccess implements Action {
  readonly type = COMPLAINT_UPLOAD_FILES_SUCCESS;
  constructor() {}
}

export class ComplaintUploadFilesStart implements Action {
  readonly type = COMPLAINT_UPLOAD_FILES_START;
  constructor(public payload: FormData) {}
}

export class ComplaintUploadFilesFail implements Action {
  readonly type = COMPLAINT_UPLOAD_FILES_FAIL;
  constructor(public payload: string) {}
}
export type ComplaintUploadFilesActions =
  | ComplaintUploadFilesSuccess
  | ComplaintUploadFilesStart
  | ComplaintUploadFilesFail;

//////////////////   COMPLAINT REJECT /////////////////////////////////////////////////
export class ComplaintRejectSuccess implements Action {
  readonly type = COMPLAINT_REJECT_SUCCESS;
  constructor() {}
}

export class ComplaintRejectStart implements Action {
  readonly type = COMPLAINT_REJECT_START;
  constructor(
    public payload: {
      complaintId: string;
      complaintUpdatedBy: string;
      complaintStatus: string;
      reason: string;
      remarks: string;
    }
  ) {}
}

export class ComplaintRejectFail implements Action {
  readonly type = COMPLAINT_REJECT_FAIL;
  constructor(public payload: string) {}
}
export type ComplaintRejectActions =
  | ComplaintRejectSuccess
  | ComplaintRejectStart
  | ComplaintRejectFail;
//////////////////   COMPLAINT FEEDBACK /////////////////////////////////////////////////
export class ComplaintFeedbackSuccess implements Action {
  readonly type = COMPLAINT_FEEDBACK_SUCCESS;
  constructor() {}
}

export class ComplaintFeedbackStart implements Action {
  readonly type = COMPLAINT_FEEDBACK_START;
  constructor(
    public payload: {
      complaintId: string;
      complaintUpdatedBy: string;
      feedbackParams: string[];
      feedbackRating: number;
      feedbackDescription: string;
    }
  ) {}
}

export class ComplaintFeedbackFail implements Action {
  readonly type = COMPLAINT_FEEDBACK_FAIL;
  constructor(public payload: string) {}
}

//////////////////   COMPLAINT RE-OPEN /////////////////////////////////////////////////
export class ComplaintReOpenSuccess implements Action {
  readonly type = COMPLAINT_RE_OPEN_SUCCESS;
  constructor() {}
}

export class ComplaintReOpenStart implements Action {
  readonly type = COMPLAINT_RE_OPEN_START;
  constructor(
    public payload: {
      complaintId: string;
      complaintUpdatedBy: string;
      complaintStatus: string;
      reason: string;
      remarks: string;
    }
  ) {}
}

export class ComplaintReOpenFail implements Action {
  readonly type = COMPLAINT_RE_OPEN_FAIL;
  constructor(public payload: string) {}
}
export type ComplaintReOpenActions =
  | ComplaintReOpenSuccess
  | ComplaintReOpenStart
  | ComplaintReOpenFail;
//////////////////   COMPLAINT CHAT MESSAGE /////////////////////////////////////////////////
export class ComplaintChatMsgSendSuccess implements Action {
  readonly type = COMPLAINT_CHAT_MSG_SEND_SUCCESS;
  constructor() {}
}

export class ComplaintChatMsgSendStart implements Action {
  readonly type = COMPLAINT_CHAT_MSG_SEND_START;
  constructor(
    public payload: {
      complaintId: string;
      complaintUpdatedBy: string;
      comments: string;
    }
  ) {}
}

export class ComplaintChatMsgSendFail implements Action {
  readonly type = COMPLAINT_CHAT_MSG_SEND_FAIL;
  constructor(public payload: string) {}
}

export type ComplaintChatMsgSendActions =
  | ComplaintChatMsgSendFail
  | ComplaintChatMsgSendStart
  | ComplaintChatMsgSendSuccess;
////////////////////////////////////////////////////////////////////////////

//////////////////   COMPLAINT REQUEST REASSIGN /////////////////////////////////////////////////
export class ComplaintRequestReassignSuccess implements Action {
  readonly type = COMPLAINT_REQUEST_RE_ASSIGN_SUCCESS;
  constructor() {}
}

export class ComplaintRequestReassignStart implements Action {
  readonly type = COMPLAINT_REQUEST_RE_ASSIGN_START;
  constructor(
    public payload: {
      complaintId: string;
      complaintUpdatedBy: string;
      complaintStatus: string;
      reason: string;
      remarks: string;
    }
  ) {}
}

export class ComplaintRequestReassignFail implements Action {
  readonly type = COMPLAINT_REQUEST_REASSIGN_FAIL;
  constructor(public payload: string) {}
}
export type ComplaintRequestReassignActions =
  | ComplaintRequestReassignSuccess
  | ComplaintRequestReassignStart
  | ComplaintRequestReassignFail;

////////////////////////////////////////////////////////////////////////////////////
//////////////////   COMPLAINT MARK RESOLVED /////////////////////////////////////////////////
export class ComplaintMarkResolvedSuccess implements Action {
  readonly type = COMPLAINT_MARK_RESOLVED_SUCCESS;
  constructor() {}
}

export class ComplaintMarkResolvedStart implements Action {
  readonly type = COMPLAINT_MARK_RESOLVED_START;
  constructor(
    public payload: {
      complaintId: string;
      complaintUpdatedBy: string;
      complaintStatus: string;
      reason: string;
      remarks: string;
    }
  ) {}
}

export class ComplaintMarkResolvedFail implements Action {
  readonly type = COMPLAINT_MARK_RESOLVED_FAIL;
  constructor(public payload: string) {}
}
export type ComplaintMarkResolvedActions =
  | ComplaintMarkResolvedSuccess
  | ComplaintMarkResolvedStart
  | ComplaintMarkResolvedFail;

////////////////////////////////////////////////////////////////////////////////////

//////////////////   COMPLAINT UPLOAD FILES /////////////////////////////////////////////////
export class ComplaintUploadReOpenFilesSuccess implements Action {
  readonly type = COMPLAINT_UPLOAD_RE_OPEN_FILES_SUCCESS;
  constructor() {}
}

export class ComplaintUploadReOpenFilesStart implements Action {
  readonly type = COMPLAINT_UPLOAD_RE_OPEN__FILES_START;
  constructor(public payload: FormData) {}
}

export class ComplaintUploadReOpenFilesFail implements Action {
  readonly type = COMPLAINT_UPLOAD_RE_OPEN_FILES_FAIL;
  constructor(public payload: string) {}
}
export type ComplaintUploadReOpenFilesActions =
  | ComplaintUploadReOpenFilesSuccess
  | ComplaintUploadReOpenFilesStart
  | ComplaintUploadReOpenFilesFail;

//////////////////   COMPLAINT UPLOAD FILES /////////////////////////////////////////////////
export class ComplaintUploadResolvedFilesSuccess implements Action {
  readonly type = COMPLAINT_UPLOAD_RESOLVED_FILES_SUCCESS;
  constructor() {}
}

export class ComplaintUploadResolvedFilesStart implements Action {
  readonly type = COMPLAINT_UPLOAD_RESOLVED__FILES_START;
  constructor(public payload: FormData) {}
}

export class ComplaintUploadResolvedFilesFail implements Action {
  readonly type = COMPLAINT_UPLOAD_RESOLVED_FILES_FAIL;
  constructor(public payload: string) {}
}
export type ComplaintUploadResolvedFilesActions =
  | ComplaintUploadResolvedFilesSuccess
  | ComplaintUploadResolvedFilesStart
  | ComplaintUploadResolvedFilesFail;
///////////////////////////////////////////////////////////////////////////////////
export type ComplaintFeedbackActions =
  | ComplaintFeedbackSuccess
  | ComplaintFeedbackStart
  | ComplaintFeedbackFail;

export type ComplaintDeleteActions =
  | ComplaintDeleteSuccess
  | ComplaintDeleteStart
  | ComplaintDeleteFail;

export type ComplaintAssignActions =
  | ComplaintAssignSuccess
  | ComplaintAssignStart
  | ComplaintAssignFail;
