// import { AlertListFilters } from '../models/alerts.list.filetr'
import { ActivationStart } from '@angular/router'
import { ComplaintListFilters } from '../models/complaint.list.filters'
import { ComplaintStatusDisplayed } from '../models/constants'
import * as ComplaintsActions from './complaint.actions'

export interface ComplaintListState {
  complaints: any[]
  loading: boolean
  error: string
  totalCount: number
  complaint: {}
  // complaintStatusDisplayed:string
  // complaintStatusAtRoAndEmployee:string
  filters:ComplaintListFilters
}

const complaintsList = localStorage.getItem('complaintsList')
  ? JSON.parse(localStorage.getItem('complaintsList'))
  : []

const complaintListInitialState: ComplaintListState = {
  complaints: complaintsList,
  loading: false,
  error: '',
  totalCount: 0,
  complaint: {},
  // complaintStatusDisplayed:ComplaintStatusDisplayed.UNASSIGNED,
  // complaintStatusAtRoAndEmployee:ComplaintStatusDisplayed.OPEN,
  filters : localStorage.getItem('complaintsFilters') ? JSON.parse(localStorage.getItem('complaintsFilters')) : null
}

export function complaintListReducer(
  state = complaintListInitialState,
  action: ComplaintsActions.ComplaintListActions
) {
  switch (action.type) {
    case ComplaintsActions.COMPLAINTS_SET_COMPLAINT_STATUS_SELECTED: {
      return {
        ...state,
        complaintStatusDisplayed: action.payload
      }
    }

    case ComplaintsActions.COMPLAINTS_SET_COMPLAINT_STATUS_SELECTED_CIVILIAN: {
      return {
        ...state,
        complaintStatusAtRoAndEmployee: action.payload
      }
    }

    case ComplaintsActions.COMPLAINTS_FETCH_SUCCESS: {
      return {
        ...state,
        complaints: action.payload.complaints,
        totalCount: action.payload.totalCount,
        loading: false,
      }
    }

    case ComplaintsActions.COMPLAINTS_FETCH_START: {
      const filters = action.payload
      return {
        ...state,
        loading: true,
        complaints:[],
        error: '',
        totalCount: 0,
        complaint: {},
        filters:filters
      }
    }

    case ComplaintsActions.COMPLAINTS_FETCH_FAIL: {
      return {
        ...state,
        loading: false,
        error: action.payload,
      }
    }

    case ComplaintsActions.COMPLAINT_VIEW_DETAILS: {
      const complaint = state.complaints.find(
        (x) => x.complaintId === action.payload
      )

      return {
        ...state,
        complaint: complaint,
      }
    }

    default: {
      return state
    }
  }
}

//////////////////   COMPLAINT CREATE /////////////////////////////////////////////////

export interface ComplaintCreateState {
  loading: boolean
  error: string
  success: boolean
  createdComplaintId: string
}

const complaintCreateInitialState: ComplaintCreateState = {
  loading: false,
  error: '',
  success: false,
  createdComplaintId: '',
}

export function complaintCreateReducer(
  state = complaintCreateInitialState,
  action: ComplaintsActions.ComplaintCreateActions
) {
  switch (action.type) {
    case ComplaintsActions.COMPLAINT_CREATE_SUCCESS: {
      return {
        ...state,
        success: true,
        loading: false,
        createdComplaintId: action.payload,
      }
    }

    case ComplaintsActions.COMPLAINT_CREATE_START: {
      return {
        ...state,
        loading: true,
        success:false,
        error:"",
        createdComplaintId:''
      }
    }

    case ComplaintsActions.COMPLAINT_CREATE_FAIL: {
      return {
        ...state,
        loading: false,
        error: "",
        success:false,
        createdComplaintId:''
      }
    }

    case ComplaintsActions.COMPLAINT_CLEAR_CREATE_DATA: {
      return {
        ...state,
        loading: true,
        success:false,
        error:"",
        createdComplaintId:''
      }
    }

    default: {
      return state
    }
  }
}

//////////////////   COMPLAINT DELETE /////////////////////////////////////////////////

export interface ComplaintDeleteState {
  loading: boolean
  error: string
  success: boolean
}

const complaintDeleteInitialState: ComplaintDeleteState = {
  loading: false,
  error: '',
  success: false,
}

export function complaintDeleteReducer(
  state = complaintDeleteInitialState,
  action: ComplaintsActions.ComplaintDeleteActions
) {
  switch (action.type) {
    case ComplaintsActions.COMPLAINT_DELETE_SUCCESS: {
      return {
        ...state,
        success: true,
        loading: false,
      }
    }

    case ComplaintsActions.COMPLAINT_DELETE_START: {
      return {
        ...state,
        loading: true,
      }
    }

    case ComplaintsActions.COMPLAINT_DELETE_FAIL: {
      return {
        ...state,
        loading: false,
        error: action.payload,
      }
    }
    default: {
      return state
    }
  }
}

//////////////////   COMPLAINT DELETE /////////////////////////////////////////////////

export interface ComplaintAssignState {
  loading: boolean
  error: string
  success: boolean
}

const complaintAssignInitialState: ComplaintAssignState = {
  loading: false,
  error: '',
  success: false,
}

export function complaintAssignReducer(
  state = complaintAssignInitialState,
  action: ComplaintsActions.ComplaintAssignActions
) {
  switch (action.type) {
    case ComplaintsActions.COMPLAINT_ASSIGN_SUCCESS: {
      return {
        ...state,
        success: true,
        loading: false,
      }
    }

    case ComplaintsActions.COMPLAINT_ASSIGN_START: {
      return {
        ...state,
        loading: true,
      }
    }

    case ComplaintsActions.COMPLAINT_ASSIGN_FAIL: {
      return {
        ...state,
        loading: false,
        error: action.payload,
      }
    }
    default: {
      return state
    }
  }
}

//////////////////   COMPLAINT UPLOAD FILES /////////////////////////////////////////////////

export interface ComplaintUploadFilesState {
  loading: boolean
  error: string
  success: boolean
}

const complaintUploadFilesInitialState: ComplaintUploadFilesState = {
  loading: false,
  error: '',
  success: false,
}

export function complaintUploadFilesReducer(
  state = complaintUploadFilesInitialState,
  action: ComplaintsActions.ComplaintUploadFilesActions
) {
  switch (action.type) {
    case ComplaintsActions.COMPLAINT_UPLOAD_FILES_SUCCESS: {
      return {
        ...state,
        success: true,
        loading: false,
      }
    }

    case ComplaintsActions.COMPLAINT_UPLOAD_FILES_START: {
      return {
        ...state,
        loading: true,
        success: false,
        error:''
      }
    }

    case ComplaintsActions.COMPLAINT_UPLOAD_FILES_FAIL: {
      return {
        ...state,
        loading: false,
        error: action.payload,
        success: false,
      }
    }
    default: {
      return state
    }
  }
}

//////////////////   COMPLAINT UPLOAD FILES /////////////////////////////////////////////////

export interface ComplaintRejectState {
  loading: boolean
  error: string
  success: boolean
}

const complaintRejectInitialState: ComplaintRejectState = {
  loading: false,
  error: '',
  success: false,
}

export function complaintRejectReducer(
  state = complaintRejectInitialState,
  action: ComplaintsActions.ComplaintRejectActions
) {
  switch (action.type) {
    case ComplaintsActions.COMPLAINT_REJECT_SUCCESS: {
      return {
        ...state,
        success: true,
        loading: false,
      }
    }

    case ComplaintsActions.COMPLAINT_REJECT_START: {
      return {
        ...state,
        loading: true,
        success: false,
      }
    }

    case ComplaintsActions.COMPLAINT_REJECT_FAIL: {
      return {
        ...state,
        success: false,
        loading: false,
        error: action.payload,
      }
    }
    default: {
      return state
    }
  }
}

//////////////////   COMPLAINT UPLOAD FILES /////////////////////////////////////////////////

export interface ComplaintFeedbackState {
  loading: boolean
  error: string
  success: boolean
}

const complaintFeedbackInitialState: ComplaintFeedbackState = {
  loading: false,
  error: '',
  success: false,
}

export function complaintFeedbackReducer(
  state = complaintFeedbackInitialState,
  action: ComplaintsActions.ComplaintFeedbackActions
) {
  switch (action.type) {
    case ComplaintsActions.COMPLAINT_FEEDBACK_SUCCESS: {
      return {
        ...state,
        success: true,
        loading: false,
      }
    }

    case ComplaintsActions.COMPLAINT_FEEDBACK_START: {
      return {
        ...state,
        loading: true,
      }
    }

    case ComplaintsActions.COMPLAINT_FEEDBACK_FAIL: {
      return {
        ...state,
        loading: false,
        error: action.payload,
      }
    }
    default: {
      return state
    }
  }
}

//////////////////   COMPLAINT CHAT MSG /////////////////////////////////////////////////

export interface ComplaintChatMsgSendState {
  loading: boolean
  error: string
  success: boolean
}

const complaintChatMsgSendInitialState: ComplaintChatMsgSendState = {
  loading: false,
  error: '',
  success: false,
}

export function complaintChatMsgSendReducer(
  state = complaintChatMsgSendInitialState,
  action: ComplaintsActions.ComplaintChatMsgSendActions
) {
  switch (action.type) {
    case ComplaintsActions.COMPLAINT_CHAT_MSG_SEND_SUCCESS: {
      return {
        ...state,
        success: true,
        loading: false,
      }
    }

    case ComplaintsActions.COMPLAINT_CHAT_MSG_SEND_START: {
      return {
        ...state,
        loading: true,
        success: false,
      }
    }

    case ComplaintsActions.COMPLAINT_CHAT_MSG_SEND_FAIL: {
      return {
        ...state,
        loading: false,
        success: false,
        error: action.payload,
      }
    }

    default: {
      return state
    }
  }
}



//////////////////   COMPLAINT CHAT MSG /////////////////////////////////////////////////

export interface ComplaintViewDetails {
  loading: boolean
  error: string
  success: boolean
  complaint:any
}

const complaintViewDetailsInitialState: ComplaintViewDetails = {
  loading: false,
  error: '',
  success: false,
  complaint:null
}

export function complaintViewDetailsReducer(
  state = complaintViewDetailsInitialState,
  action: ComplaintsActions.ComplaintViewDetailsActions
) {
  switch (action.type) {
    case ComplaintsActions.COMPLAINT_VIEW_DETAILS_SUCCESS: {
      return {
        ...state,
        success: true,
        loading: false,
        complaint:action.payload
      }
    }

    case ComplaintsActions.COMPLAINT_VIEW_DETAILS_START: {
      return {
        ...state,
        loading: true,
        success: false,
        complaint:null,
        error: '',
      }
    }

    case ComplaintsActions.COMPLAINT_VIEW_DETAILS_FAIL: {
      return {
        ...state,
        loading: false,
        error: action.payload,
      }
    }
    
    default: {
      return state
    }
  }
}

//////////////////   COMPLAINT REQUEST RE-ASSIGN /////////////////////////////////////////////////

export interface ComplaintRequestReassignState {
  loading: boolean
  error: string
  success: boolean
}

const complaintRequestReassignInitialState: ComplaintRequestReassignState = {
  loading: false,
  error: '',
  success: false,
}

export function complaintRequestReassignReducer(
  state = complaintRequestReassignInitialState,
  action: ComplaintsActions.ComplaintRequestReassignActions
) {
  switch (action.type) {
    case ComplaintsActions.COMPLAINT_REQUEST_RE_ASSIGN_SUCCESS: {
      return {
        ...state,
        success: true,
        loading: false,
      }
    }

    case ComplaintsActions.COMPLAINT_REQUEST_RE_ASSIGN_START: {
      return {
        ...state,
        loading: true,
      }
    }

    case ComplaintsActions.COMPLAINT_REQUEST_REASSIGN_FAIL: {
      return {
        ...state,
        loading: false,
        error: action.payload,
      }
    }
    default: {
      return state
    }
  }
}

//////////////////   COMPLAINT REQUEST RE-ASSIGN /////////////////////////////////////////////////

export interface ComplaintMarkResolvedState {
  loading: boolean
  error: string
  success: boolean
}

const complaintMarkResolvedInitialState: ComplaintMarkResolvedState = {
  loading: false,
  error: '',
  success: false,
}

export function complaintMarkResolvedReducer(
  state = complaintMarkResolvedInitialState,
  action: ComplaintsActions.ComplaintMarkResolvedActions
) {
  switch (action.type) {
    case ComplaintsActions.COMPLAINT_MARK_RESOLVED_SUCCESS: {
      return {
        ...state,
        success: true,
        loading: false,
      }
    }

    case ComplaintsActions.COMPLAINT_MARK_RESOLVED_START: {
      return {
        ...state,
        loading: true,
      }
    }

    case ComplaintsActions.COMPLAINT_MARK_RESOLVED_FAIL: {
      return {
        ...state,
        loading: false,
        error: action.payload,
      }
    }
    default: {
      return state
    }
  }
}

//////////////////   COMPLAINT REOPEN /////////////////////////////////////////////////

export interface ComplaintReOpenState {
  loading: boolean
  error: string
  success: boolean
}

const complaintReOpenInitialState: ComplaintReOpenState = {
  loading: false,
  error: '',
  success: false,
}

export function complaintReOpenReducer(
  state = complaintRejectInitialState,
  action: ComplaintsActions.ComplaintReOpenActions
) {
  switch (action.type) {
    case ComplaintsActions.COMPLAINT_RE_OPEN_SUCCESS: {
      return {
        ...state,
        success: true,
        loading: false,
      }
    }

    case ComplaintsActions.COMPLAINT_RE_OPEN_START: {
      return {
        ...state,
        loading: true,
        success: false,
      }
    }

    case ComplaintsActions.COMPLAINT_RE_OPEN_FAIL: {
      return {
        ...state,
        loading: false,
        success: false,
        error: action.payload,
      }
    }
    default: {
      return state
    }
  }
}

/////////////////////////////////////////////////////////////////////////
//////////////////   COMPLAINT UPLOAD RE_OPEN FILES /////////////////////////////////////////////////

export interface ComplaintUploadReOpenFilesState {
  loading: boolean
  error: string
  success: boolean
}

const complaintUploadReOpenFilesInitialState: ComplaintUploadReOpenFilesState = {
  loading: false,
  error: '',
  success: false,
}

export function complaintUploadReOpenFilesReducer(
  state = complaintUploadReOpenFilesInitialState,
  action: ComplaintsActions.ComplaintUploadReOpenFilesActions
) {
  switch (action.type) {
    case ComplaintsActions.COMPLAINT_UPLOAD_RE_OPEN_FILES_SUCCESS: {
      return {
        ...state,
        success: true,
        loading: false,
      }
    }

    case ComplaintsActions.COMPLAINT_UPLOAD_RE_OPEN__FILES_START: {
      return {
        ...state,
        loading: true,
      }
    }

    case ComplaintsActions.COMPLAINT_UPLOAD_RE_OPEN_FILES_FAIL: {
      return {
        ...state,
        loading: false,
        error: action.payload,
      }
    }
    default: {
      return state
    }
  }
}

//////////////////   COMPLAINT UPLOAD RESOLVED FILES /////////////////////////////////////////////////

export interface ComplaintUploadResolvedFilesState {
  loading: boolean
  error: string
  success: boolean
}

const complaintUploadResolvedFilesInitialState: ComplaintUploadResolvedFilesState = {
  loading: false,
  error: '',
  success: false,
}

export function complaintUploadResolvedFilesReducer(
  state = complaintUploadResolvedFilesInitialState,
  action: ComplaintsActions.ComplaintUploadResolvedFilesActions
) {
  switch (action.type) {
    case ComplaintsActions.COMPLAINT_UPLOAD_RESOLVED_FILES_SUCCESS: {
      return {
        ...state,
        success: true,
        loading: false,
      }
    }

    case ComplaintsActions.COMPLAINT_UPLOAD_RESOLVED__FILES_START: {
      return {
        ...state,
        loading: true,
      }
    }

    case ComplaintsActions.COMPLAINT_UPLOAD_RESOLVED_FILES_FAIL: {
      return {
        ...state,
        loading: false,
        error: action.payload,
      }
    }
    default: {
      return state
    }
  }
}

