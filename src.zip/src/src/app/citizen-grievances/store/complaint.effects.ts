import { Injectable, SkipSelf } from "@angular/core";
import { Actions, ofType, Effect } from "@ngrx/effects";
import { switchMap, catchError, map, tap } from "rxjs/operators";
import { of } from "rxjs";
import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import * as ComplaintsActions from "./complaint.actions";
import { AppConfigService } from "src/app/shared/configs-loader/app.config.service";

@Injectable()
export class ComplaintsEffects {
  @Effect()
  authLogin = this.actions$.pipe(
    ofType(ComplaintsActions.COMPLAINTS_FETCH_START),
    switchMap((filterData: ComplaintsActions.ComplaintsFetchStart) => {
      const BASE_URL = this.appConfigService.getConfig().API_BASE_URL + '/citizengrievances/complaint'

      const endpoint = `${BASE_URL}/filtercomplaints`;

      const params = {
        stateName: filterData.payload.stateName,
        districtCity: filterData.payload.districtCity,
        pageIndex: filterData.payload.pageIndex,
        pageSize: filterData.payload.pageSize,
        sortBy: filterData.payload.sortBy,
        complaintAssignedTo: filterData.payload.complaintAssignedTo,
        complaintStatusList:filterData.payload.getComplaintStatuslist(),
        userId:filterData.payload.userId,
        fromDate:filterData.payload.fromDate,
        toDate:filterData.payload.toDate,

      };

      return this.http.post<any>(endpoint, params).pipe(
        map((resData) => {
          const { complaints, totalCount } = resData;
          localStorage.setItem(
            "complaintsList",
            JSON.stringify({ complaints, totalCount })
          );
          return new ComplaintsActions.ComplaintsFetchSuccess({
            complaints,
            totalCount,
          });
        }),
        catchError((errorRes) => {
          return of(
            new ComplaintsActions.ComplaintsFetchFail(errorRes.message)
          );
        })
      );
    })
  );

  @Effect()
  viewDetails = this.actions$.pipe(
    ofType(ComplaintsActions.COMPLAINT_VIEW_DETAILS_START),
    switchMap((filterData: ComplaintsActions.ComplaintViewDetailsStart) => {
      const BASE_URL = this.appConfigService.getConfig().API_BASE_URL + '/citizengrievances/complaint'

      const endpoint = `${BASE_URL}/filtercomplaints`;

      const params = {
        stateName: filterData.payload.stateName,
        districtCity: filterData.payload.districtCity,
        pageIndex: filterData.payload.pageIndex,
        pageSize: filterData.payload.pageSize,
        sortBy: filterData.payload.sortBy,
        complaintId: filterData.payload.complaintId,
      };

      return this.http.post<any>(endpoint, params).pipe(
        map((resData) => {
          const { complaints, totalCount } = resData;
          return new ComplaintsActions.ComplaintViewDetailsSuccess(
            complaints[0]
          );
        }),
        catchError((errorRes) => {
          return of(
            new ComplaintsActions.ComplaintViewDetailsFail(
              errorRes.console.error
            )
          );
        })
      );
    })
  );

  @Effect()
  createComplaint = this.actions$.pipe(
    ofType(ComplaintsActions.COMPLAINT_CREATE_START),
    switchMap((complaintData: ComplaintsActions.ComplaintCreateStart) => {
      const BASE_URL = this.appConfigService.getConfig().API_BASE_URL + '/citizengrievances/complaint'

      const endpoint = `${BASE_URL}register`;
      // console.log(complaintData.payload.complaint)
      return this.http
        .post<any>(endpoint, complaintData.payload.complaint)
        .pipe(
          map((resData) => {
            return new ComplaintsActions.ComplaintCreateSuccess(
              resData.complaintId
            );
          }),
          catchError((errorRes) => {
            return of(
              // console.log(errorRes.console.error)
              new ComplaintsActions.ComplaintCreateFail(
                "error while creating new coplaint"
              )
            );
          })
        );
    })
  );

  @Effect()
  deleteComplaint = this.actions$.pipe(
    ofType(ComplaintsActions.COMPLAINT_DELETE_START),
    switchMap((complaintData: ComplaintsActions.ComplaintDeleteStart) => {
      const BASE_URL = this.appConfigService.getConfig().API_BASE_URL + '/citizengrievances/complaint'

      const endpoint = `${BASE_URL}delete`;
      const complaintId = complaintData.payload;
      const headers = new HttpHeaders().append("header", "value");
      const params = new HttpParams().append("complaintId", complaintId);

      return this.http.get<any>(endpoint, { headers, params }).pipe(
        map((resData) => {
          return new ComplaintsActions.ComplaintDeleteSuccess();
        }),
        catchError((errorRes) => {
          return of(
            // console.log(errorRes.console.error)
            new ComplaintsActions.ComplaintDeleteFail(
              "error while deleting coplaint"
            )
          );
        })
      );
    })
  );

  @Effect()
  assignComplaint = this.actions$.pipe(
    ofType(ComplaintsActions.COMPLAINT_ASSIGN_START),
    switchMap((complaintData: ComplaintsActions.ComplaintAssignStart) => {
      const BASE_URL = this.appConfigService.getConfig().API_BASE_URL + '/citizengrievances/complaint'

      const endpoint = `${BASE_URL}updatecomplaint`;
      const complaintUpdateDetails = complaintData.payload;

      return this.http.put<any>(endpoint, complaintUpdateDetails).pipe(
        map((resData) => {
          return new ComplaintsActions.ComplaintAssignSuccess();
        }),
        catchError((errorRes) => {
          return of(
            // console.log(errorRes.console.error)
            new ComplaintsActions.ComplaintAssignFail(
              "error while assigning complaint"
            )
          );
        })
      );
    })
  );

  @Effect()
  rejectComplaint = this.actions$.pipe(
    ofType(ComplaintsActions.COMPLAINT_REJECT_START),
    switchMap((complaintData: ComplaintsActions.ComplaintRejectStart) => {
      const BASE_URL = this.appConfigService.getConfig().API_BASE_URL + '/citizengrievances/complaint/'

      const endpoint = `${BASE_URL}updatecomplaint`;
      const complaintUpdateDetails = complaintData.payload;

      return this.http.put<any>(endpoint, complaintUpdateDetails).pipe(
        map((resData) => {
          return new ComplaintsActions.ComplaintRejectSuccess();
        }),
        catchError((errorRes) => {
          return of(
            // console.log(errorRes.console.error)
            new ComplaintsActions.ComplaintRejectFail(
              "error while rejecting complaint"
            )
          );
        })
      );
    })
  );

  @Effect()
  chatSendMsg = this.actions$.pipe(
    ofType(ComplaintsActions.COMPLAINT_CHAT_MSG_SEND_START),
    switchMap((complaintData: ComplaintsActions.ComplaintChatMsgSendStart) => {
      const BASE_URL = this.appConfigService.getConfig().API_BASE_URL + '/citizengrievances/complaint/'

      const endpoint = `${BASE_URL}updatecomplaint`;
      const complaintUpdateDetails = complaintData.payload;

      return this.http.put<any>(endpoint, complaintUpdateDetails).pipe(
        map((resData) => {
          return new ComplaintsActions.ComplaintChatMsgSendSuccess();
        }),
        catchError((errorRes) => {
          return of(
            // console.log(errorRes.console.error)
            new ComplaintsActions.ComplaintChatMsgSendFail(
              "error while sending msg"
            )
          );
        })
      );
    })
  );

  @Effect()
  complaintFeedback = this.actions$.pipe(
    ofType(ComplaintsActions.COMPLAINT_FEEDBACK_START),
    switchMap((complaintData: ComplaintsActions.ComplaintFeedbackStart) => {
      const BASE_URL = this.appConfigService.getConfig().API_BASE_URL + '/citizengrievances/complaint/'

      const endpoint = `${BASE_URL}updatecomplaint`;
      const complaintUpdateDetails = complaintData.payload;

      return this.http.put<any>(endpoint, complaintUpdateDetails).pipe(
        map((resData) => {
          return new ComplaintsActions.ComplaintFeedbackSuccess();
        }),
        catchError((errorRes) => {
          return of(
            // console.log(errorRes.console.error)
            new ComplaintsActions.ComplaintFeedbackFail(
              "error while giving complaint feedback"
            )
          );
        })
      );
    })
  );

  @Effect()
  uploadFiles = this.actions$.pipe(
    ofType(ComplaintsActions.COMPLAINT_UPLOAD_FILES_START),
    switchMap((complaintData: ComplaintsActions.ComplaintUploadFilesStart) => {
      const BASE_URL = this.appConfigService.getConfig().API_BASE_URL + '/citizengrievances/complaint/'

      const endpoint = `${BASE_URL}uploadfiles`;
      const formData = complaintData.payload;

      return this.http.post<any>(endpoint, formData).pipe(
        map((resData) => {
          return new ComplaintsActions.ComplaintUploadFilesSuccess();
        }),
        catchError((errorRes) => {
          return of(
            // console.log(errorRes.console.error)
            new ComplaintsActions.ComplaintUploadFilesFail(
              "error while uploading files"
            )
          );
        })
      );
    })
  );

  @Effect()
  uploadReOpenFiles = this.actions$.pipe(
    ofType(ComplaintsActions.COMPLAINT_UPLOAD_RE_OPEN__FILES_START),
    switchMap((complaintData: ComplaintsActions.ComplaintUploadReOpenFilesStart) => {
      const BASE_URL = this.appConfigService.getConfig().API_BASE_URL + '/citizengrievances/complaint/'

      const endpoint = `${BASE_URL}uploadfiles`;
      const formData = complaintData.payload;

      return this.http.post<any>(endpoint, formData).pipe(
        map((resData) => {
          return new ComplaintsActions.ComplaintUploadReOpenFilesSuccess();
        }),
        catchError((errorRes) => {
          return of(
            // console.log(errorRes.console.error)
            new ComplaintsActions.ComplaintUploadReOpenFilesFail(
              "error while uploading Re Open files"
            )
          );
        })
      );
    })
  );

  @Effect()
  uploadResolvedFiles = this.actions$.pipe(
    ofType(ComplaintsActions.COMPLAINT_UPLOAD_RESOLVED__FILES_START),
    switchMap((complaintData: ComplaintsActions.ComplaintUploadResolvedFilesStart) => {
      const BASE_URL = this.appConfigService.getConfig().API_BASE_URL + '/citizengrievances/complaint/'

      const endpoint = `${BASE_URL}uploadfiles`;
      const formData = complaintData.payload;

      return this.http.post<any>(endpoint, formData).pipe(
        map((resData) => {
          return new ComplaintsActions.ComplaintUploadResolvedFilesSuccess();
        }),
        catchError((errorRes) => {
          return of(
            // console.log(errorRes.console.error)
            new ComplaintsActions.ComplaintUploadResolvedFilesFail(
              "error while uploading resolved files"
            )
          );
        })
      );
    })
  );

  @Effect()
  requestReassignComplaint = this.actions$.pipe(
    ofType(ComplaintsActions.COMPLAINT_REQUEST_RE_ASSIGN_START),
    switchMap((complaintData: ComplaintsActions.ComplaintRequestReassignStart) => {
      const BASE_URL = this.appConfigService.getConfig().API_BASE_URL + '/citizengrievances/complaint/'

      const endpoint = `${BASE_URL}updatecomplaint`;
      const complaintUpdateDetails = complaintData.payload;

      return this.http.put<any>(endpoint, complaintUpdateDetails).pipe(
        map((resData) => {
          return new ComplaintsActions.ComplaintRequestReassignSuccess();
        }),
        catchError((errorRes) => {
          return of(
            // console.log(errorRes.console.error)
            new ComplaintsActions.ComplaintRequestReassignFail(
              "error while requesting re assign complaint"
            )
          );
        })
      );
    })
  );

  @Effect()
  reOpenComplaint = this.actions$.pipe(
    ofType(ComplaintsActions.COMPLAINT_RE_OPEN_START),
    switchMap((complaintData: ComplaintsActions.ComplaintReOpenStart) => {
      const BASE_URL = this.appConfigService.getConfig().API_BASE_URL + '/citizengrievances/complaint/'

      const endpoint = `${BASE_URL}updatecomplaint`;
      const complaintUpdateDetails = complaintData.payload;

      return this.http.put<any>(endpoint, complaintUpdateDetails).pipe(
        map((resData) => {
          return new ComplaintsActions.ComplaintReOpenSuccess();
        }),
        catchError((errorRes) => {
          return of(
            // console.log(errorRes.console.error)
            new ComplaintsActions.ComplaintReOpenFail(
              "error while requesting re assign complaint"
            )
          );
        })
      );
    })
  );

  @Effect()
  resolvedComplaint = this.actions$.pipe(
    ofType(ComplaintsActions.COMPLAINT_MARK_RESOLVED_START),
    switchMap((complaintData: ComplaintsActions.ComplaintMarkResolvedStart) => {
      const BASE_URL = this.appConfigService.getConfig().API_BASE_URL + '/citizengrievances/complaint/'

      const endpoint = `${BASE_URL}updatecomplaint`;
      const complaintUpdateDetails = complaintData.payload;

      return this.http.put<any>(endpoint, complaintUpdateDetails).pipe(
        map((resData) => {
          return new ComplaintsActions.ComplaintMarkResolvedSuccess();
        }),
        catchError((errorRes) => {
          return of(
            // console.log(errorRes.console.error)
            new ComplaintsActions.ComplaintMarkResolvedFail(
              "error while updating complain resolve status"
            )
          );
        })
      );
    })
  );


  constructor(
    private actions$: Actions,
    private http: HttpClient,
    private appConfigService: AppConfigService
  ) {}
}
