import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cg-map-legend',
  templateUrl: './cg-map-legend.component.html',
  styleUrls: ['./cg-map-legend.component.scss']
})
export class CgMapLegendComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
