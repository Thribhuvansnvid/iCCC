import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CgMapLegendComponent } from './cg-map-legend.component';

describe('CgMapLegendComponent', () => {
  let component: CgMapLegendComponent;
  let fixture: ComponentFixture<CgMapLegendComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CgMapLegendComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CgMapLegendComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
