import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cg-home-page',
  templateUrl: './cg-home-page.component.html',
  styleUrls: ['./cg-home-page.component.scss']
})
export class CgHomePageComponent implements OnInit {

  constructor() { }
  showSideNavContainer = true;
  kpiContainer = true;

  ngOnInit() {
  }

}
