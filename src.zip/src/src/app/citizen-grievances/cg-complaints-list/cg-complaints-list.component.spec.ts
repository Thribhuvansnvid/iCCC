import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CgComplaintsListComponent } from './cg-complaints-list.component';

describe('CgComplaintsListComponent', () => {
  let component: CgComplaintsListComponent;
  let fixture: ComponentFixture<CgComplaintsListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CgComplaintsListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CgComplaintsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
