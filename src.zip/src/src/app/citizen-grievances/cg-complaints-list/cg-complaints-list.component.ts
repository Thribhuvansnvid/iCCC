import { Component, OnInit, ViewChild } from '@angular/core'
import { MatPaginator } from '@angular/material'
import { tap } from 'rxjs/operators'
import { ComplaintsFilter } from '../models/complaints.filter.model'
import * as moment from 'moment'
import { ComplaintService } from '../services/citizen.grievance.service'
import { Complaint } from '../models/complaint.model'
// import { CustomMatIconService } from 'src/app/shared/services/custom-icon.service';
import { Router } from '@angular/router'
import { ToastService } from 'src/app/shared/services/toastr.service'

@Component({
  selector: 'cg-complaints-list',
  templateUrl: './cg-complaints-list.component.html',
  styleUrls: ['./cg-complaints-list.component.scss'],
})
export class CgComplaintsListComponent implements OnInit {
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator

  _loadingComplaints: boolean = true
  _complaintsArray: Complaint[] = []
  _totatlComplaintsCount: number = 0
  _itemsDrawnOnMap = false
  _complaintsFilter = new ComplaintsFilter()

  constructor(
    private _complaintService: ComplaintService,
    //  private _customMatIconService: CustomMatIconService,
    private _router: Router,
    private toastService: ToastService
  ) {
    // _customMatIconService.init();
  }

  ngOnInit() {
    this._complaintService.onChangeComplaints.subscribe((filter) => {
      this._complaintsFilter.severity = filter.severity
      this._complaintsFilter.complaint_status = filter.complaint_status
      this._complaintsFilter.smart_vertical = filter.smart_vertical

      this._complaintsFilter.state_name = filter.state_name
      this._complaintsFilter.district_city = filter.district_city
      this._itemsDrawnOnMap = false
      this.loadComplaintsList()
    })
  }

  ngAfterViewInit() {
    this.paginator.page
      .pipe(
        tap(() => {
          this.loadComplaintsList()
        })
      )
      .subscribe()
  }

  loadComplaintsList() {
    this._loadingComplaints = true
    this._complaintsArray = []
    this._totatlComplaintsCount = 0

    this._complaintsFilter.no_of_records = 50
    this._complaintsFilter.page_index = this.paginator.pageIndex + 1
    // complaintsFilter.no_of_records = 50;
    // complaintsFilter.page_index = 1;
    this._complaintsFilter.user_id = 'rajani'

    this._complaintsFilter.front_end = 'WEB'

    // complaintsFilter.state_name = "Karnataka";
    // complaintsFilter.district_city = "Bangalore Urban";
    // complaintsFilter.severity = null;
    // complaintsFilter.complaint_status = null;
    // complaintsFilter.from_date = "2020-10-01 00:10:00";
    // complaintsFilter.to_date =  moment().format(
    //   "YYYY-MM-DD HH:mm:ss"
    // );

    this._complaintService
      .getComplaints(this._complaintsFilter)
      .then((res: { complaints: Complaint[]; totalcount: number }) => {
        if (res.totalcount) {
          this._complaintsArray = res.complaints
          this._totatlComplaintsCount = res.totalcount
        } else {
          this._complaintsArray = []
          this._totatlComplaintsCount = 0
        }
        this._loadingComplaints = false

        if (!this._itemsDrawnOnMap) {
          this.drawComplaintsOnMap()
          this._itemsDrawnOnMap = true
        }
        // console.log(res);
      })
      .catch((error) => {
        console.log(error)

        this._totatlComplaintsCount = -1
        this._loadingComplaints = false
      })
  }

  viewComplaintDetails(complaintId) {
    this.locateComplaintsOnMap(complaintId)
    this._router.navigate(['/auth/cg/home/complaint', complaintId])
  }

  drawComplaintsOnMap() {
    this._complaintService
      // .drawComplaintsOnMap('rajani')
      .drawComplaintsOnMap({
        state_name: this._complaintsFilter.state_name,
        district_city: this._complaintsFilter.district_city,
      })
      .then((res) => {
        console.log('Successfully drawn complaints on map')
      })
      .catch((error) => {
        console.log('Error while drawing complaints on map')
      })
  }

  locateComplaintsOnMap(complaintId) {
    this._complaintService
      .locateComplaintsOnMap(complaintId)
      .then((res) => {
        console.log('Successfully drawn complaints on map')
      })
      .catch((error) => {
        console.log('Error while drawing complaints on map')
      })
  }

  sendEscalationReport() {
    this._complaintService
      .sendEscalationReport()
      .then((res) => {
        this.toastService.successToast(
          `Sent Escalation Report`,
          'Citizen Grievances '
        )

        console.log('Successfully sent escalation report')
      })
      .catch((error) => {
        this.toastService.errorToast(
          `Error while sending Escalation report`,
          'Citizen Grievances'
        )

        console.log('Error while sending escalation report')
      })
  }
}
