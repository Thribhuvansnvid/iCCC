import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CgReportsComponent } from './cg-reports.component';

describe('CgReportsComponent', () => {
  let component: CgReportsComponent;
  let fixture: ComponentFixture<CgReportsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CgReportsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CgReportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
