import { Component, OnInit, ViewChild } from '@angular/core';
import { Subscription } from 'rxjs';
import { ComplaintsFilter } from '../models/complaints.filter.model';
import { ComplaintService } from '../services/citizen.grievance.service';
import {
  ApexAxisChartSeries,
  ApexChart,
  ChartComponent,
  ApexDataLabels,
  ApexXAxis,
  ApexPlotOptions,
  ApexResponsive,
  ApexLegend,
  ApexFill,
  ApexNonAxisChartSeries,
  ApexStroke,
  ApexTitleSubtitle,
  ApexYAxis,
  ApexGrid
} from "ng-apexcharts";
export type ChartOptions = {
  series: ApexAxisChartSeries;
  chart: ApexChart;
  dataLabels: ApexDataLabels;
  plotOptions: ApexPlotOptions;
  xaxis: ApexXAxis;
};

export type StackChartOptions = {
  series: ApexAxisChartSeries;
  chart: ApexChart;
  dataLabels: ApexDataLabels;
  plotOptions: ApexPlotOptions;
  responsive: ApexResponsive[];
  xaxis: ApexXAxis;
  legend: ApexLegend;
  fill: ApexFill;
};

export type PieOptions = {
  series: ApexNonAxisChartSeries;
  chart: ApexChart;
  responsive: ApexResponsive[];
  labels: any;
  stroke: ApexStroke;
  fill: ApexFill;
  title: ApexTitleSubtitle
};
export type LineOptions = {
  series: ApexAxisChartSeries;
  chart: ApexChart;
  xaxis: ApexXAxis;
  dataLabels: ApexDataLabels;
  grid: ApexGrid;
  labels: string[];
  stroke: ApexStroke;
  title: ApexTitleSubtitle;

};
@Component({
  selector: 'app-cg-reports',
  templateUrl: './cg-reports.component.html',
  styleUrls: ['./cg-reports.component.scss']
})
export class CgReportsComponent implements OnInit {

  data: any;

  statusData: any;
  loadingData = true;
  reportData: any;
  reportsSubscription: Subscription;
  chartType = 'BAR_CHART';
  title: any;
  params: any;
  selected = 'WARD_WISE';
  series: any;
  cat: any;
  assigned: any;
  closed: any;
  open: any;
  reopen: any;
  reject: any;
  width: any;

  complaintsFilter = new ComplaintsFilter();
  reportOptions = ['DAY_WISE', 'WEEK_WISE', 'MONTH_WISE', 'YEAR_WISE', 'STATUS_WISE'];
  reportOptionSelected = 'DAY_WISE';
  array = ['DEPARTMENT_WISE', 'WARD_WISE'];

  @ViewChild('chart', { static: true }) chart: ChartComponent
  public chartOptions: Partial<ChartOptions>;
  public stackChartOptions: Partial<StackChartOptions>;
  public pieOptions: Partial<PieOptions>;
  public lineOptions: Partial<LineOptions>;
  public areaOptions: Partial<LineOptions>;
  constructor(private complaintService: ComplaintService) { }

  ngOnInit() {

    this.complaintService.onChangeComplaints.subscribe((filter) => {
      this.complaintsFilter.state_name = filter.state_name
      this.complaintsFilter.district_city = filter.district_city
    })
    this.onApplyConditions();
    // this.loadStackGraph();
    // this.loadPieTypeChart();
    // this.loadLineChart();
    // this.loadAreaChart();
    this.loadingData = false;
  }
  onApplyConditions() {
    this.params = [];
    if (this.reportOptionSelected)
      this.params.push(this.reportOptionSelected)
    if (this.selected) {
      this.params.push(this.selected);
    }
    let options =
    {
      stateName: this.complaintsFilter.state_name,
      districtCity: this.complaintsFilter.district_city,
      countParam: this.params
    }
    console.log("selected  ", this.selected)
    console.log("charttype", options)
    this.reportsSubscription = this.complaintService.getReportsData(options).subscribe(
      data => {
        if (this.reportOptionSelected === 'DAY_WISE') {
          this.title = 'Day Wise';
          this.width = 500;
          this.data = data['DAY_WISE']
          this.series = this.data.map((item) => item.count)
          this.cat = this.data.map((item) => item.date)
          this.loadGraphData();
          // this.loadLineChart();
          this.loadAreaChart();
          this.loadPieTypeChart();
        }
        if (this.reportOptionSelected === 'WEEK_WISE') {

          this.data = data['WEEK_WISE']
          this.width = 350;
          this.series = this.data.map((item) => item.count)
          this.cat = this.data.map((item) => item.weekOfTheYear)
          this.title = 'Week Wise';
          this.loadGraphData();
          this.loadAreaChart();
          this.loadPieTypeChart();

        }
        if (this.reportOptionSelected === 'MONTH_WISE') {
          this.data = data['MONTH_WISE']
          this.title = 'Month Wise';
          this.width = 350;
          this.series = this.data.map((item) => item.count)
          this.cat = this.data.map((item) => item.monthOfTheYear);
          this.loadGraphData();
          this.loadAreaChart();
          this.loadPieTypeChart();

        }
        if (this.reportOptionSelected === 'STATUS_WISE') {
          this.data = data['STATUS_WISE']
          this.title = 'Status Wise';
          this.series = [];
          this.width = 500;
          this.series.push(this.data.Assigned);
          this.series.push(this.data.Reopened);
          this.series.push(this.data.Closed);
          this.series.push(this.data.Rejected);
          this.series.push(this.data.Open);
          this.cat = ["Assign", "Reopen", "Clos", "Reject", "Open"]
          this.loadGraphData();
          this.loadAreaChart();
          this.loadPieTypeChart();
        }
        if (this.reportOptionSelected === 'YEAR_WISE') {
          this.data = data['YEAR_WISE']
          this.title = 'Year Wise';
          this.width = 250;
          this.series = this.data.map((item) => item.count)
          this.cat = this.data.map((item) => item.year);
          this.loadGraphData();
          this.loadAreaChart();
          this.loadPieTypeChart();
        }

        if (this.selected === 'WARD_WISE') {
          this.data = data['WARD_WISE']
          this.title = 'Ward Wise';
          this.width = 500;
          this.cat = this.data.map((item) => item.ward);
          this.assigned = this.data.map((item) => item.Assigned);
          this.open = this.data.map((item) => item.Open);
          this.closed = this.data.map((item) => item.Closed);
          this.reject = this.data.map((item) => item.Rejected);
          this.reopen = this.data.map((item) => item.Reopened);
          this.loadStackGraph();
          this.loadAreaMultiGraph();


        }
        if (this.selected === 'DEPARTMENT_WISE') {
          this.data = data['DEPARTMENT_WISE']
          this.title = 'Department Wise';
          this.width = 550;
          this.cat = this.data.map((item) => item.departmentId);
          this.assigned = this.data.map((item) => item.Assigned);
          this.open = this.data.map((item) => item.Open);
          this.closed = this.data.map((item) => item.Closed);
          this.reject = this.data.map((item) => item.Rejected);
          this.reopen = this.data.map((item) => item.Reopened);
          this.loadStackGraph();
          this.loadAreaMultiGraph();
        }
      }
    );
  }
  loadGraphData() {

    this.chartOptions = {
      series: [
        {
          name: "Count",
          data: this.series
        }
      ],
      chart: {
        type: "bar",
        height: 550,
        width: this.width,
        toolbar: {
          show: true
        },
        zoom: {
          enabled: true
        }
      },
      plotOptions: {
        bar: {
          columnWidth: "45%",
          horizontal: false,

        }
      },
      dataLabels: {
        enabled: false
      },

      xaxis: {
        categories: this.cat,

        title: {
          text: this.title
        }
      }
    };
  }
  loadGraphDayData() {

    this.chartOptions = {
      series: [
        {
          name: "Count",
          data: this.series
        }
      ],
      chart: {
        type: "bar",
        height: 550,
        width: this.width,
        toolbar: {
          show: true
        },
        zoom: {
          enabled: true
        }
      },
      plotOptions: {
        bar: {
          columnWidth: "45%",
          horizontal: false,

        }
      },
      dataLabels: {
        enabled: false
      },

      xaxis: {
        categories: this.cat,
        type: 'datetime',


        title: {
          text: this.title
        }
      }
    };
  }
  loadLineChart() {
    console.log(" area ", this.series, " cat", this.cat);
    this.lineOptions = {
      series: [
        {
          name: "Count",
          data: this.series
        }
      ],
      chart: {
        height: 550,
        width: this.width,
        type: "line",
        toolbar: {
          show: true
        },
        zoom: {
          enabled: true
        }
      },
      dataLabels: {
        enabled: false
      },
      stroke: {
        curve: "straight"
      },
      title: {
        text: this.title,
        align: "left"
      },
      grid: {
        row: {
          colors: ["#f3f3f3", "transparent"], // takes an array which will be repeated on columns
          opacity: 0.5
        }
      },
      xaxis: {
        categories: this.cat,

      }
    };
  }
  loadStackGraph() {

    this.stackChartOptions = {
      series: [
        {
          name: "Assigned",
          data: this.assigned
        },
        {
          name: "Open",
          data: this.open
        },
        {
          name: "Closed",
          data: this.closed
        },
        {
          name: "Rejected",
          data: this.reject
        }
        ,
        {
          name: "Reopen",
          data: this.reopen
        }
      ],
      chart: {
        type: "bar",
        height: 550,
        width: this.width,
        stacked: true,
        toolbar: {
          show: true
        },
        zoom: {
          enabled: true
        }
      },
      responsive: [
        {
          breakpoint: 480,
          options: {
            legend: {
              position: "bottom",
              offsetX: -10,
              offsetY: 0
            }
          }
        }
      ],
      plotOptions: {
        bar: {
          horizontal: false
        }
      },
      xaxis: {
        type: "category",
        title:
        {
          text: this.title,
        },
        categories: this.cat
      },

      legend: {
        position: "right",
        offsetY: 40
      },
      fill: {
        opacity: 1
      }
    };
  }
  loadPieTypeChart() {
    this.pieOptions = {
      series: this.series,
      chart: {
        type: "pie",
        width: 400,
        height: 400,
        toolbar: {
          show: true
        },
        zoom: {
          enabled: true
        }

      },
      title:
      {
        text: this.title
      },
      labels: this.cat,
      stroke: {
        colors: ["#fff"]
      },
      fill: {
        opacity: 0.8
      },
      responsive: [
        {
          breakpoint: 480,
          options: {
            chart: {
              width: 400,
              height: 400
            },
            legend: {
              position: "bottom"
            }
          }
        }
      ]
    };
  }
  loadAreaChart() {
    console.log(" area ", this.series, " cat", this.cat);
    this.lineOptions = {
      series: [
        {
          name: "Count",
          data: this.series
        }
      ],
      chart: {
        type: "area",
        height: 550,
        width: this.width,
        zoom: {
          enabled: true
        },
        toolbar: {
          show: true,
        }
      },
      dataLabels: {
        enabled: true
      },
      stroke: {
        curve: "straight"
      },

      title: {
        text: this.title,
        align: "left"
      },

      labels: this.cat,



    };
  }
  loadAreaMultiGraph() {
    console.log(" area ", this.series, " cat", this.cat);
    this.areaOptions = {
      series: [
        {
          name: "Assigned",
          data: this.assigned
        },
        {
          name: "Open",
          data: this.open
        },
        {
          name: "Closed",
          data: this.closed
        },
        {
          name: "Rejected",
          data: this.reject
        }
        ,
        {
          name: "Reopen",
          data: this.reopen
        }
      ],
      chart: {
        type: "area",
        height: 550,
        width: this.width,
        zoom: {
          enabled: true
        },
        toolbar: {
          show: true,
        }
      },
      dataLabels: {
        enabled: true
      },
      stroke: {
        curve: "straight"
      },

      title: {
        text: this.title,
        align: "left"
      },

      labels: this.cat,



    };
  }
}
