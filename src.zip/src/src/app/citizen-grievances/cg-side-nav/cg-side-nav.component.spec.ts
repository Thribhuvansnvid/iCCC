import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CgSideNavComponent } from './cg-side-nav.component';

describe('CgSideNavComponent', () => {
  let component: CgSideNavComponent;
  let fixture: ComponentFixture<CgSideNavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CgSideNavComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CgSideNavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
