import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cg-side-nav',
  templateUrl: './cg-side-nav.component.html',
  styleUrls: ['./cg-side-nav.component.scss']
})
export class CgSideNavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
