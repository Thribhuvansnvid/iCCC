import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { CgComplaintDetailsComponent } from "./cg-complaint-details/cg-complaint-details.component";
import { CgComplaintImageViewerComponent } from "./cg-complaint-image-viewer/cg-complaint-image-viewer.component";
import { CgComplaintsListComponent } from "./cg-complaints-list/cg-complaints-list.component";
import { CgHomePageComponent } from "./cg-home-page/cg-home-page.component";
import { CgLayoutComponent } from "./cg-layout/cg-layout.component";
import { ComplaintEmployeeMainpageComponent } from "./components/complaint-employee-mainpage/complaint-employee-mainpage.component";
import { CgMapComponent } from "./cg-map/cg-map.component";
import { ComplaintAssignComponent } from "./components/complaint-assign/complaint-assign.component";
import { ComplaintCreationComponent } from "./components/complaint-creation/complaint-creation.component";
import { ComplaintDetailsComponent } from "./components/complaint-details/complaint-details.component";
import { ComplaintFeedbackComponent } from "./components/complaint-feedback/complaint-feedback.component";
import { ComplaintReopenComponent } from "./components/complaint-reopen/complaint-reopen.component";
import { ComplaintResolvedComponent } from "./components/complaint-resolved/complaint-resolved.component";
import { ComplaintSubmittedComponent } from "./components/complaint-submitted/complaint-submitted.component";
import { ComplaintsListComponent } from "./components/complaints-list/complaints-list.component";
import { ComplaintRequestReassignComponent } from "./components/complaint-request-reassign/complaint-request-reassign.component";
import { ComplaintRejectComponent } from "./components/complaint-reject/complaint-reject.component";
import { CgReportsComponent } from "./cg-reports/cg-reports.component";
import { ComplaintCitizenMainpageComponent } from "./components/complaint-citizen-mainpage/complaint-citizen-mainpage.component";
import { ComplaintCitizenListComponent } from "./components/complaint-citizen-list/complaint-citizen-list.component";
import { ComplaintsRoListComponent } from "./components/complaints-ro-list/complaints-ro-list.component";
import { ComplaintsMapViewComponent } from "./components/complaints-map-view/complaints-map-view.component";
import { ComplaintResolvedAcknowledgeComponent } from "./components/complaint-resolved-acknowledge/complaint-resolved-acknowledge.component";
import { ComplaintReopenAcknowledgeComponent } from "./components/complaint-reopen-acknowledge/complaint-reopen-acknowledge.component";
import { ComplaintRejectAcknowledgeComponent } from "./components/complaint-reject-acknowledge/complaint-reject-acknowledge.component";
import { ComplaintRequestReAssignAcknowledgeComponent } from "./components/complaint-request-reassign-acknowledge/complaint-request-reassign-acknowledge.component";
import { ComplaintAssignAcknowledgeComponent } from "./components/complaint-assign-acknowledge/complaint-assign-acknowledge.component";

const pagesRoutes: Routes = [
  {
    path: "list",
    // component: ComplaintRequestReassignComponent,
    component: ComplaintsListComponent,

    // component: ComplaintDetailsComponent,
    // component: ComplaintCreationComponent,
    // component: CgMainpageComponent,
    // component: CgLayoutComponent,

    // children: [
    //   {
    //     path: "home",
    //     component: CgHomePageComponent,
    //     children: [
    //       {
    //         path: "list",
    //         component: CgComplaintsListComponent,
    //       },
    //       {
    //         path: "complaint/:complaintId",
    //         component: CgComplaintDetailsComponent,
    //       },
    //     ],
    //   },
    //   {
    //     path:'images/:complaintId',
    //     component:CgComplaintImageViewerComponent
    //   },
    // ],
  },
  {
    path: "citizen/home",
    component: ComplaintCitizenMainpageComponent,
  },
  {
    path: "employee/home",
    component: ComplaintEmployeeMainpageComponent,
  },
  {
    path: "gro/list",
    component: ComplaintsListComponent,
  },
  {
    path: "citizen/list",
    component: ComplaintCitizenListComponent,
  },
  {
    path: "ro/list",
    component: ComplaintsRoListComponent,
  },
  {
    path: "create",
    component: ComplaintCreationComponent,
  },
  
  {
    path: "details/:complaintId",
    component: ComplaintDetailsComponent,
  },
  {
    path: "assign-complaint/:complaintId",
    component: ComplaintAssignComponent,
  },
  {
    path: "complaint-assign-ack/:complaintId",
    component: ComplaintAssignAcknowledgeComponent,
  },
  
  {
    path: "complaint-submitted/:complaintId",
    component: ComplaintSubmittedComponent,
  },

  {
    path: "complaint-resolved/:complaintId",
    component: ComplaintResolvedComponent,
  },
  {
    path: "complaint-resolved-ack/:complaintId",
    component: ComplaintResolvedAcknowledgeComponent,
  },
  {
    path: "complaint-reopen/:complaintId",
    component: ComplaintReopenComponent,
  },
  {
    path: "complaint-reopen-ack/:complaintId",
    component: ComplaintReopenAcknowledgeComponent,
  },
  {
    path: "complaint-reject/:complaintId",
    component: ComplaintRejectComponent,
  },
  {
    path: "complaint-reject-ack/:complaintId",
    component: ComplaintRejectAcknowledgeComponent,
  },
  {
    path: "complaint-feedback/:complaintId",
    component: ComplaintFeedbackComponent,
  },
  {
    path: "complaint-request-re-assign/:complaintId",
    component: ComplaintRequestReassignComponent,
  },
  {
    path: "complaint-request-re-assign-ack/:complaintId",
    component: ComplaintRequestReAssignAcknowledgeComponent,
  },
  {
    path: "complaints-map-view",
    component: ComplaintsMapViewComponent,
  },
  {
    path: "report",
    component: CgReportsComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(pagesRoutes)],
  exports: [RouterModule],
})
export class CitizenGrievancesRoutes {}
