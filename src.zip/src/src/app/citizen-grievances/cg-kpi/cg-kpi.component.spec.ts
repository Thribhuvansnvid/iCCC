import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CgKpiComponent } from './cg-kpi.component';

describe('CgKpiComponent', () => {
  let component: CgKpiComponent;
  let fixture: ComponentFixture<CgKpiComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CgKpiComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CgKpiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
