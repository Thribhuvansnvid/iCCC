import { Component, OnInit } from '@angular/core'
import { ComplaintService } from '../services/citizen.grievance.service'

@Component({
  selector: 'cg-kpi',
  templateUrl: './cg-kpi.component.html',
  styleUrls: ['./cg-kpi.component.scss'],
})
export class CgKpiComponent implements OnInit {
  loadingData = true
  constructor(private _complaintService: ComplaintService) {}
  kpidata: any = null

  swmCount = 0
  totalCount = 0
  energyTotal = 0
  trafficTotal = 0
  transpostTotal = 0
  ngOnInit() {
    this.loadingData = true

    const data = {
      user_id: 'rajani',
      report_type: 'VERTICAL_WISE_COMPLAINT_STATUS',
    }
    this._complaintService
      .getKpiData(data)
      .then((data: any) => {
        this.loadingData = false
        this.swmCount = data.find((item) => item.type == 'SWM')
          ? data.find((item) => item.type == 'SWM').value
          : 0
        this.energyTotal = data.find((item) => item.type == 'ENERGY')
          ? data.find((item) => item.type == 'ENERGY').value
          : 0
        this.trafficTotal = data.find((item) => item.type == 'TRAFFIC')
          ? data.find((item) => item.type == 'TRAFFIC').value
          : 0
        this.transpostTotal = data.find((item) => item.type == 'TRANSPORT')
          ? data.find((item) => item.type == 'TRANSPORT').value
          : 0

        this.totalCount = data.find((item) => (item.type = 'TOTAL'))
          ? data.find((item) => (item.type = 'TOTAL')).value
          : 0

        // this.kpidata = data;
        // console.log(data);
      })
      .catch((err) => {
        this.loadingData = false

        console.log(err)
      })
  }
}
