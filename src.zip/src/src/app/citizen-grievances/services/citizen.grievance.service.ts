import { Injectable, SkipSelf } from '@angular/core'
import {
  BehaviorSubject,
  Observable,
  of,
  Subject,
  throwError,
  timer,
} from 'rxjs'
// import { Patient } from "../models/patient";
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
} from '@angular/common/http'
import * as moment from 'moment'
import { tap, catchError, map, flatMap } from 'rxjs/operators'
import { AppConfigService } from '../../shared/configs-loader/app.config.service'
import { Complaint } from '../models/complaint.model'
import { ComplaintsFilter } from '../models/complaints.filter.model'

@Injectable()
export class ComplaintService {
  public onChangeComplaints = new BehaviorSubject<ComplaintsFilter>(
    new ComplaintsFilter()
  )

  // public loadAlertsSubject = new BehaviorSubject<any>(null);
  // public sidenavListOpen = new Subject<boolean>();

  // private loadingSubject = new BehaviorSubject<boolean>(false);
  // public loading$ = this.loadingSubject.asObservable();

  // totalCount = 0;
  // fetchedData = false;

  // total_no_of_alerts: number = 0;

  // alertList: Complaint[] = [];
  // alertListFilters: ComplaintsFilter = new ComplaintsFilter();

  BASE_URL = ''

  jsonData: any
  jsonEventString: string
  polling_interval = 30000
  constructor(
    @SkipSelf() private httpClient: HttpClient,
    private appConfigService: AppConfigService
  ) {
    this.BASE_URL = this.appConfigService.getConfig().API_BASE_URL + '/citizengrievances/complaint'
    this.polling_interval = this.appConfigService.getConfig().polling_table_interval

    // this.alertListFilters.no_of_records = 50;
    // this.alertListFilters.page_index = 1;
  }
  getReportsData(params: any) {

    const endpoint = `${this.BASE_URL}/reports`;
    return this.httpClient.post(endpoint, params);


  }
  getComplaints(params: ComplaintsFilter) {
    // this.loadingSubject.next(true);

    // this.fetchedData = false;
    // this.alertList = null;
    // this.totalCount = 0;

    let promise = new Promise((resolve, reject) => {
      //const endpoint = `${this.BASE_URL}/filteralerts`;
      const endpoint = `${this.BASE_URL}/filtercomplaints`
      // const variables = {
      //   // state_name: "all",
      //   // district_city: "all",
      //   // page_index: params.page_index,
      //   // no_of_records: 50,
      //   // // "smartvertical" : params.verticleSelected ,
      //   // smartvertical:
      //   //   params.verticleSelected != "All" ? params.verticleSelected : null,
      //   // eventtype: params.event_type != "All" ? params.event_type : null,
      //   // severity: params.severity != "All" ? params.severity : null,
      //   // "verticleSelected": params.verticleSelected,
      //   // "eventtype": params.event_type,
      //   //**************************************************** */
      //   // fromDate: "2020-02-25 00:10:00",
      //   // toDate: "2020-07-12 00:13:00",
      //   // eventType: "All",
      //   // severity: "All"
      // };
      this.httpClient
        .post(endpoint, params)
        .toPromise()
        .then(
          // (res: any) => {
          (res: { complaints: Complaint[]; totalcount: number }) => {
            // console.log(res);
            // Success
            // this.fetchedData = true;
            // this.loadingSubject.next(false);

            // this.alertList = res.alerts;
            // this.totalCount = res.totalcount;

            // this.alertList.map((obj) => ({ ...obj, showSopStatus: "false" }));
            // console.log(this.alertList[0])
            resolve(res)
          },
          (msg) => {
            // Error
            reject(msg)
            // this.totalCount = 0;
            // this.fetchedData = true;
            // this.loadingSubject.next(false);
          }
        )
    })
    return promise
  }

  getComplaintDetails(params: ComplaintsFilter) {
    // this.loadingSubject.next(true);

    // this.fetchedData = false;
    // this.alertList = null;
    // this.totalCount = 0;

    let promise = new Promise((resolve, reject) => {
      const endpoint = `${this.BASE_URL}/filtercomplaints`
      this.httpClient
        .post(endpoint, params)
        .toPromise()
        .then(
          // (res: any) => {
          (res: { complaints: Complaint[]; totalcount: number }) => {
            // console.log(res);
            resolve(res)
          },
          (msg) => {
            // Error
            reject(msg)
          }
        )
    })
    return promise
  }

  updateComplaint(params) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
    }

    // const endpoint = `${this.BASE_URL}/updatecomplaint`;
    // this.httpClient.put(endpoint, params, httpOptions).subscribe(
    //   (data) => {
    //     console.log(data);
    //   },
    //   (err) => {
    //     console.log(err);
    //   }
    // );

    const body = JSON.stringify(params)

    let promise = new Promise((resolve, reject) => {
      const endpoint = `${this.BASE_URL}/updatecomplaint`
      this.httpClient
        .put(endpoint, params, httpOptions)
        .toPromise()
        .then(
          (res) => {
            resolve(res)
          },
          (msg) => {
            // Error
            reject(msg)
          }
        )
    })
    return promise
  }

  getResponders(complaintId: number) {
    let promise = new Promise((resolve, reject) => {
      const endpoint = `${this.BASE_URL}/getresponder/${complaintId}`
      this.httpClient
        .get(endpoint)
        .toPromise()
        .then(
          (res) => {
            resolve(res)
          },
          (msg) => {
            // Error
            reject(msg)
          }
        )
    })
    return promise
  }

  drawComplaintsOnMap(params: { state_name; district_city }) {
    // let promise = new Promise((resolve, reject) => {
    //   const endpoint = `${this.BASE_URL}/drawcomplaints/${userId}`
    //   this.httpClient
    //     .get(endpoint)
    //     .toPromise()
    //     .then(
    //       (res) => {
    //         resolve(res)
    //       },
    //       (msg) => {
    //         // Error
    //         reject(msg)
    //       }
    //     )
    // })
    // return promise

    let promise = new Promise((resolve, reject) => {
      const endpoint = `${this.BASE_URL}/drawcomplaints`
      this.httpClient
        .post(endpoint, params)
        .toPromise()
        .then(
          (res) => {
            resolve(res)
          },
          (msg) => {
            // Error
            reject(msg)
          }
        )
    })
    return promise
  }

  locateComplaintsOnMap(complaintId: string) {
    let promise = new Promise((resolve, reject) => {
      const endpoint = `${this.BASE_URL}/locateonmap/${complaintId}`
      this.httpClient
        .get(endpoint)
        .toPromise()
        .then(
          (res) => {
            resolve(res)
          },
          (msg) => {
            // Error
            reject(msg)
          }
        )
    })
    return promise
  }

  sendEscalationReport() {
    let promise = new Promise((resolve, reject) => {
      const endpoint = `${this.BASE_URL}/escalateunclosedissues`
      this.httpClient
        .get(endpoint)
        .toPromise()
        .then(
          (res) => {
            resolve(res)
          },
          (msg) => {
            // Error
            reject(msg)
          }
        )
    })
    return promise
  }

  getKpiData(params) {
    let promise = new Promise((resolve, reject) => {
      const endpoint = `${this.BASE_URL}/reports`
      this.httpClient
        .post(endpoint, params)
        .toPromise()
        .then(
          (res: any) => {
            const { VERTICAL_WISE_COMPLAINT_STATUS } = res
            let verticalsData: any[] = []
            let totalComplaints = 0
            // Object.keys(VERTICAL_WISE_COMPLAINT_STATUS).forEach((key) => {
            //   const total =
            //     VERTICAL_WISE_COMPLAINT_STATUS[key].CLOSED +
            //     VERTICAL_WISE_COMPLAINT_STATUS[key].ASSIGNED +
            //     VERTICAL_WISE_COMPLAINT_STATUS[key].OPEN;
            //   totalComplaints = totalComplaints + total;
            //   const label = `${key}`;
            //   verticalsData.push({
            //     type: key,
            //     value: total,
            //   });
            // });

            VERTICAL_WISE_COMPLAINT_STATUS.forEach((item) => {
              const total = item.CLOSED + item.ASSIGNED + item.OPEN

              totalComplaints = totalComplaints + total

              verticalsData.push({
                type: item.smart_vertical,
                value: total,
              })
            })

            verticalsData.push({
              type: 'TOTAL',
              value: totalComplaints,
            })

            // console.log(verticalsData)
            resolve(verticalsData)
          },
          (msg) => {
            // Error
            reject(msg)
          }
        )
    })
    return promise
  }

  getTimeSpan(timespanSelected) {
    let fromDatetime = moment().format('YYYY-MM-DD HH:mm:ss')
    let toDatetime = ''

    switch (timespanSelected) {
      case 'Live': {
        toDatetime = moment()
          .subtract(12, 'hours')
          .format('YYYY-MM-DD HH:mm:ss')
        break
      }
      case 'Last 24 Hours': {
        toDatetime = moment()
          .subtract(24, 'hours')
          .format('YYYY-MM-DD HH:mm:ss')
        break
      }
      case 'Last 2 Days': {
        toDatetime = moment()
          .subtract(48, 'hours')
          .format('YYYY-MM-DD HH:mm:ss')
        break
      }
      case 'Last 3 Days': {
        toDatetime = moment()
          .subtract(72, 'hours')
          .format('YYYY-MM-DD HH:mm:ss')
        break
      }
    }

    return { fromDatetime: toDatetime, toDatetime: fromDatetime }
  }

  getComplaintKpi(params = {}): Observable<any> {
    const endpoint = `${this.BASE_URL}/reports`

    return this.httpClient.post<any>(endpoint, params).pipe(
      tap((res) => {
        console.log(res)
        // return res;
      })
    )
  }

}
