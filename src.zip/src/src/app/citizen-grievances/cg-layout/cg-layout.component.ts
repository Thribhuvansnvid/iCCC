import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cg-layout',
  templateUrl: './cg-layout.component.html',
  styleUrls: ['./cg-layout.component.scss']
})
export class CgLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
