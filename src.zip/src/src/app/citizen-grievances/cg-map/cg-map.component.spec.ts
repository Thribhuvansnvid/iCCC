import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CgMapComponent } from './cg-map.component';

describe('CgMapComponent', () => {
  let component: CgMapComponent;
  let fixture: ComponentFixture<CgMapComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CgMapComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CgMapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
