import { Component, OnInit } from '@angular/core'
import { AppConfigService } from 'src/app/shared/configs-loader/app.config.service'
import { ComplaintService } from '../services/citizen.grievance.service'

@Component({
  selector: 'cg-map',
  templateUrl: './cg-map.component.html',
  styleUrls: ['./cg-map.component.scss'],
})
export class CgMapComponent implements OnInit {
  public gisUrl = ''

  showSideNavContainer = true
  opened = true

  constructor(
    private _configs: AppConfigService,
    private _complaintService: ComplaintService
  ) {
    this.gisUrl =
      this._configs.getConfig().API_BASE_URL +
      '/gis/arcgis?service=SmartComp+login=citizengrievances'
  }

  state_name = ''
  district_city = ''

  ngOnInit() {
    this._complaintService.onChangeComplaints.subscribe((filter) => {
      this.state_name = filter.state_name
      this.district_city = filter.district_city
    })
  }

  iframeLoadEvent() {
    this._complaintService
      .drawComplaintsOnMap({
        state_name: this.state_name,
        district_city: this.district_city,
      })
      .then((res) => {
        console.log('Successfully drawn complaints on map')
      })
      .catch((error) => {
        console.log('Error while drawing complaints on map')
      })
  }
}
