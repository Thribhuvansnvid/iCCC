import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cg-mainpage',
  templateUrl: './cg-mainpage.component.html',
  styleUrls: ['./cg-mainpage.component.scss']
})
export class CgMainpageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
