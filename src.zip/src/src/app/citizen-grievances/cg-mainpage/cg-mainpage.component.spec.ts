import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CgMainpageComponent } from './cg-mainpage.component';

describe('CgMainpageComponent', () => {
  let component: CgMainpageComponent;
  let fixture: ComponentFixture<CgMainpageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CgMainpageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CgMainpageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
