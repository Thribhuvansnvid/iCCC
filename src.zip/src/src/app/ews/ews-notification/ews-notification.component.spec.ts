import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EwsNotificationComponent } from './ews-notification.component';

describe('EwsNotificationComponent', () => {
  let component: EwsNotificationComponent;
  let fixture: ComponentFixture<EwsNotificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EwsNotificationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EwsNotificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
