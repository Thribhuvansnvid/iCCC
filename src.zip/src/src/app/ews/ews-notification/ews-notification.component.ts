import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { EWSService } from '../service/data-service';
import { ToastService } from '../../shared/services/toastr.service';
@Component({
  selector: 'app-ews-notification',
  templateUrl: './ews-notification.component.html',
  styleUrls: ['./ews-notification.component.scss']
})
export class EwsNotificationComponent implements OnInit {
  imgURL: any = [];
  imgname: any = [];
  jsonObj = [];
  img: any;
  name: any;
  ewsForm: FormGroup;
  event_type: string[] = ['FIRE_DETECTED', 'MOTION_DETECTED', 'PIPE_LEAKAGE', 'SOS_ALARAM'];
  dept: string[] = ['AMBULANCE', 'FIRE BRIGADE', 'POLICE', 'OTHER'];
  event_subtype: string[] = ['FIRE_DETECTED', 'MOTION_DETECTED', 'PIPE_LEAKAGE', 'SOS_ALARAM'];
  source: string[] = ['MOBILE', 'POLE'];
  constructor(private formBuilder: FormBuilder, public service: EWSService, private toastService: ToastService) { }

  ngOnInit() {

    this.ewsForm = new FormGroup({
      'userid': new FormControl('',),
      'source': new FormControl('', [Validators.required]),
      'descp': new FormControl(''),
      'event_type': new FormControl(''),
      'dept': new FormControl(''),
      'event_subtype': new FormControl(''),
      'attachment': new FormControl(''),
    })
    this.formControlValueChanged();
  }

  formControlValueChanged() {

    this.ewsForm.get('source').valueChanges.subscribe(
      (source: string) => {
        console.log('source  ', source);
        if (source === 'MOBILE') {
          this.ewsForm.controls.userid.enable();
          this.ewsForm.controls.userid.setValidators([Validators.required]);
          // userControl.setValidators([Validators.required]); 
        }
        else {
          this.ewsForm.controls.userid.disable();
        }
        this.ewsForm.controls.userid.updateValueAndValidity();
      });

  }
  onSubmit() {
    console.log('image list   ', this.jsonObj);
    let body = {
      // user_id: (this.ewsForm.value.userid != null ? this.ewsForm.value.userid : null),
      userId: 'rajani',
      description: (this.ewsForm.value.descp != null ? this.ewsForm.value.descp : null),
      eventYype: (this.ewsForm.value.event_type != null ? this.ewsForm.value.event_type : null),
      eventSubtype: (this.ewsForm.value.event_subtype != null ? this.ewsForm.value.event_subtype : null),
      source: this.ewsForm.value.source,
      attachment: {
        name: this.name,
        data: this.img,
        content_type: (this.img != null ? 'image/png' : null),
      },
    }
    this.service.postNotify(body).
      subscribe((data) => {
        this.toastService.successToast(`New Notification registered Successfully `, `Notify EWS`)
        console.log('data inside post ', data)
      }, err => {
        this.toastService.errorToast(`Error while registering Notification`, `Notify EWS`)
      }
      )
    // console.log('inside onsubmit');
    console.log('body      ', body);

  }
  removeImage(index) {
    if (index > -1) {
      this.imgURL.splice(index, 1);
    }
  }
  onFileSelected(event) {
    // this.selectedFile = <File>event.target.files[0];
    // console.log(this.selectedFile)

    const files: File[] = event.target.files;
    if (files.length === 0) return;

    for (let file of files) {
      let mimeType = file.type;
      if (mimeType.match(/image\/*/) == null) {
        console.log("Only images are supported.");
        return;
      }
    }

    for (let file of files) {
      let item = {}

      let reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (_event) => {
        item["name"] = file.name;
        item["data"] = reader.result;
        item["content"] = "image/png";
        this.img = reader.result;
        this.name = file.name;
        this.imgURL.push(reader.result);
        this.imgname.push(file.name);
        this.jsonObj.push(item);
        console.log('files are ', file.name)
      };
    }
    console.log('final outut  ', this.jsonObj);

  }
}
