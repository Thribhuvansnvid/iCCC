import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EwsImageComponent } from './ews-image.component';

describe('EwsImageComponent', () => {
  let component: EwsImageComponent;
  let fixture: ComponentFixture<EwsImageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EwsImageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EwsImageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
