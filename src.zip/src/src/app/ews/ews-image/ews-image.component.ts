import { HttpClient } from '@angular/common/http';
import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { thresholdFreedmanDiaconis } from 'd3-array';

@Component({
  selector: 'app-ews-image',
  templateUrl: './ews-image.component.html',
  styleUrls: ['./ews-image.component.css']
})
export class EwsImageComponent implements OnInit {

  constructor(@Inject(MAT_DIALOG_DATA) public data: any, private http: HttpClient, public dialogRef:
    MatDialogRef<EwsImageComponent>) { }
  image: any;
  imageName: any;
  ngOnInit() {
    this.data = this.data.row
    console.log("data here is ", this.data)
    this.image = this.data.attachment.data;
    this.imageName = this.data.attachment.name;
    // this.http.get('https://image.shutterstock.com/image-photo/firefighters-extinguish-house-600w-532096123.jpg', { responseType: 'blob' })
    //   .subscribe(blob => {
    //     const reader = new FileReader();
    //     const binaryString = reader.readAsDataURL(blob);
    //     reader.onload = (event: any) => {
    //       console.log('Image in Base64: ', event.target.result);
    //       this.image = event.target.result;
    //     };

    //     reader.onerror = (event: any) => {
    //       console.log("File could not be read: " + event.target.error.code);
    //     };

    // });
  }
  // this.readThis("fire.jpg", "../../../assets/sample/fire.jpg")

  // uploadFiles() {
  //   let image;
  //   try {
  //     let canvas = document.createElement('canvas');
  //     let img = document.createElement('img');
  //     img.src = "assets/sample/fire.jpg";
  //     img.onload = function () {
  //       canvas.height = img.height;
  //       canvas.width = img.width;
  //       let dataURL = canvas.toDataURL('image/png');
  //       console.log('>>><<<', dataURL);
  //       canvas = null;
  //     }
  //     console.log("check output ", img.onloadeddata)
  //   } catch (e) {
  //     console.log('error while processing base64 conversion>>>', e)
  //   }
  // }


}
