export interface EWSModel {
    stateName: string
    districtCity: string
    emergencyEventId: number
    emergencyEventStatus: string
    eventRegistrationDate: string
    description: string
    source: string
    eventSubType: string
    eventType: string
    attachment: attachmenDetail


}
export class attachmenDetail {
    name: string
    data: string
}