import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EwsNotificationComponent } from './ews-notification/ews-notification.component';
import { EwsNotifyComponent } from './ews-notify/ews-notify.component';
import { EwslistComponent } from './ewslist/ewslist.component';
import { HeaderComponent } from './header/header.component';

const routes: Routes = [
  { path: 'notify', component: EwsNotificationComponent },
  { path: 'list', component: EwslistComponent }
  // {
  //   path: '', component: HeaderComponent,
  //   children: [
  //     ,
  //     { path: 'list', component: EwslistComponent },
  //   ]
  // },

];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EwsRoutingModule { }
