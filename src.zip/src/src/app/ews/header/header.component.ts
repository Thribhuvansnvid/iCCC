import { Component, OnInit } from '@angular/core';
import { AppConfigService } from 'src/app/shared/configs-loader/app.config.service';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  constructor(private configs: AppConfigService) { }
  citySelected = 'Chandigarh'
  stateName = 'Punjab'
  ngOnInit() {
  }

  notifyCitySelection(city: string) {
    this.citySelected = city
    this.stateName = this.configs
      .getCityNames()
      .find((item) => item.city == city).state

  }
  getCityNames() {
    return this.configs.getCityNames()
  }
}
