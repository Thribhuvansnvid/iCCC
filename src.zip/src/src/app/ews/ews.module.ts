import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EwsRoutingModule } from './ews-routing.module';
import { EwsNotifyComponent } from './ews-notify/ews-notify.component';
import { MaterialModule } from 'src/app/shared/material/material.module';
import { SharedModule } from '../shared/shared.module';
import { ToastService } from '../shared/services/toastr.service';
import { EwslistComponent } from './ewslist/ewslist.component';
import { EWSService } from './service/data-service';
import { EwsImageComponent } from './ews-image/ews-image.component';
import { HeaderComponent } from './header/header.component';
import { EwsNotificationComponent } from './ews-notification/ews-notification.component';

import { FlexLayoutModule } from "@angular/flex-layout";
@NgModule({
  declarations: [EwsNotifyComponent, EwslistComponent, EwsImageComponent, HeaderComponent, EwsNotificationComponent],
  imports: [
    CommonModule,
    EwsRoutingModule,
    SharedModule,
    MaterialModule,
    FlexLayoutModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [
    ToastService,
    EWSService
  ],
  entryComponents: [
    EwsImageComponent
  ]
})
export class EwsModule { }
