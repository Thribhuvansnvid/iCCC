import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Component, Injectable, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { ToastService } from '../../shared/services/toastr.service';
import { AppConfigService } from 'src/app/shared/configs-loader/app.config.service';
const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
  }),
}
@Component({
  selector: 'app-ews-notify',
  templateUrl: './ews-notify.component.html',
  styleUrls: ['./ews-notify.component.scss']
})

@Injectable()
export class EwsNotifyComponent implements OnInit {
  event_type: string[] = ['FIRE_DETECTED', 'MOTION_DETECTED', 'PIPE_LEAKAGE', 'SOS_ALARAM'];
  event_subtype: string[] = ['FIRE_DETECTED', 'MOTION_DETECTED', 'PIPE_LEAKAGE', 'SOS_ALARAM'];
  source: string[] = ['MOBILE', 'POLE'];
  isImageSaved: boolean;
  fileName: any;
  ewsURL: '';
  image;
  subscription: Subscription;
  constructor(private toastService: ToastService, private configs: AppConfigService,
    private httpClient: HttpClient) {
    this.ewsURL = this.configs.getConfig().ews
  }
  ewsForm: FormGroup;

  ngOnInit() {

    this.ewsForm = new FormGroup({
      'userid': new FormControl('',),
      'source': new FormControl('', [Validators.required]),
      'descp': new FormControl(''),
      'event_type': new FormControl(''),
      'event_subtype': new FormControl(''),
      'attachment': new FormControl(''),
    })
    this.formControlValueChanged();
  }


  formControlValueChanged() {

    this.ewsForm.get('source').valueChanges.subscribe(
      (source: string) => {
        console.log('source  ', source);
        if (source === 'MOBILE') {
          this.ewsForm.controls.userid.enable();
          this.ewsForm.controls.userid.setValidators([Validators.required]);
          // userControl.setValidators([Validators.required]); 
        }
        else {
          this.ewsForm.controls.userid.disable();
        }
        this.ewsForm.controls.userid.updateValueAndValidity();
      });

  }

  onSubmit() {
    let body = {
      // user_id: (this.ewsForm.value.userid != null ? this.ewsForm.value.userid : null),
      userId: 'rajani',
      description: (this.ewsForm.value.descp != null ? this.ewsForm.value.descp : null),
      eventYype: (this.ewsForm.value.event_type != null ? this.ewsForm.value.event_type : null),
      eventSubtype: (this.ewsForm.value.event_subtype != null ? this.ewsForm.value.event_subtype : null),
      source: this.ewsForm.value.source,
      attachment: {
        name: (this.image != null ? this.fileName : null),
        data: (this.image != null ? this.image : null),
        content_type: (this.image != null ? 'image/png' : null),
      },
    }
    this.httpClient.post(this.ewsURL + 'notify', body, httpOptions)
      .subscribe((data) => {
        this.toastService.successToast(`New Notification registered Successfully `, `Notify EWS`)
        console.log('data inside post ', data)
      }, (error: HttpErrorResponse) => {
        this.toastService.errorToast(`Error while registering Notification`, `Notify EWS`)
        console.log(error.name + ' ' + error.message)
      }
      )
    console.log('inside onsubmit');
    console.log('body      ', body);
    console.log('source', this.ewsForm.value.source);
  }


  changeListener($event): void {
    this.fileName = $event.target.files[0].name;
    console.log("event ", $event.target)
    this.readThis($event.target);

  }

  readThis(inputValue: any): void {
    var file: File = inputValue.files[0];
    var myReader: FileReader = new FileReader();

    myReader.onloadend = (e) => {
      this.image = myReader.result;
      console.log(myReader.result);
      this.isImageSaved = true;
    }
    myReader.readAsDataURL(file);
  }
  removeImage() {
    this.image = null;
    this.isImageSaved = false;
  }
}
