import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { map, catchError, tap } from 'rxjs/operators'

import { AppConfigService } from "src/app/shared/configs-loader/app.config.service";
import { EWSModel } from "../model/ews-model";


@Injectable()
export class EWSService {
    ewsURL;
    constructor(private configs: AppConfigService,
        private httpClient: HttpClient) {
        this.ewsURL = this.configs.getConfig().API_BASE_URL + '/ews/emergency/';
    }
    private httpOptions = {
        headers: new HttpHeaders({
            "Content-Type": "application/json",
        }),
    };
    dataRow: any;
    totalCount: any;
    getNotify(params: any): Observable<EWSModel[]> {
        console.log('return ', params)
        return this.httpClient.post<any>(this.ewsURL + 'filterevents', params, this.httpOptions)
            .pipe(
                map((data) => {
                    this.totalCount = data.totalCount;
                    return data
                })
            )
    }
    postNotify(params: any): Observable<any> {
        return this.httpClient.post<any>(this.ewsURL + 'notify', params, this.httpOptions)
            .pipe(
                tap((data) => {
                    console.log("post  ", data);
                })

            )
    }
}
