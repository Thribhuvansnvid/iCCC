import { Injectable } from "@angular/core";
import { ToastrService } from "ngx-toastr";

@Injectable({
  providedIn: 'root'
})
export class ToastService {
  constructor(
    private toastr: ToastrService,
  ) { }

  successToast(msg, titile) {
    this.toastr.success(msg, titile);
  }


  errorToast(msg, titile) {
    this.toastr.error(msg, titile);
  }

}
