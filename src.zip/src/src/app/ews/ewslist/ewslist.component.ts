import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatSort, MatPaginator, MatTable, MatDialog } from '@angular/material';
import { MatMenuTrigger } from '@angular/material/menu';
import { Router } from '@angular/router';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { tap } from 'rxjs/operators';
import { EwsImageComponent } from '../ews-image/ews-image.component';
import { EWSModel } from '../model/ews-model'
import { EWSService } from '../service/data-service';

@Component({
  selector: 'app-ewslist',
  templateUrl: './ewslist.component.html',
  styleUrls: ['./ewslist.component.scss']
})
export class EwslistComponent implements OnInit {
  // mat-table columns
  displayedColumns = [

    "emergencyEventId",
    "eventRegistrationDate",
    "emergencyEventStatus",
    "description",
    "source",
    "eventType",
    "eventSubType",
    "stateName",
    "districtCity",
    // "photo",

  ];
  dataSource: MatTableDataSource<EWSModel[]>;
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild(MatTable, { static: true }) table: MatTable<any>;

  constructor(public service: EWSService, public dialog: MatDialog, private router: Router
  ) { }

  private pageIndex = 0;
  private pageSize = 10;
  public totalCount = 100;
  onPaginateChange(event) {
    console.log('page ', event);
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.getNotifications();
  }
  ngOnInit() {
    this.paginator.pageIndex = 0;
    this.getNotifications();
  }
  refresh() {
    // this.dataSource = ELEMENT_DATA;   
    this.getNotifications()
  }
  onRowClicked(row) {
    let dialogRef = this.dialog.open(EwsImageComponent, {
      data: { row: row },
    }); dialogRef.afterClosed().subscribe((result) => {
      if (result === 1) {
      }
    });

    console.log("Row clicked ", row);
  }
  /* Flag for loading animation */
  isLoading = true;

  getNotifications() {
    let params = {
      pageIndex: this.pageIndex,
      pageSize: this.pageSize,
      sortBy: "eventRegistrationDate"
    }
    this.service.getNotify(params)
      .subscribe((data) => {
        this.isLoading = false;
        console.log("data inseideeeee is    ", data["emergencyEvents"]);
        this.totalCount = this.service.totalCount;
        this.dataSource = new MatTableDataSource(data["emergencyEvents"]);
        this.isLoading = false;
        this.dataSource.sort = this.sort;
        console.log("data in data source is ", this.dataSource)
      },
        (err) => { if (err) console.log("error occured"); this.isLoading = false; }
      )
  }




  /* ### Search field action ### */
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }


  /* ### Export as PDF ### */
  headRows() {
    /* PDF header row column names */
    return [{
      deviceid: 'Device ID',
      devicename: 'Device Name',
      state_name: 'State',
      district_city: 'City',
      devicetype: 'Device Type',
      ipaddress: 'IP Address',
      receivedtime: 'Timestamp',
      // geocoordinates: 'Location',
    }]
  }

  saveAsPdf() {
    /* Export table as pdf */
    var doc = new jsPDF();
    doc.setFontSize(18);
    doc.text('With content', 14, 22);
    doc.setFontSize(11);
    doc.setTextColor(100);

  }

  ngAfterViewInit(): void {
    // this.dataSource.paginator = this.paginator;     
    // this.dataSource.sort = this.sort;
    this.paginator.page
      .pipe(
        tap(() => {
          this.getNotifications()
        })
      )
      .subscribe();
  }

  notify() {
    console.log("clicked notify")
  }

  getCurrentRow(row) {
    this.service.dataRow = row;
    // console.log(row);
  }


}




