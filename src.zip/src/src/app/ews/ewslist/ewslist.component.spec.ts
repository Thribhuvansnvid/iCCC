import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EwslistComponent } from './ewslist.component';

describe('EwslistComponent', () => {
  let component: EwslistComponent;
  let fixture: ComponentFixture<EwslistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EwslistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EwslistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
