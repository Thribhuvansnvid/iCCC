import { Component, OnInit, Input } from "@angular/core";
// import { CustomMatIconService } from "../../shared/services/custom-icon.service";

@Component({
  selector: "cdk-sidemenu-item",
  templateUrl: "./sidemenu-item.component.html",
  styleUrls: ["./sidemenu-item.component.scss"]
})
export class SidemenuItemComponent implements OnInit {
  @Input() menu;
  @Input() iconOnly: boolean;
  @Input() secondaryMenu = false;

  // clickedItem: "dashboard" | "notification" | "comments";
  clickedItem = "Home";

  constructor(
    // private customMatIconService: CustomMatIconService
    ) {
    // customMatIconService.init();
  }

  ngOnInit() {
    console.log(this.menu)
  }

  openLink() {
    this.menu.open = this.menu.open;
  }

  chechForChildMenu() {
    return this.menu && this.menu.sub ? true : false;
  }

  onClick(item) {
    this.menu.open = !this.menu.open;
    this.clickedItem = item;
    console.log(`sidemenu-item clicked item ${this.clickedItem}`)
  }
}
