import { Component, OnInit, Input, HostListener, ElementRef } from '@angular/core';

@Component({
  selector: 'cdk-toolbar-notification',
  templateUrl: './toolbar-notification.component.html',
  styleUrls: ['./toolbar-notification.component.scss']
})
export class ToolbarNotificationComponent implements OnInit {
	cssPrefix = 'toolbar-notification';
  	isOpen: boolean = false;
  	@Input() notifications = [];

    // @HostListener('document:click', ['$event', '$event.target'])
    // onClick(event: MouseEvent, targetElement: HTMLElement) {
    //     if (!targetElement) {
    //           return;
    //     }
    //     const clickedInside = this.elementRef.nativeElement.contains(targetElement);
    //     if (!clickedInside) {
    //          this.isOpen = false;
    //     }
    // }
  	
  	constructor(private elementRef: ElementRef) { }

  	ngOnInit() {
  	}

  	select() {
    	
  	}

  	delete(notification) {
      
    let indexofnotification=this.notifications.indexOf(notification);
    if(indexofnotification>=0)
    {
      this.notifications.splice(indexofnotification,1);
    }

    }
    deleteAllNotification()
    {
      console.log('Inside delete all');
      this.notifications.length=0;
    }

}
