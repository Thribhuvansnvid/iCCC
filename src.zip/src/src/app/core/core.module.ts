import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { SidemenuComponent } from "./sidemenu/sidemenu.component";
import { SidemenuItemComponent } from "./sidemenu-item/sidemenu-item.component";
//import { MatFormFieldModule } from '@angular/material/form-field';
import { RouterModule } from "@angular/router";
import { PerfectScrollbarModule } from "ngx-perfect-scrollbar";
import { PERFECT_SCROLLBAR_CONFIG } from "ngx-perfect-scrollbar";
import { PerfectScrollbarConfigInterface } from "ngx-perfect-scrollbar";
import { FlexLayoutModule } from "@angular/flex-layout";
import { ToolbarNotificationComponent } from "./toolbar-notification/toolbar-notification.component";
import { ToolbarComponent } from "./toolbar/toolbar.component";
import { SearchBarComponent } from "./search-bar/search-bar.component";
//import { FullscreenComponent } from './fullscreen/fullscreen.component';
import { SidebarComponent } from "./sidebar/sidebar.component";

import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MaterialModule } from "../shared/material/material.module";
import { TranslateModule } from '@ngx-translate/core';
import { LanguageSettingsComponent } from './language-settings/language-settings.component';
import { UserMenuComponent } from "./user-menu/user-menu.component";
import { LogOutDialogComponent } from "./dialogs/logout/logout.dialog.component";
//import { CustomMatIconService } from './services/custom-icon.service'
const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true,
};

@NgModule({
  declarations: [
    SidemenuComponent,
    SidemenuItemComponent,
    ToolbarNotificationComponent,
    ToolbarComponent,
    SearchBarComponent,
    //FullscreenComponent,
    SidebarComponent,
    UserMenuComponent,
    LanguageSettingsComponent,
    LogOutDialogComponent
  ],

  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    RouterModule,
    PerfectScrollbarModule,
    FlexLayoutModule,
    MaterialModule,
    TranslateModule,
  ],

  exports: [
    SidemenuComponent,
    SidemenuItemComponent,
    ToolbarNotificationComponent,
    ToolbarComponent,
    SearchBarComponent,
    //FullscreenComponent,
    SidebarComponent,
    UserMenuComponent,
  ],
  entryComponents: [LogOutDialogComponent],
  providers: [
    //CustomMatIconService,
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG,
    },
  ],
})
export class CoreModule { }
