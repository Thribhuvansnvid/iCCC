import { Subject, BehaviorSubject } from 'rxjs'
import { Injectable } from '@angular/core'
import { environment } from '../../../environments/environment'
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs'
import { AppConfigService } from '../../shared/configs-loader/app.config.service'

@Injectable({
  providedIn: 'root',
})
export class CoreService {
  //mainToolbarSelectionChanged = new Subject<string[]>();
  mainToolbarSelectionChanged = new BehaviorSubject<string[]>(null)

  private areaListUrl = ''
  private areaListUrlSWM = ''
  constructor(private http: HttpClient, private configs: AppConfigService) {
    this.areaListUrl = this.configs.getConfig().smartEnergy + '/getAreaDetails'
    //private areaListUrlSWM=environment.smartbinVehicle+"/getBinLocationDetails";
    this.areaListUrlSWM =
      this.configs.getConfig().API_BASE_URL + '/swm/getBinLocationDetails'
  }

  //citySelectionChanged = new Subject<string[]>();
  addNotificationSubject = new Subject<any>()

  onToolbarSelection(data: string[]) {
    this.mainToolbarSelectionChanged.next(data)
    console.log('#' + location)
  }

  addNotification(Notification: any) {
    //this.addNotificationSubject.next(Notification.notification);
    console.log('Notification in core service' + Notification)
    this.addNotificationSubject.next(Notification)
    //console.log("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@on selecton change#######################################"+location);
  }

  getAreaList(cityname: string): Observable<string[]> {
    return this.http.get<string[]>(this.areaListUrl + '/' + cityname)
  }
  getAreaListSWM(): Observable<any> {
    return this.http.get<string[]>(this.areaListUrlSWM)
  }
}
