import { Component, OnInit, Input } from '@angular/core'
//import { menus } from './menu-element';
import { MenuConfigService } from '../../auth/auth.service'
// import { AuthService } from '../../login/services/auth.service'
import { AppConfigService } from '../../shared/configs-loader/app.config.service'
import * as fromApp from "../../store/app.reducer";
import { Store } from "@ngrx/store";
import { Subscription } from 'rxjs';

@Component({
  selector: 'cdk-sidemenu',
  templateUrl: './sidemenu.component.html',
  styleUrls: ['./sidemenu.component.scss'],
})
export class SidemenuComponent implements OnInit {
  @Input() iconOnly: boolean = false
  //public menus = menus;
  public menus
  public mail
  storeSub:Subscription;

  constructor(
    private menuConfigService: MenuConfigService,
    // private authService: AuthService,
    private appConfigService: AppConfigService,
    private store: Store<fromApp.AppState>,
  ) {
    // this.storeSub = this.store
    // .select("auth")
    // .subscribe(({ user }) => {
    //   console.log(user)
    //   if(user.userId == 'civilian'){
    //     this.menus = this.appConfigService.getCitizenMenuConfig()
    //   }
    //   else{
    //     this.menus = this.appConfigService.getMenuConfig()
    //   }
    // });

    this.storeSub = this.store
    .select("core")
    .subscribe(({ maindata }) => {
      if(maindata.length > 0){
        this.menus = maindata.filter(item=>item.type === 'menu')
        console.log(this.menus)
      }
    });

    // this.menus = this.menuConfigService.menuConfig;
    // this.authService.user.subscribe((data) => {
    //   this.mail = data.user_id
    //   console.log('menu-config logged in email : ' + data.user_id)
    // })
    //console.log('menu-config logged in email : '+this.mail);
    //  this.mail='admin@bel.co.in';
    //console.log('menu-config logged in email : '+this.mail);
    //console.log('menu is ', this.menus);
  }

  ngOnInit() {}
}
