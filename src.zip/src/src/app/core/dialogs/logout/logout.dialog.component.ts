import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog'
import { Component, Inject } from '@angular/core'

@Component({
  // selector: 'app-add.dialog',
  templateUrl: './logout.dialog.html',
  styleUrls: ['./logout.dialog.scss'],
})
export class LogOutDialogComponent {

  constructor(
    public dialogRef: MatDialogRef<LogOutDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
  }

  confirmLogout() {
    this.dialogRef.close()
  }

  cancelLogout(){
    this.dialogRef.close()
  }

}
