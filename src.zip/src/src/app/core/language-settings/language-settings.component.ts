import {
  Component,
  ElementRef,
  OnInit,
  Input,
  HostListener,
} from "@angular/core";
import { TranslateConfigService } from "src/app/shared/services/translate-config.service";

@Component({
  selector: "cdk-language-settings",
  templateUrl: "./language-settings.component.html",
  styleUrls: ["./language-settings.component.scss"],
})
export class LanguageSettingsComponent implements OnInit {
  isOpen: boolean = false;

  selectedLanguage:string = 'English'

  @Input() currentUser = null;
  @HostListener("document:click", ["$event", "$event.target"])
  onClick(event: MouseEvent, targetElement: HTMLElement) {
    if (!targetElement) {
      return;
    }

    const clickedInside = this.elementRef.nativeElement.contains(targetElement);
    if (!clickedInside) {
      this.isOpen = false;
    }
  }

  constructor(private elementRef: ElementRef, private translateConfigService: TranslateConfigService) {}

  ngOnInit() {}


  changeLanguage(type: string, languageName: string) {
    this.selectedLanguage = languageName;
    this.translateConfigService.changeLanguage(type);
  }

}
