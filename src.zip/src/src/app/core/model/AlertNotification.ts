export class AlertNotification{
    title:string;
    alertid:string;
    
}