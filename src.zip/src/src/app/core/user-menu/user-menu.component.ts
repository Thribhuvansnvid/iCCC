import {
  Component,
  OnInit,
  Input,
  HostListener,
  ElementRef,
} from '@angular/core'
// import { AuthService } from '../../login/services/auth.service';
import { Store } from '@ngrx/store'
import * as fromApp from '../../store/app.reducer'
import * as AuthActions from '../../login/store/auth.actions'
import { LogOutDialogComponent } from '../dialogs/logout/logout.dialog.component'
import { MatDialog } from '@angular/material'
import { ThemeSwitcherComponent } from 'src/app/shared/services/theme-switcher.service'

@Component({
  selector: 'cdk-user-menu',
  templateUrl: './user-menu.component.html',
  styleUrls: ['./user-menu.component.scss'],
})
export class UserMenuComponent implements OnInit {
  isOpen: boolean = false
  lightTheme = true
  darkTheme = false

  //currentUser = null;
  Hari

  @Input() currentUser = null
  
  @HostListener('document:click', ['$event', '$event.target'])
  onClick(event: MouseEvent, targetElement: HTMLElement) {
    if (!targetElement) {
      return
    }

    const clickedInside = this.elementRef.nativeElement.contains(targetElement)
    if (!clickedInside) {
      this.isOpen = false
    }
  }

  constructor(
    private ThemeSwitcherComponent:ThemeSwitcherComponent,
    public dialog: MatDialog,
    private elementRef: ElementRef,
    private store: Store<fromApp.AppState> // private authService: AuthService
  ) { }

  ngOnInit() {
    if(this.ThemeSwitcherComponent.themeColor === 'dark-theme'){
      this.lightTheme = false
      this.darkTheme = true
    }else{
      this.lightTheme = true
      this.darkTheme = false
    }
   }

  //   logout() {
  // 	this.authService.logout();
  // }

  logout() {
    // this.authService.logout()

    const dialogRef = this.dialog.open(LogOutDialogComponent, {
      disableClose: true,
      autoFocus: true,
    })

    dialogRef.afterClosed().subscribe((result) => {
      if (result === 1) {
        this.store.dispatch(new AuthActions.Logout())
      }
    })
  }

  // changeTheme(){
  //   this.myTheme = !this.myTheme;

  //   this.myTheme ?
  //   this.ThemeSwitcherComponent.themeSwitcher('light-theme'):
  //   this.ThemeSwitcherComponent.themeSwitcher('dark-theme')

  //   console.log(this.myTheme)
  // }

  switchToLightTheme(){
    this.ThemeSwitcherComponent.themeSwitcher('light-theme')
    this.lightTheme = true;
    this.darkTheme = false;
  }

  switchTodarkTheme(){
    this.ThemeSwitcherComponent.themeSwitcher('dark-theme')
    this.darkTheme = true;
    this.lightTheme = false;

  }

}
