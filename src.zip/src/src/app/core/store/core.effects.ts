import { Injectable } from '@angular/core'
import { Router } from '@angular/router'
import { Actions, ofType, Effect } from '@ngrx/effects'
import { switchMap, catchError, map, tap } from 'rxjs/operators'
import { of } from 'rxjs'
import { HttpClient } from '@angular/common/http'
import { AppConfigService } from "src/app/shared/configs-loader/app.config.service";
import * as CoreActions from './core.actions'


@Injectable()
export class CoreEffects {

  @Effect()
  authLogin = this.actions$.pipe(
    ofType(CoreActions.FETCH_MENU_LIST_START),
    switchMap((data: CoreActions.FetchMenuListStart) => {

      const endpoint = `${this.appConfigService.getConfig().API_BASE_URL}/mdms/maindata`;

      return this.http
        .post<any>(endpoint, {
          city: data.payload.city,
          roles: data.payload.roles,
        })
        .pipe(
          map((resData) => {
            localStorage.setItem('maindata', JSON.stringify(resData.menuList))
            return new CoreActions.FetchMenuListSuccess(
              resData
            );
          }),
          catchError((errorRes) => {
            return of(
              new CoreActions.FetchMenuListFail(
                errorRes.console.error
              )
            );
          })
        )
    })
  )

  constructor(
    private actions$: Actions,
    private http: HttpClient,
    private router: Router,
    private appConfigService: AppConfigService
  ) { }
}
