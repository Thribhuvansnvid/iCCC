import { Action } from '@ngrx/store'

export const FETCH_MENU_LIST_START = '[Core] Menu Start'
export const FETCH_MENU_LIST_SUCCESS = '[Core] Menu Sucess'
export const FETCH_MENU_LIST_FAIL = '[Core] Menu Fail'


export class FetchMenuListSuccess implements Action {
  readonly type = FETCH_MENU_LIST_SUCCESS

  constructor(
    public payload: {
      menuList: any[]
    }
  ) {}
}

export class FetchMenuListStart implements Action {
  readonly type = FETCH_MENU_LIST_START
  constructor(public payload: { city: string; roles: string[] }) {}
}

export class FetchMenuListFail implements Action {
  readonly type = FETCH_MENU_LIST_FAIL

  constructor(public payload: string) {}
}

export type CoreActions =
  | FetchMenuListSuccess
  | FetchMenuListStart
  | FetchMenuListFail
