import * as CoreActions from './core.actions'

export interface State {
  maindata: any[]
  menuError: string
  loading: boolean
}

const initialState: State = {
  maindata: JSON.parse(localStorage.getItem('maindata')) ? JSON.parse(localStorage.getItem('maindata')) :[],
  menuError: null,
  loading: false,
}

export function coreReducer(
  state = initialState,
  action: CoreActions.CoreActions
) {
  switch (action.type) {
    case CoreActions.FETCH_MENU_LIST_SUCCESS:

      return {
        ...state,
        menuError: null,
        maindata: action.payload.menuList,
        loading: false,
      }
    case CoreActions.FETCH_MENU_LIST_FAIL:
      return {
        ...state,
        menuError:action.payload,
        maindata: null,
        loading: false,
      }
    case CoreActions.FETCH_MENU_LIST_START:
      return {
        ...state,
        maindata:[],
        menuError: null,
        loading: true,
      }

    default:
      return state
  }
}
