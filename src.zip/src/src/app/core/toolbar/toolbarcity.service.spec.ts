import { TestBed } from '@angular/core/testing';

import { ToolbarcityService } from './toolbarcity.service';

describe('ToolbarcityService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ToolbarcityService = TestBed.get(ToolbarcityService);
    expect(service).toBeTruthy();
  });
});
