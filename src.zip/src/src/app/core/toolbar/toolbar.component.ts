import { Component, OnInit, Input, OnDestroy, ChangeDetectorRef } from '@angular/core'
import { ToolbarHelpers } from './toolbar.helpers'

import { CoreService } from '../services/core.service'
import { Subscription } from 'rxjs'
import { CustomMatIconService } from '../../shared/services/custom-icon.service'
import { ServerNotificationService } from '../../shared/services/server.notification.service'
import { ToastService } from '../../shared/services/toastr.service'
import { MySseService } from 'src/app/shared/server-sent-events/sw-service-worker.service'
import { AppConfigService } from 'src/app/shared/configs-loader/app.config.service'
import { TranslateConfigService } from 'src/app/shared/services/translate-config.service'
import { MySseServiceService } from 'src/app/shared/server-sent-events/my-sse-service.service'
import { FileInjectorService } from 'src/app/shared/services/loadJS.service'
import { Store } from '@ngrx/store'
import * as fromApp from '../../store/app.reducer'
import * as AuthActions from '../../login/store/auth.actions'
import { User } from 'src/app/login/models/user.model'

declare const googleTranslateElementInit: any

@Component({
  selector: 'cdk-toolbar',
  templateUrl: './toolbar.component.html',

  styleUrls: ['./toolbar.component.scss'],
})
export class ToolbarComponent implements OnInit, OnDestroy {
  currentUser = {
    // currentUserName: "Ashok Kurukundi",
    currentUserName: '',
  }


  cityname = 'Belagavi'
  zone = 'All'
  area = 'All'

  private subscription: Subscription
  private subscriptionBelgaviData: Subscription
  private subscriptionWebsocket: Subscription
  private storeSub1: Subscription
  private storeSub2: Subscription

  loggedInUser: User = null

  @Input() sidenav
  @Input() sidebar
  @Input() drawer
  @Input() matDrawerShow
  @Input() sideNavOpened

  appName: string = ''
  appCityName: string = ''

  searchOpen: boolean = false
  toolbarHelpers = ToolbarHelpers

  areaList: string[]
  areaWardList: any[]

  states = []
  cities = []
  wardsList = []
  areasList = []

  constructor(
    private coreservice: CoreService,
    private toastr: ToastService,
    private serverNotificationService: ServerNotificationService,
    private customIconService: CustomMatIconService,
    private store: Store<fromApp.AppState>,
    private MySseService: MySseService,
    private appConfigService: AppConfigService,
    private _mySseServiceService: MySseServiceService,
    private _cdr: ChangeDetectorRef,
    private fileInjectorService: FileInjectorService // private translateConfigService: TranslateConfigService
  ) {
    this.customIconService.init()

    // this.appName = this.appConfigService.getSystemConfig().appName
    // this.appCityName = this.appConfigService.getSystemConfig().cityName
  }

  ngOnInit() {
    // console.log(`side nav opened ${this.sideNavOpened}`)
    this.storeSub1 = this.store.select("auth").subscribe(({ user }) => {
      this.loggedInUser = user;
    });

    this.storeSub2 = this.store
      .select("core")
      .subscribe(({ maindata }) => {
        if (maindata.length > 0) {
          this.appName = maindata.find(o => o.name === 'appName').displayName;
          this.appCityName = maindata.find(o => o.name === 'appCityName').displayName
          this._cdr.detectChanges()
          console.log(this.appCityName)
        }
      });


    // this.subscription = this.coreservice.addNotificationSubject.subscribe(notification => {
    // 	this.toolbarHelpers.notifications.push({
    // 		id: 'id',
    // 		title: notification.title,
    // 		lastTime: '12 Minutes ago',
    // 		state: 'state'
    // 	})
    // })

    // this.MySseService.getServerSentEvent(`http://localhost:3000/my-endpoint`).subscribe(data=>{
    //   console.log(`SSE ${data}`)
    //   console.log(data)
    // },
    // err=>{
    //   console.log(`SSE Error`)
    //   console.log(err)
    // })

    // this.fileInjectorService
    // .loadJS(
    //   "google-translator"
    // )
    // .then((data) => {
    //   googleTranslateElementInit()
    // })
    // .catch((error) => console.log(error));

    // this._mySseServiceService.getServerSentEvents(`http://localhost:3000/events`).subscribe(data=>{
    //   console.log(`SSE ${data}`)
    //   console.log(data)
    // },
    // err=>{
    //   console.log(`SSE Error`)
    //   console.log(err)
    // })

    this.subscriptionWebsocket = this.serverNotificationService.onWebSocketAlertRcvd.subscribe(
      (alert) => {
        // let alertMsg = JSON.parse(alert)
        this.toastr.errorToast(
          `${alert.alertmessage}`,
          `${alert.eventtype} - ${alert.alertid} `
        )
        this.toolbarHelpers.notifications.push({
          id: alert.alertid,
          title: alert.alertmessage,
        })
      }
    )

    // this.pushService.onWebSocketAlertRcvd.subscribe(alert=>{

    // 	this.alertMessageFromWebSocket=JSON.parse(alert);
    // 	this.notification.title=this.alertMessageFromWebSocket.AlertMessage;

    // 	this.toastr.warning(this.alertMessageFromWebSocket.AlertMessage,this.alertMessageFromWebSocket.EventType);
    //   });

    // this.smartBin.notifyToolBar.subscribe((data)=>
    // {
    // 	if(data==='swm')
    // 	{
    // 		 this.isSWMLoaded=true;
    // 		 this.cityname = "Belagavi";
    // 		 this.coreservice.onToolbarSelection(['Belagavi','All','All']);
    // 	}
    // 	else
    // 	{
    // 		this.isSWMLoaded=false;
    // 	}
    // });

    // this.subscriptionBelgaviData = this.coreservice.getAreaListSWM().
    // pipe(take(1)).subscribe((data) => {
    this.subscriptionBelgaviData = this.coreservice
      .getAreaListSWM()
      .subscribe((data) => {
        console.dir(data)
        const usersJson: any[] = Array.of(data)
        const swmJSONDataStr = JSON.stringify(data)
        const swmJSONData = JSON.parse(swmJSONDataStr)

        this.areaWardList = swmJSONData
      })

    this.coreservice.onToolbarSelection([this.cityname, this.zone, this.area])
  }

  async getAreaList() {
    await this.coreservice
      .getAreaList(this.cityname)
      .toPromise()
      .then((data) => {
        this.areaList = data
        console.log(`area list count ${this.areaList.length}`)
      })
  }

  changeCitySelector() {
    console.log('toolbar selected city : ' + this.cityname)
    if (this.cityname == 'Belagavi') {
      this.areaWardList.filter((element) => {
        if (element.cityname == this.cityname) {
          console.log(element.wardAndAreas[0].wardName, 'first wardName')
          this.wardsList = element.wardAndAreas
        }
      })

      this.zone = 'All'
      this.area = 'All'
    }
    this.coreservice.onToolbarSelection([this.cityname, this.zone, this.area])
  }

  wardChnage() {
    console.log('toolbar-wardChnage')
    this.wardsList.filter((element) => {
      if (element.wardName == this.zone) {
        this.areasList = element.areaNames
        //this.ward = this.zone;
        //this.area = element.areaNames[0]
      }
    })

    //console.dir(this.areasList)
    this.coreservice.onToolbarSelection([this.cityname, this.zone, this.area])
  }

  statesChange(evt) {
    console.log('statechange' + evt.target.value, this.states)
    this.states.filter((element) => {
      if (element.name == evt.target.value) {
        this.cities = element.cities
      }
    })
  }

  areaChnageSWM() {
    this.coreservice.onToolbarSelection([this.cityname, this.zone, this.area])
  }

  changeZoneSelector() {
    console.log('toolbar selected zone : ' + this.zone)
    this.coreservice.onToolbarSelection([this.cityname, this.zone, this.area])
  }

  changeAreaSelector() {
    console.log('toolbar selected area : ' + this.area)
    this.coreservice.onToolbarSelection([this.cityname, this.zone, this.area])
  }

  getDateTime() {
    return new Date()
  }

  SendToast() {
    this.toastr.successToast('Hello world!', 'Toastr fun!')
  }

  logout() {
    // this.authService.logout()
    this.store.dispatch(new AuthActions.Logout())
  }

  ngOnDestroy() {
    if (this.subscription) {
      this.subscription.unsubscribe()
    }

    if (this.subscriptionBelgaviData) {
      this.subscriptionBelgaviData.unsubscribe()
    }

    if (this.subscriptionWebsocket) {
      this.subscriptionWebsocket.unsubscribe()
    }
    this.storeSub1 && this.storeSub1.unsubscribe();
    this.storeSub2 && this.storeSub2.unsubscribe();
  }
}
