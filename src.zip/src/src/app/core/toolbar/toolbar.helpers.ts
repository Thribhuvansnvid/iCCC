export const ToolbarHelpers = {
	notifications: [
  		// {
	    //     id: 'id',
	    //     title: 'Alert',
	    //     lastTime: '23 Minutes ago',
	    //     state: 'state'
	    // },
	    // {
	    //     id: 'id',
	    //     title: 'Alert',
	    //     lastTime: '23 Minutes ago',
	    //     state: 'state'
	    // },
	    // {
	    //     id: 'id',
	    //     title: 'Alert',
	    //     lastTime: '23 Minutes ago',
	    //     state: 'state'
	    // },
	],

	currentUser: {
		photoURL: 'assets/images/avatars/hari.jpg',
		currentUserName: 'ADMIN'
	}
};