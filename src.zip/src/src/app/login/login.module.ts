import { NgModule } from '@angular/core'
import { NgbModule } from '@ng-bootstrap/ng-bootstrap'
import { LoginComponent } from './login/login.component'
import { CommonModule } from '@angular/common'
import { FlexLayoutModule } from '@angular/flex-layout'
import { Routes, RouterModule } from '@angular/router'
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { LoadingScreenComponent } from './loading-screen/loading-screen.component'
import { MaterialModule } from '../shared/material/material.module'
import { SignuppageComponent } from './signuppage/signuppage.component'
import { ShowErrorsComponent } from './show-errors/show-errors.component'

const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'signup', component: SignuppageComponent },
]
@NgModule({
  imports: [
    CommonModule,
    FlexLayoutModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
    NgbModule,
  ],
  declarations: [
    LoginComponent,
    LoadingScreenComponent,
    SignuppageComponent,
    ShowErrorsComponent,
  ],
  exports: [RouterModule],
  providers: [],
})
export class LoginModule {}
