import { Component, OnInit } from '@angular/core'
import { Router } from '@angular/router'
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms'
//import { NgForm } from '@angular/forms';
import { Observable, Subscription } from 'rxjs'
import { ToastrService } from 'ngx-toastr'

// import { AuthService, AuthResponseData } from '../services/auth.service'
import { LoadingScreenService } from '../services/loadingscreen'
import { flatMap } from 'rxjs/operators'
import { AppConfigService } from 'src/app/shared/configs-loader/app.config.service'

import { Store } from '@ngrx/store'
import * as fromApp from '../../store/app.reducer'
import * as AuthActions from '../store/auth.actions'
import * as CoreActions from '../../core/store/core.actions'
import { SpinnerOverlayService } from 'src/app/shared/spinner-overlay/spinner-overlay.service'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  isLoginMode = true
  isLoading = false
  error: string = null
  private storeSub: Subscription

  appName: string = ''
  appCityName: string = ''
  
  userForm: FormGroup
  formErrors = {
    email: '',
    password: '',
  }
  validationMessages = {
    email: {
      required: 'Please enter your email',
      email: 'please enter your vaild email',
    },
    password: {
      required: 'please enter your password',
      pattern: 'The password must contain numbers and letters',
      minlength: 'Please enter more than 4 characters',
      maxlength: 'Please enter less than 25 characters',
    },
  }

  constructor(
    // private authService: AuthService,
    private router: Router,
    private toastr: ToastrService,
    private fb: FormBuilder,
    private loadingScreenService: LoadingScreenService,
    // private spinnerOverlayService: SpinnerOverlayService,
    private appConfigService: AppConfigService,
    private store: Store<fromApp.AppState>
  ) {
    this.appName = this.appConfigService.getSystemConfig().appName
    this.appCityName = this.appConfigService.getSystemConfig().cityName
    // this.appCityName = `Welcome to ${this.appConfigService.getSystemConfig().cityName}`
  }

  ngOnInit() {
    this.storeSub = this.store.select('auth').subscribe((authState) => {
      this.isLoading = authState.loading
      this.error = authState.authError
      if (authState.user) {
        // this.spinnerOverlayService.hide();

        this.store.dispatch(
          new CoreActions.FetchMenuListStart({ city: authState.user.districtCity, roles: authState.user.role })
        )

        this.SendSuccessToast('Logged in', 'Login')
      }
      if (this.error) {
        // this.spinnerOverlayService.hide();
        this.SendErrorToast(this.error, 'Login')
      }
    })

    this.buildForm()
  }

  ngOnDestroy() {
    if (this.storeSub) {
      this.storeSub.unsubscribe()
    }
  }

  buildForm() {
    this.userForm = this.fb.group({
      email: ['', [Validators.required]],
      password: [
        '',
        [
          //Validators.pattern('^(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9]+)$'),
          //Validators.pattern('^(?=.*[0-9])([a-zA-Z0-9]+)$'),
          Validators.required,
          //Validators.minLength(6),
          //Validators.maxLength(25)
        ],
      ],
    })
  }

  onSubmit() {
    if (this.userForm.valid) {
      if (!this.userForm.valid) {
        return
      }
      const email = this.userForm.value.email
      const password = this.userForm.value.password

      if (this.isLoginMode) {
        // this.spinnerOverlayService.show();
        this.store.dispatch(
          new AuthActions.LoginStart({ userId: email, password: password })
        )
      } else {
        this.store.dispatch(
          new AuthActions.SignupStart({ userId: email, password: password })
        )
      }
    } else {
      this.validateAllFormFields(this.userForm)
    }
    this.userForm.reset()
  }

  onSwitchMode() {
    this.isLoginMode = !this.isLoginMode
  }

  SendSuccessToast(msg, titile) {
    this.toastr.success(msg, titile)
  }

  SendErrorToast(msg, titile) {
    this.toastr.error(msg, titile)
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach((field) => {
      const control = formGroup.get(field)
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true })
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control)
      }
    })
  }
}
