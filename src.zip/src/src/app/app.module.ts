import { BrowserModule } from '@angular/platform-browser'
import { NgModule, APP_INITIALIZER } from '@angular/core'
import { AppConfigService } from './shared/configs-loader/app.config.service'
import { AppComponent } from './app.component'
import { LazyLoadModule } from './lazy-load/lazy-load.module'
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'
import { CoreModule } from './core/core.module'
import { ServiceWorkerModule } from '@angular/service-worker'
import { SwPush, SwUpdate } from '@angular/service-worker'
import { environment } from '../environments/environment'
import { AlertNotification } from './core/model/AlertNotification'
const VAPID_PUBLIC =
  'BBYCxwATP2vVgw7mMPHJfT6bZrJP2iUV7OP_oxHzEcNFenrX66D8G34CdEmVULNg4WJXfjkeyT0AT9LwavpN8M4='
import { ToastrModule } from 'ngx-toastr'
import {
  HttpClient,
  HttpClientModule,
  HTTP_INTERCEPTORS,
} from '@angular/common/http'
import { ToastrService } from 'ngx-toastr'
import { AppInterceptorService } from './shared/interceptor/app.interceptor.service'
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { FormlyModule } from '@ngx-formly/core'
import { FormlyMaterialModule } from '@ngx-formly/material'
import { TranslateHttpLoader } from '@ngx-translate/http-loader'
import { TranslateLoader, TranslateModule } from '@ngx-translate/core'
import { StoreModule } from '@ngrx/store'
import { EffectsModule } from '@ngrx/effects'
import { StoreDevtoolsModule } from '@ngrx/store-devtools'
import { StoreRouterConnectingModule } from '@ngrx/router-store'
import * as fromApp from './store/app.reducer'
import { AuthEffects } from './login/store/auth.effects'
import { AlertsEffects } from './alerts/store/alerts.effects'

import { NgxImageZoomModule } from 'ngx-image-zoom';

import { ReportsEffects } from './reports/store/reports.effects'
import { ComplaintsEffects } from './citizen-grievances/store/complaint.effects';
import { CoreEffects } from './core/store/core.effects'


const appInitializerFunction = (appConfig: AppConfigService) => {
  return () => {
    return appConfig.loadApiConfig()
  }
}

export function rootLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, 'assets/languages/', '.json')
}

@NgModule({
  declarations: [
    AppComponent,

    //SafePipe
  ],
  imports: [
    NgxImageZoomModule,
    BrowserModule,
    LazyLoadModule,
    CoreModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot({
      timeOut: 10000,
      positionClass: 'toast-bottom-right',
      preventDuplicates: true,
      closeButton: true,
    }),
    HttpClientModule,
    ServiceWorkerModule.register('ngsw-worker.js', {
      enabled: environment.production,
      registrationStrategy: 'registerImmediately',
    }),
    FormsModule,
    ReactiveFormsModule,
    FormlyModule.forRoot({ extras: { lazyRender: true } }),
    FormlyMaterialModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: rootLoaderFactory,
        deps: [HttpClient],
      },
    }),
    StoreModule.forRoot(fromApp.appReducer),
    EffectsModule.forRoot([AuthEffects, AlertsEffects, ReportsEffects, ComplaintsEffects, CoreEffects]),
    StoreDevtoolsModule.instrument({ logOnly: environment.production }),
    StoreRouterConnectingModule.forRoot(),
  ],
  providers: [
    // {provide:OverlayContainer, useClass: FullscreenOverlayContainer}
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AppInterceptorService,
      multi: true,
    },
    AppConfigService,
    {
      provide: APP_INITIALIZER,
      useFactory: appInitializerFunction,
      multi: true,
      deps: [AppConfigService],
    },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {
  alertMessageFromWebSocket: any
  notification: AlertNotification

  constructor() { }
}
