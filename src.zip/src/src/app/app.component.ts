import { Component, OnInit, HostBinding } from '@angular/core'
import { SwPush, SwUpdate } from '@angular/service-worker'
import { PushNotificationFromServerService } from './shared/services/push-notification.service'
const VAPID_PUBLIC =
  'BDJQc5VY0wHB5KZygvqNibn7u8VWDB3H5AYhIGDX8OUaoZq68-we24yu9zypTGrq5jaDO87z_ImgdIWkWrU3HW0'

import * as fromApp from './store/app.reducer'
import * as AuthActions from './login/store/auth.actions'
import { Store } from '@ngrx/store'
import { ThemeSwitcherComponent } from './shared/services/theme-switcher.service'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit {
  title = 'app'
  private isDark = false

  // @HostBinding('class')
  // get themeMode(){
  //   return this.isDark ? 'theme-dark' : 'theme-light'
  // }

  getRouteAnimation(outlet) {
    return outlet.activatedRouteData.animation
  }

  // constructor(
  //   private authService: AuthService){
  // }

  ngOnInit() {
    this.store.dispatch(new AuthActions.AutoLogin())
  }

  constructor(
    private ThemeSwitcherComponent:ThemeSwitcherComponent,
    private store: Store<fromApp.AppState>,
    swPush: SwPush,
    pushService: PushNotificationFromServerService
  ) {
    this.ThemeSwitcherComponent.setDefaultTheme()
    console.log(`inside AppComponent constructor`)
    if (swPush.isEnabled) {
      console.log(`swPush isEnabled`)

      swPush
        .requestSubscription({
          serverPublicKey: VAPID_PUBLIC,
        })
        .then((subscription) => {
          pushService.sendSubscriptionToTheServer(subscription).subscribe()
        })
        .catch(console.error)
    }
  }
}
