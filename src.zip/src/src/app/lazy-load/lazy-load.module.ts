import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes,RouterModule } from '@angular/router';
import { AuthGuard } from '../login/services/auth.gaurd';
import { environment } from '../../environments/environment'
const routes: Routes = [
    {path: 'auth', canActivate:[AuthGuard],loadChildren: '../auth/auth.module#AuthModule'},
    // {path: 'auth', loadChildren: '../auth/auth.module#AuthModule'},
    {path: 'login', loadChildren: '../login/login.module#LoginModule'},

    {path: '**', redirectTo: 'login'},
    // {path: '**', redirectTo: 'auth'},
]

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class LazyLoadModule { }
