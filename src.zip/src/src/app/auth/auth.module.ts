import { NgModule, APP_INITIALIZER } from '@angular/core'
import { CommonModule } from '@angular/common'
import { AuthComponent } from './auth.component'
import { RouterModule } from '@angular/router'
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar'
import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar'
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar'

import { appRoutes } from './lazyloader.routes'

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true,
}
import { CoreModule } from '../core/core.module'
import { MenuConfigService } from './auth.service'
// import { AuthService } from '../login/services/auth.service'
import { MaterialModule } from '../shared/material/material.module'

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(appRoutes),
    CoreModule,
    PerfectScrollbarModule,
    MaterialModule,
  ],
  declarations: [AuthComponent],
  providers: [
    MenuConfigService,
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG,
    },
  ],
})
export class AuthModule {
  constructor(
    private menuConfigService: MenuConfigService
  ) // private authService: AuthService
  {
    // console.log('auth.module constructor')
    // this.authService.user.subscribe((data) => {
    //   let role = data.role
    //   this.menuConfigService.loadMenuConfig(role)
    // })
  }
}
