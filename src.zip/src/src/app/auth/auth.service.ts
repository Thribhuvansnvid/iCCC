import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class MenuConfigService {
  public menuConfig;

  constructor(private http: HttpClient) { }

  loadMenuConfig(role) {
    console.log('menu-config')
    return this.http.get('/assets/config/menuConfig.json')
      .toPromise()
      .then(data => {
        this.menuConfig = data[role];
        console.log('auth service loadMenuConfig role : '+role)
      });
  }

  resetMenuConfig(){
    this.menuConfig = [];
  }

//   getConfig() {
//     return this.appConfig;
//   }
}