import { RouterModule, Routes } from '@angular/router'
import { AuthComponent } from './auth.component'

export const appRoutes: Routes = [
  {
    path: '',
    component: AuthComponent,
    children: [
      { path: 'alerts', loadChildren: '../alerts/alerts.module#AlertsModule' },
      {
        path: 'cg',
        loadChildren:
          '../citizen-grievances/citizen-grievances.module#CitizenGrievancesModule',
      },
      {
        path: 'emergency',
        loadChildren:
          '../emergency-system/emergency-system.module#EmergencySystemModule',
      },
      {
        path: "smartwater",
        loadChildren:
          "../smartcity-verticals/smartwaternew/smartwaternew.module#SmartwaternewModule",
      },
      {
        path: "rvm",
        loadChildren: "../smartcity-verticals/rvm/rvm.module#RvmModule",
      },
      {
        path: 'ews',
        loadChildren:
          '../ews/ews.module#EwsModule',
      },

      {
        path: 'dashboard',
        loadChildren: () =>
          import('../dashboard/dashboard-dynamic-widget.module').then(
            (m) => m.DashboardDynamicWidgetModule
          ),
      },
      // {
      //   path: 'atcs-cdac',
      //   loadChildren:
      //     '../atcs-cdac/atcs-cdac.module#AtcsCdacModule',
      // },

      {
        path: 'atcs-cdac',
        loadChildren: () =>
        import('../acts-cdac/atcs-cdac.module').then(
          (m) => m.AtcsCdacModule
        ),
      },


      {
        path: 'milestone',
        loadChildren:
          '../milestone-vms/milestone-vms.module#MilestoneVMSModule',
      },
      { path: 'sop', loadChildren: '../sop/sop.module#SOPModule' },

      {
        path: 'policies',
        loadChildren: '../policies/policies.module#PoliciesModule',
      },
      {
        path: 'settings',
        loadChildren: '../settings/settings.module#SettingsModule',
      },
      { path: 'user', loadChildren: '../users/users.module#UsersModule' },
      { path: 'sma', loadChildren: '../sma/sma.module#SmaModule' },

      {
        path: 'reports',
        loadChildren: '../reports/reports.module#ReportsModule',
      },
      // smartcity verticals
      {
        path: 'smartbin',
        loadChildren:
          '../smartcity-verticals/smartbin/smartbin.module#SmartBinModule',
      },
      {
        path: 'smartenv',
        loadChildren:
          '../smartcity-verticals/smartenv/smartenv.module#SmartEnvModule',
      },
      {
        path: 'smartenergy',
        loadChildren:
          '../smartcity-verticals/smartenergynew/smart-energy.module#SmartEnergyModule',
      },
      {
        path: 'smartparking',
        loadChildren:
          '../smartcity-verticals/smartparking/smartparking.module#SmartParkingModule',
      },
      {
        path: 'smartstreetlight',
        loadChildren:
          '../smartcity-verticals/smartstreetlight/smartstreetlight.module#SmartstreetlightModule',
      },
      // {
      //   path: 'vmd',
      //   loadChildren: '../smartcity-verticals/vmd/vmd.module#VmdModule',
      // },
      {
        path: 'smartvmd',
        loadChildren:
          '../smartcity-verticals/vmd-new/vmd-new.module#VmdNewModule',
      },
      {
        path: 'vms',
        loadChildren: '../smartcity-verticals/vms-va/vms-va.module#VmsVaModule',
      },
      {
        path: 'smartwater',
        loadChildren:
          '../smartcity-verticals/smartwater/smartwater.module#SmartWaterModule',
      },
      {
        path: 'atcsnew',
        loadChildren:
          '../smartcity-verticals/atcsnew/atcsnew.module#AtcsnewModule',
      },
      {
        path: 'smarttransportnew',
        loadChildren:
          '../smartcity-verticals/smarttransport_new/smarttransport.module#SmarttransportModule',
      },

      {
        path: 'itms',
        loadChildren:
          '../smartcity-verticals/itms-new/itms-new.module#ItmsNewModule',
      },
      {
        path: 'sensor-devices',
        loadChildren:
          '../sensor-devices/sensor-devices.module#SensorDevicesModule',
      },
      {
        path: 'mapview',
        loadChildren:
          '../smartcity-verticals/map-view/map-view.module#MapViewModule',
      },
      {
        path: 'floodmtrg',
        loadChildren:
          '../smartcity-verticals/waterresources/waterresources.module#WaterresourcesModule',
      },
      {
        path: 'services',
        loadChildren:
          '../smart-city-services/smart-city-services.module#SmartCityServicesModule',
      },
    ],
  },
]
