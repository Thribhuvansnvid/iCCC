import { Component, OnInit ,Input, ChangeDetectorRef} from '@angular/core';
import { MediaChange, MediaObserver } from '@angular/flex-layout';
import { ThemeSwitcherComponent } from '../shared/services/theme-switcher.service';




@Component({
  selector: 'app-auth',
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.scss']

})

export class AuthComponent implements OnInit{
  @Input() isVisible : boolean = true;
  visibility = 'shown';
  applicationTheme:string = ''

  sideNavOpened: boolean = true;
  matDrawerOpened: boolean = false;
  matDrawerShow: boolean = true;
  sideNavMode: string = 'side';

  ngOnChanges() {
   this.visibility = this.isVisible ? 'shown' : 'hidden';
  }

	constructor(private media: MediaObserver, private _themeSwitcherComponent:ThemeSwitcherComponent, private _cdr: ChangeDetectorRef) { }

	ngOnInit() {

    this._themeSwitcherComponent.appTheme.subscribe(theme=>{
      this.applicationTheme = theme
      // this._cdr.detectChanges();
      // console.log(this.applicationTheme)
    })
		this.media.asObservable().subscribe(() => {
            this.toggleView();
        });
	}
    getRouteAnimation(outlet) {

       return outlet.activatedRouteData.animation;
       //return outlet.isActivated ? outlet.activatedRoute : ''
    }

	toggleView() {
		if (this.media.isActive('gt-md')) {
            this.sideNavMode = 'side';
            this.sideNavOpened = true;
            this.matDrawerOpened = false;
            this.matDrawerShow = true;
        } else if(this.media.isActive('gt-xs')) {
            this.sideNavMode = 'side';
            this.sideNavOpened = false;
            this.matDrawerOpened = true;
            this.matDrawerShow = true;
        } else if (this.media.isActive('lt-sm')) {
            this.sideNavMode = 'over';
            this.sideNavOpened = false;
            this.matDrawerOpened = false;
            this.matDrawerShow = false;
        }
	}


}
