import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../environments/environment'

@Injectable()
export class AppConfigService {
  private serverConfig;

  constructor(private http: HttpClient) { }

  loadApiConfig() {
    let configPath = "";
    if(environment.production){
      configPath = '/assets/config/apiConfig.prod.json'

    } else{
      configPath = '/assets/config/apiConfig.json'
    }
    return this.http.get(configPath)
      .toPromise()
      .then(data => {
        this.serverConfig = data;

        if(this.serverConfig.production){
          console.log('app.config.service prod mode')
          ///console.log('app.config.service testapi'+this.serverConfig.test)
        }else{
          console.log('app.config.service dev mode')
          //console.log('app.config.service testapi'+this.serverConfig.test)
        }
      });
  }

  getConfig() {
    return this.serverConfig.apis;
  }

  getMenuConfig() {
    return this.serverConfig.menus.admin;
  }

  getSystemConfig() {
    return this.serverConfig.systemConfig;
  }

  getGisLoadUrl(){
    return this.serverConfig.apis.gis+'/'+this.serverConfig.apis.gisname;
  }
  getOpenGtsUrl()
  {
    return this.serverConfig.apis.opengtslogin+'';
  }

  getCityNames(){
    return this.serverConfig.cities.sort((a, b) => (a.city > b.city) ? 1 : -1);
  }


}
