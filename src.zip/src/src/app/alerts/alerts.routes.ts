import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AlertLayoutComponent } from "./alert-layout/alert-layout.component";
import { AlertListComponent } from "./alert-list/alert-list.component";
import { AlertMapComponent } from './alert-map/alert-map.component';

// const pagesRoutes: Routes = [

//     { path: '', component:  AlertListComponent },

// ];

const pagesRoutes: Routes = [
  {
    path: "",
    component: AlertLayoutComponent,

    children: [
      {
        path: "list",
        component: AlertListComponent,
      },
      {
        path: "map",
        component: AlertMapComponent,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(pagesRoutes)],
  exports: [RouterModule],
})
export class AlertsRoutes {}
