import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-alert-layout',
  templateUrl: './alert-layout.component.html',
  styleUrls: ['./alert-layout.component.scss']
})
export class AlertLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
