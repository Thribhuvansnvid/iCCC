import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AlertNavbarComponent } from './alert-navbar.component';

describe('AlertNavbarComponent', () => {
  let component: AlertNavbarComponent;
  let fixture: ComponentFixture<AlertNavbarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AlertNavbarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AlertNavbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
