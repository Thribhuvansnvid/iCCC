import { Component, DoCheck, OnInit, ViewChild } from '@angular/core'
import { AlertService } from '../services/alerts.service'
import { MatPaginator } from '@angular/material'
import { tap } from 'rxjs/operators'
import { Router } from '@angular/router'
import { AppConfigService } from 'src/app/shared/configs-loader/app.config.service'
import * as AlertsActions from '../store/alerts.actions'
import { Store } from '@ngrx/store'
import * as fromApp from '../../store/app.reducer'
import * as moment from 'moment'

@Component({
  selector: 'alert-navbar',
  templateUrl: './alert-navbar.component.html',
  styleUrls: ['./alert-navbar.component.scss'],
})
export class AlertNavbarComponent implements OnInit {
  cityName = 'Saharanpur'
  stateName = 'Uttar Pardesh'

  // @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  showSideNavIcon = false
  sideNavStatus = true
  timespanSelected: string = 'Live'
  timespans: string[] = [
    'Live',
    'Last 24 Hours',
    'Last 2 Days',
    'Last 3 days',
    'Date Range',
  ]

  alertTypeSelected: string = 'All'

  // alertTypesList: string[] = ["All", "ITMS", "SVL", "FRS", "SWM", "Parking"];
  alertTypesList: string[] = []

  severitySelected: string = 'All'
  severityList: string[] = ['All', 'High', 'Low', 'Medium']

  verticleSelected = 'All'
  alertTypes: any = []
  // alertTypes = {
  //   ITMS: [
  //     "Blacklisted",
  //     "Stolen",
  //     "helmet_violation",
  //     "rl_violation",
  //     "stopline_violation",
  //     "triple_ride_violation",
  //   ],
  //   Surveillance: [
  //     "CrowdDetection",
  //     "FallDetection",
  //     "IntrusionDetection",
  //     "Loitering",
  //     "ObjectRemovalDetection",
  //   ],
  //   FRS: ["FaceRecognition"],
  //   SWM: ["GarbageLitterDetection"],
  //   Parking: ["ParkingViolation"],
  // };

  constructor(
    public alertService: AlertService,
    private router: Router,
    private _configs: AppConfigService,
    private store: Store<fromApp.AppState>
  ) {}

  ngOnInit() {
    if (this.router.url.includes('list')) {
      this.showSideNavIcon = false
    } else {
      this.showSideNavIcon = true
    }

    this.alertService
      .getEventTypes()
      .then((data: any) => {
        this.alertTypesList = data.map((item) => item.eventType)
        this.alertTypes = data
      })
      .catch((err) => {
        console.log(err)
      })

    this.loadAlertsList()
  }

  loadAlertsList() {
    const fromDate = '2020-02-25 00:10:00'
    const toDate = moment().format('YYYY-MM-DD HH:mm:ss')

    this.store.dispatch(
      new AlertsActions.AlertsFetchStart({
        state_name: this.stateName,
        district_city: this.cityName,
        smartvertical: this.verticleSelected,
        // eventtype: this.alertTypeSelected,
        severity: this.severitySelected,
        verticleSelected: this.verticleSelected,
        event_type: this.alertTypeSelected,
        from_date: fromDate,
        to_date: toDate,

        page_index: 1,
        no_of_records: 50,
      })
    )
  }

  timeSpanSelector() {
    this.loadAlertsList()
  }

  verticleSelector() {
    this.alertTypeSelected = 'All'
    this.loadAlertsList()
  }

  alertTypeSelector() {
    this.loadAlertsList()
  }

  severitySelector() {
    this.loadAlertsList()
  }

  getAlertTypes() {
    if (this.alertTypes.length > 0) {
      const val = this.alertTypes.find(
        (item) => item.eventType == this.verticleSelected
      ).eventSubType
      // console.log(val)
      return val
    }
    // console.log(this.alertTypes[this.verticleSelected])
    // return this.alertTypes[this.verticleSelected]
  }

  ngAfterViewInit() {}

  onSelectionMenubtn() {
    this.sideNavStatus = !this.sideNavStatus
    this.alertService.sidenavListOpen.next(this.sideNavStatus)
  }

  getCityNames() {
    return this._configs.getCityNames()
  }

  notifyCitySelection(city: string) {
    this.verticleSelected = 'All'
    this.alertTypeSelected = 'All'
    this.severitySelected = 'All'

    this.cityName = city
    this.stateName = this._configs
      .getCityNames()
      .find((item) => item.city == city).state

    this.loadAlertsList()
  }
}
