import { Component, OnInit, ViewChild } from '@angular/core';
import { Subscription } from 'rxjs';
import { Store } from '@ngrx/store';
import * as fromApp from '../../store/app.reducer'
import { AlertListFilters } from '../models/alerts.list.filetr';
import { MatPaginator } from '@angular/material';
import { tap } from 'rxjs/operators';
import * as AlertsActions from '../store/alerts.actions'


@Component({
  selector: 'alert-footer',
  templateUrl: './alert-footer.component.html',
  styleUrls: ['./alert-footer.component.scss']
})
export class AlertFooterComponent implements OnInit {
  private storeSub: Subscription
  constructor(private store: Store<fromApp.AppState>) { }
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator
  
  totalAlerts:number = 0;
  filters: AlertListFilters = null;

  ngOnInit() {
    this.storeSub = this.store.select('alert').subscribe((alertsState) => {
      this.totalAlerts = alertsState.totalAlerts
      this.filters = alertsState.filters
    })
  }

  ngAfterViewInit() {
    this.paginator.page
      .pipe(
        tap(() => {
           this.store.dispatch(
            new AlertsActions.AlertsFetchStart({
              ...this.filters,      
              page_index:  this.paginator.pageIndex + 1,
              no_of_records: this.paginator.pageSize,
            })
          )

        })
      )
      .subscribe()
  }

  ngOnDestroy() {

    if (this.storeSub) {
      this.storeSub.unsubscribe()
    }
  }

}
