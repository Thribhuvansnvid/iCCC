import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog'
import { Component, Inject } from '@angular/core'
import { FormControl, Validators } from '@angular/forms'
import { MatCarousel, MatCarouselComponent } from '@ngmodule/material-carousel'

@Component({
  selector: 'app-add.dialog',
  templateUrl: '../../dialogs/view-visual-info/view-visual-info.dialog.html',
  styleUrls: ['../../dialogs/view-visual-info/view-visual-info.dialog.scss'],
})
export class ViewVisualInfoDialogComponent {
  images: string[] = []

  slides: any[] = []

  videoSlides: any[] = []
  videoUrls: string[] = []
  constructor(
    public dialogRef: MatDialogRef<ViewVisualInfoDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.images =
      data.alert.eventtype == 'helmet_violation'
        ? ['/assets/images/itms/helmet-violation.jpg']
        : data.alert.visualinfo.imageUrl[0].split(',')

    this.videoUrls = data.alert.visualinfo.videoUrl

    // this.images = data.alert.visualinfo.imageUrl[0].split(',');
    // this.videoUrls = data.alert.visualinfo.videoUrl;

    // console.log(data.alert.visualinfo.videoUrl[0])
    // this.slides = [
    //   {'image': 'https://m.economictimes.com/thumb/msid-72217766,width-1200,height-900,resizemode-4,imgsize-297490/airbin-main.jpg'},
    //   {'image': 'https://m.economictimes.com/thumb/msid-72217766,width-1200,height-900,resizemode-4,imgsize-297490/airbin-main.jpg'},
    //   {'image': 'https://m.economictimes.com/thumb/msid-72217766,width-1200,height-900,resizemode-4,imgsize-297490/airbin-main.jpg'},
    //   {'image': 'https://m.economictimes.com/thumb/msid-72217766,width-1200,height-900,resizemode-4,imgsize-297490/airbin-main.jpg'},
    //   {'image': 'https://m.economictimes.com/thumb/msid-72217766,width-1200,height-900,resizemode-4,imgsize-297490/airbin-main.jpg'},
    //   {'image': 'https://m.economictimes.com/thumb/msid-72217766,width-1200,height-900,resizemode-4,imgsize-297490/airbin-main.jpg'},
    // ]

    // this.imgaes.push('https://m.economictimes.com/thumb/msid-72217766,width-1200,height-900,resizemode-4,imgsize-297490/airbin-main.jpg')
    // this.imgaes.push('https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.factchecker.in%2Ftraffic-violations-caused-323-deaths-every-day-in-2017-yet-fines-alone-not-a-solution%2F&psig=AOvVaw0wWqpsj40rfvyJh7Iw4Zta&ust=1601191832371000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCPCLnMGnhuwCFQAAAAAdAAAAABAO')
    // this.imgaes.push('https://www.google.com/url?sa=i&url=https%3A%2F%2Fnewsable.asianetnews.com%2Fsouth%2Ftraffic-rules-violation-in-bengaluru&psig=AOvVaw0wWqpsj40rfvyJh7Iw4Zta&ust=1601191832371000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCPCLnMGnhuwCFQAAAAAdAAAAABAU')
    // this.imgaes.push('https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.businesstoday.in%2Fcurrent%2Feconomy-politics%2Frajya-sabha-clears-motor-vehicles-bill-stricter-penalties-for-traffic-violation%2Fstory%2F369604.html&psig=AOvVaw0wWqpsj40rfvyJh7Iw4Zta&ust=1601191832371000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCPCLnMGnhuwCFQAAAAAdAAAAABAZ')
    // this.imgaes.push('https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.telegraphindia.com%2Fjharkhand%2Ftraffic-law-quandary-for-bikes-scooters%2Fcid%2F1702626&psig=AOvVaw0wWqpsj40rfvyJh7Iw4Zta&ust=1601191832371000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCPCLnMGnhuwCFQAAAAAdAAAAABAe')

    // console.log(data.visualinfo.imageUrl)
  }

  formControl = new FormControl('', [
    Validators.required,
    // Validators.email,
  ])

  getErrorMessage() {
    return this.formControl.hasError('required')
      ? 'Required field'
      : this.formControl.hasError('email')
      ? 'Not a valid email'
      : ''
  }

  submit() {
    // emppty stuff
  }

  onNoClick(): void {
    this.dialogRef.close()
  }

  getEventTypes(items) {
    return items.split(',')
  }
}
