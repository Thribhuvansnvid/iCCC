import { Component, OnInit } from '@angular/core'
import { AppConfigService } from 'src/app/shared/configs-loader/app.config.service'

@Component({
  selector: 'app-alert-map',
  templateUrl: './alert-map.component.html',
  styleUrls: ['./alert-map.component.scss'],
})
export class AlertMapComponent implements OnInit {
  public gisUrl = ''

  showSideNavContainer = true
  opened = true

  constructor(private configs: AppConfigService) {
    this.gisUrl =
      this.configs.getConfig().API_BASE_URL + '/gis/arcgis?service=SmartSWM+login=swm'

    console.log(this.gisUrl)
  }

  ngOnInit() {}

  iframeLoadEvent() {}
}
