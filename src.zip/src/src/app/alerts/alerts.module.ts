import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { HttpClientModule } from '@angular/common/http';
import { AlertsRoutes } from './alerts.routes';
import { AlertService } from './services/alerts.service';
import { AlertListComponent } from './alert-list/alert-list.component';
import { SharedModule } from '../shared/shared.module';
import { SOPModule } from '../sop/sop.module';
import { MaterialModule } from '../shared/material/material.module';
import { ViewVisualInfoDialogComponent } from './dialogs/view-visual-info/view-visual-info.dialog.component';

import { MatVideoModule } from 'mat-video';
import { MatCarouselModule } from '@ngmodule/material-carousel';
import { AlertLayoutComponent } from './alert-layout/alert-layout.component';
import { AlertNavbarComponent } from './alert-navbar/alert-navbar.component';
import { AlertMapComponent } from './alert-map/alert-map.component';
import { AlertSideNavComponent } from './alert-side-nav/alert-side-nav.component';
import { AlertFooterComponent } from './alert-footer/alert-footer.component';

@NgModule({
	imports: [
		CommonModule,		
		FormsModule,		
		ReactiveFormsModule,
		HttpClientModule,
		FlexLayoutModule,
		AlertsRoutes,
		MaterialModule,
		SharedModule,
		SOPModule,
		MatVideoModule,
		MatCarouselModule.forRoot(),
		
	],
	declarations: [
		AlertListComponent,
		ViewVisualInfoDialogComponent,
		AlertLayoutComponent,
		AlertNavbarComponent,
		AlertMapComponent,
		AlertSideNavComponent,
		AlertFooterComponent
	],
		
	providers: [
		AlertService
	],
	entryComponents: [	
		ViewVisualInfoDialogComponent
	  ],
})
export class AlertsModule { }
