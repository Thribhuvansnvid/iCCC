import { Action } from '@ngrx/store'
import { AlertListFilters } from '../models/alerts.list.filetr'

export const ALERTS_FETCH_START = '[Alerts] Fetch Start'
export const ALERTS_FETCH_SUCCESS = '[Alerts] Fetched'
export const ALERTS_FETCH_FAIL = '[Alerts] Fetch Fail'
export const ALERTS_LIST_PAGINATION = '[Alerts] List Pagination'


export const SIGNUP_START = '[Alerts] Signup Start'
export const CLEAR_ERROR = '[Alerts] Clear Error'
export const AUTO_LOGIN = '[Alerts] Auto Login'
export const LOGOUT = '[Alerts] Logout'

export class AlertsFetchSuccess implements Action {
  readonly type = ALERTS_FETCH_SUCCESS

  constructor(public payload: { alerts: any; totalAlerts: number }) {}
}

export class AlertsFetchStart implements Action {
  readonly type = ALERTS_FETCH_START

  constructor(
    public payload: {
      state_name: string
      district_city: string
      page_index: number
      no_of_records: number
      smartvertical: string
      // eventtype: string
      severity: string
      verticleSelected: string
      event_type: string
      from_date: string
      to_date: string
    }
  ) {}
}


export class AlertsFetchFail implements Action {
  readonly type = ALERTS_FETCH_FAIL

  constructor(public payload: string) {}
}

export type AlertsActions =
  | AlertsFetchSuccess
  | AlertsFetchStart
  | AlertsFetchFail
  
