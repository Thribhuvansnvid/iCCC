import { AlertListFilters } from '../models/alerts.list.filetr'
import * as AlertsActions from './alerts.actions'

export interface State {
  alerts: any
  totalAlerts: number
  authError: string
  loading: boolean
  filters: AlertListFilters
}

const initialState: State = {
  alerts: null,
  totalAlerts: 0,
  authError: null,
  loading: false,
  filters: null,
}

export function alertsReducer(
  state = initialState,
  action: AlertsActions.AlertsActions
) {
  switch (action.type) {
    case AlertsActions.ALERTS_FETCH_SUCCESS: {
      const alerts = action.payload.alerts
      const totalAlerts = action.payload.totalAlerts

      return {
        ...state,
        authError: null,
        totalAlerts: totalAlerts,
        alerts: alerts,
        loading: false,
      }
    }

    case AlertsActions.ALERTS_FETCH_START: {
      const filters = new AlertListFilters(
        action.payload.state_name,
        action.payload.district_city,
        action.payload.page_index,
        action.payload.no_of_records,
        action.payload.smartvertical,
        // action.payload.eventtype,
        action.payload.severity,
        action.payload.verticleSelected,
        action.payload.event_type,
        action.payload.from_date,
        action.payload.to_date
      )

      return {
        ...state,
        authError: null,
        loading: true,
        alerts: null,
        totalAlerts: 0,
        filters: filters,
      }
    }

    case AlertsActions.ALERTS_FETCH_FAIL: {
      return {
        ...state,
        alerts: null,
        authError: action.payload,
        loading: false,
        totalAlerts: 0,
      }
    }

    default: {
      return state
    }
  }
}
