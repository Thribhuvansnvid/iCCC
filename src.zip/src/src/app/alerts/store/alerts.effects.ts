import { Injectable, SkipSelf } from '@angular/core'
import { Actions, ofType, Effect } from '@ngrx/effects'
import { switchMap, catchError, map, tap } from 'rxjs/operators'
import { of } from 'rxjs'
import { HttpClient } from '@angular/common/http'
import * as AlertsActions from './alerts.actions'
import { AppConfigService } from 'src/app/shared/configs-loader/app.config.service'

@Injectable()
export class AlertsEffects {
  @Effect()
  authLogin = this.actions$.pipe(
    ofType(AlertsActions.ALERTS_FETCH_START),
    switchMap((alertsData: AlertsActions.AlertsFetchStart) => {
      const BASE_URL = this.appConfigService.getConfig().eventsUrl

      const endpoint = `${BASE_URL}/filteralerts`

      const params = {
        state_name: alertsData.payload.state_name,
        district_city: alertsData.payload.district_city,
        page_index: alertsData.payload.page_index,
        no_of_records: 50,
        smartvertical:
          alertsData.payload.verticleSelected != 'All'
            ? alertsData.payload.verticleSelected
            : null,
        eventtype:
          alertsData.payload.event_type != 'All'
            ? alertsData.payload.event_type
            : null,
        severity:
          alertsData.payload.severity != 'All'
            ? alertsData.payload.severity
            : null,
      }

      return this.http.post<any>(endpoint, params).pipe(
        map((resData) => {
          const totalCount = resData.totalcount
          let alertList = null
          if (totalCount > 0) {
            alertList = resData.alerts
            alertList.map((obj) => ({ ...obj, showSopStatus: 'false' }))
          }
          return new AlertsActions.AlertsFetchSuccess({
            alerts: alertList,
            totalAlerts: totalCount,
          })
        }),
        catchError((errorRes) => {
          return of(new AlertsActions.AlertsFetchFail(errorRes.console.error))
        })
      )
    })
  )

  constructor(
    private actions$: Actions,
    private http: HttpClient,
    private appConfigService: AppConfigService
  ) {}
}
