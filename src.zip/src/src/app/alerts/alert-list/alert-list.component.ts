import { Component, OnInit, OnDestroy, AfterViewInit } from '@angular/core'
import { BreakpointObserver, BreakpointState } from '@angular/cdk/layout'
import { MatDialog, MatPaginator } from '@angular/material'
import { AlertService } from '../services/alerts.service'
import { Subscription } from 'rxjs'
import { Alert } from '../models/alerts.model'
import { ServerNotificationService } from '../../shared/services/server.notification.service'
import { ViewVisualInfoDialogComponent } from '../dialogs/view-visual-info/view-visual-info.dialog.component'
import { Router } from '@angular/router'
import { Store } from '@ngrx/store'
import * as fromApp from '../../store/app.reducer'
import { AlertListFilters } from '../models/alerts.list.filetr'

@Component({
  selector: 'alert-list',
  templateUrl: './alert-list.component.html',
  styleUrls: ['./alert-list.component.scss'],
})
export class AlertListComponent implements OnInit, OnDestroy, AfterViewInit {
  panelOpenState = false

  subscriptionGetAlerts: Subscription
  subscriptionWebsocket: Subscription
  subscriptionOnSelectionChange: Subscription

  cityName = 'Saharanpur'
  stateName = 'Uttar Pardesh'
  totalAlerts = 0
  loading = true
  alerts: any
  filters: AlertListFilters = null
  alertList: Alert[] = []
  tableRefreshTimer: any

  value = ''
  mini = true
  mobileView = false
  private storeSub: Subscription

  constructor(
    public alertService: AlertService,
    private serverNotificationService: ServerNotificationService,
    public dialog: MatDialog,
    private router: Router,
    private store: Store<fromApp.AppState>,
    private _breakpointObserver: BreakpointObserver
  ) {}

  ngOnInit() {
    // console.log(this.router.url);
    if (this.router.url.includes('list')) {
      this.mini = false
    }

    this.subscriptionWebsocket = this.serverNotificationService.onWebSocketAlertRcvd.subscribe(
      (alert) => {
        this.loadAlertsList()
      }
    )

    this.storeSub = this.store.select('alert').subscribe((alertsState) => {
      this.totalAlerts = alertsState.totalAlerts
      this.loading = alertsState.loading
      this.alerts = alertsState.alerts
      this.filters = alertsState.filters
    })

    this.mediaQuery()
  }

  mediaQuery() {
    this._breakpointObserver
      .observe(['(min-width: 1000px)'])
      .subscribe((state: BreakpointState) => {
        if (state.matches) {
          this.mobileView = true
        } else {
          this.mobileView = false
        }
      })
  }

  ngAfterViewInit() {}

  ngOnDestroy() {
    if (this.tableRefreshTimer) {
      clearInterval(this.tableRefreshTimer)
    }
    if (this.subscriptionWebsocket) {
      this.subscriptionWebsocket.unsubscribe()
    }
  }

  refreshTableAfterSetInterval() {
    this.tableRefreshTimer = setInterval(() => {
      this.loadAlertsList()
    }, this.alertService.polling_interval)
  }

  loadAlertsList() {}

  startSop(item: any) {}

  showMedia(alert) {
    // const imageUrlArray = imageUrl.split(',')
    const dialogRef = this.dialog.open(ViewVisualInfoDialogComponent, {
      data: { alert: alert },
    })

    dialogRef.afterClosed().subscribe((result) => {
      if (result === 1) {
      }
    })
  }

  getEventTypes(items) {
    return items.split(',')
  }
}
