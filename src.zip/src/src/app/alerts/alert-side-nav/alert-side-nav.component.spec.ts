import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AlertSideNavComponent } from './alert-side-nav.component';

describe('AlertSideNavComponent', () => {
  let component: AlertSideNavComponent;
  let fixture: ComponentFixture<AlertSideNavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AlertSideNavComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AlertSideNavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
