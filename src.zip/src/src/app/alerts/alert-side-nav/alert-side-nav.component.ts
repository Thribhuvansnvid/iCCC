import { Component, OnInit } from '@angular/core';
import { AlertService } from '../services/alerts.service';

@Component({
  selector: 'alert-side-nav',
  templateUrl: './alert-side-nav.component.html',
  styleUrls: ['./alert-side-nav.component.scss']
})
export class AlertSideNavComponent implements OnInit {

  showSideNavContainer = true;
  opened = true;

  constructor(public alertService:AlertService) { }

  ngOnInit() {
    this.alertService.sidenavListOpen.subscribe(data=>{
      this.showSideNavContainer = data;
    })
  }

}
