export class AlertListFilters {
  // //   user_id: string = null;
  // state_name: string = null
  // district_city: string = null
  // page_index: number = null
  // no_of_records: number = null
  // smartvertical: string = null
  // eventtype: string = null
  // severity: string = null
  // // searchBy?:string;
  // //   alert_status: string = null;
  // verticleSelected: string = null
  // event_type: string = null
  // //   severity: string = null;
  // //   patient_id: number = null;
  // //   patient_name: string = null;
  // from_date: string = null
  // to_date: string = null

  constructor(
    public state_name: string,
    public district_city: string,
    public page_index: number,
    public no_of_records: number,
    public smartvertical: string,
    // public eventtype: string,
    public severity: string,
    public verticleSelected: string,
    public event_type: string,
    public from_date: string,
    public to_date: string
  ) {}
}

// "state_name" : "all" ,
// "district_city" : "all" ,
// "page_index" : params.page_index,
// "no_of_records" : 50,
// // "smartvertical" : params.verticleSelected ,
// "smartvertical": params.verticleSelected != 'All'?params.verticleSelected:null,
// "eventtype": params.event_type != 'All'?params.event_type:null,
// "severity": params.severity != 'All'?params.severity:null
// // "verticleSelected": params.verticleSelected,
// // "eventtype": params.event_type,

// //**************************************************** */
// // fromDate: "2020-02-25 00:10:00",
// // toDate: "2020-07-12 00:13:00",
// // eventType: "All",
// // severity: "All"
