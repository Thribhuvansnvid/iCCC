export class Alert{
    
    alert_id:number;
    patient_id:number;
    patient_name:string;
    device_id:string;
    event_time:string;
    event_type:string;
    severity:string;
    alert_status:string;
    remarks:string;
    eventdetails:Array<AlertDetails>;

    // name:string;
    // details:string;
    // dateTime:string;
    // priority:string;
}

export class AlertDetails{
    name:string;
    value:string;
}