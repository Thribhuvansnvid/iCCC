import { Injectable } from '@angular/core';
import {
  HttpInterceptor,
  HttpRequest,
  HttpHandler,
  HttpParams,
  HttpResponse
} from '@angular/common/http';
//import { HttpInterceptor, HttpRequest, HttpHandler, HttpResponse } from '@angular/common/http';
import { finalize, tap } from 'rxjs/operators';


import { take, exhaustMap } from 'rxjs/operators';

import { AuthService } from './login/services/auth.service';

@Injectable()

export class AuthInterceptorService implements HttpInterceptor {
  constructor(private authService: AuthService) {}

  intercept(req: HttpRequest<any>, next: HttpHandler) {
    return this.authService.user.pipe(
      take(1),
      exhaustMap(user => {
        if(req.url.includes('/api/complaint/')){
          console.log(`interceptor complaint apis --> ${req.url}`)
        }
        
        if (!user) {
          return next.handle(req);
        }

        const modifiedReq = req.clone({
          params: new HttpParams().set('authorization', user.token)
        });
        return next.handle(modifiedReq);
      })
    );
  }

  // intercept(req: HttpRequest<any>, next: HttpHandler) {
  //   const startTime = Date.now();
  //   let status: string;

  //   return next.handle(req).pipe(
  //       tap( event => {
  //           status = '';
  //           if (event instanceof HttpResponse) {
  //             status = 'succeeded';
  //           }
  //         },
  //         error => status = 'failed'
  //       ),
  //       finalize(() => {
  //         const elapsedTime = Date.now() - startTime;
  //         const message = req.method + " " + req.urlWithParams +" "+ status
  //         + " in " + elapsedTime + "ms";

  //         this.logDetails(message);
  //       })
  //   );
  // }
  private logDetails(msg: string) {
    console.log(`app interceptor --> ${msg}`);
  }

}
