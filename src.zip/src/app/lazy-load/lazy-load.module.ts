import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { SmartTransportServerSideReportComponent } from "../serverSideReports/smart-transport-server-side-report/smart-transport-server-side-report.component";
const routes: Routes = [
  // {
  //   path: "SSR/transport/:fromDate/:toDate",
  //   component: SmartTransportServerSideReportComponent,
  // },
  {
    path: "smartcity",
    loadChildren: () =>
      import(`../SmartTransportRreports/smartTransportReport.module`).then(
        (m) => m.SmartTransportModule
      ),
  },

  //   {
  //     path: "transport",
  //     loadChildren:
  //       "../SmartTransportRreports/smartTransportModule.module#SmartTransportModule",
  //   },
  // {path: '**', redirectTo: 'login'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class LazyLoadModule {}
