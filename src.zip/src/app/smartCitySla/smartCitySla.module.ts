import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { SmartTransportComponent } from './smart-transport/smart-transport.component';
import { DoughnutChartComponent } from './doughnut-chart/doughnut-chart.component';
import { MaterialModule } from '../shared/material.module';
import { SmartTransportHeaderComponent } from './smart-transport-header/smart-transport-header.component';
import { SmartCitySlaRoutes } from "./smartCitySla.routes";
import { SwmSlaComponent } from './swm-sla/swm-sla.component';
import { SlaDashboardComponent } from "./sla-dashboard/sla-dashboard.component";
import { FlexLayoutModule } from "@angular/flex-layout";
import { NgApexchartsModule } from "ng-apexcharts";
import { SlaCardComponentComponent } from "./sla-card-component/sla-card-component.component";
import { SlaSwmTimechatComponent } from "./sla-swm-timechat/sla-swm-timechat.component";
import { SwmBillReportComponent } from "./swm-bill-report/swm-bill-report.component";


@NgModule({
  imports: [
    CommonModule, 
    FormsModule, 
    ReactiveFormsModule, 
    HttpClientModule, 
    SmartCitySlaRoutes, 
    MaterialModule, 
    FlexLayoutModule,
    NgApexchartsModule
  ],
  declarations: [
    SmartTransportComponent,
     DoughnutChartComponent, 
     SmartTransportHeaderComponent, 
     SwmSlaComponent, 
     SlaDashboardComponent,
     SlaCardComponentComponent,
     SlaSwmTimechatComponent,
     SwmBillReportComponent
    ],

  providers: [],
  entryComponents: [],
  exports: [SmartTransportComponent]
})
export class SmartCitySlaModule { }
