import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';

// import {
//   ApexNonAxisChartSeries,
//   ApexPlotOptions,
//   ApexChart,
//   ChartComponent
// } from "ng-apexcharts";

// export type ChartOptions = {
//   series: ApexNonAxisChartSeries;
//   chart: ApexChart;
//   labels: string[];
//   plotOptions: ApexPlotOptions;
// };

import {
  ApexNonAxisChartSeries,
  ApexPlotOptions,
  ApexChart,
  ApexFill,
  ChartComponent,
  ApexStroke,
  ApexGrid
} from "ng-apexcharts";
import { SLADataService } from '../services/sla.data.service';

export type ChartOptions = {
  series: ApexNonAxisChartSeries;
  chart: ApexChart;
  labels: string[];
  plotOptions: ApexPlotOptions;
  fill: ApexFill;
  stroke: ApexStroke;
  grid:ApexGrid
};

@Component({
  selector: 'app-swm-sla',
  templateUrl: './swm-sla.component.html',
  styleUrls: ['./swm-sla.component.scss']
})
export class SwmSlaComponent implements OnInit {

  slaData:any = null;

  rfid:any = null;
  rfidTimeSeriesData:any = null;

  gps:any = null;
  gpsTimeSeriesData:any = null;

  weightSensors:any = null;
  weightSensorsTimeSeriesData:any = null;

  swmApplication:any = null;
  swmApplicationTimeSeriesData:any = null;


  @ViewChild("chart",{static: true}) chart: ChartComponent;
  public chartOptions: Partial<ChartOptions>;

  constructor(private _slaDataService: SLADataService, private router: Router) {
    // this.chartOptions = {
    //   series: [70],
    //   chart: {
    //     height: 150,
    //     type: "radialBar"
    //   },
    //   grid: {
    //     borderColor: '#EE6161',
    //     padding: {
    //       top: 0,
    //       right: 0,
    //       bottom: 0,
    //       left: 0,
    //     },
    //   },
    //   plotOptions: {
    //     radialBar: {
    //       hollow: {
    //         size: "60%"
    //       }
    //     }
    //   },
    //   labels: ["Cricket"]
    // };
  }

  // @ViewChild("chart",{static: true}) chart: ChartComponent;
  // public chartOptions: Partial<ChartOptions>;

  // constructor() {
  //   this.chartOptions = {
  //     series: [67],
  //     chart: {
  //       height: 200,
  //       type: "radialBar",
  //       offsetY: -10
  //     },
  //     plotOptions: {
  //       radialBar: {
  //         startAngle: -135,
  //         endAngle: 135,
  //         dataLabels: {
  //           name: {
  //             fontSize: "16px",
  //             color: undefined,
  //             offsetY: 120
  //           },
  //           value: {
  //             offsetY: 76,
  //             fontSize: "22px",
  //             color: undefined,
  //             formatter: function(val) {
  //               return val + "%";
  //             }
  //           }
  //         }
  //       }
  //     },
  //     fill: {
  //       type: "gradient",
  //       gradient: {
  //         shade: "dark",
  //         shadeIntensity: 0.15,
  //         inverseColors: false,
  //         opacityFrom: 1,
  //         opacityTo: 1,
  //         stops: [0, 50, 65, 91]
  //       }
  //     },
  //     stroke: {
  //       dashArray: 4
  //     },
  //     labels: ["Median Ratio"]
  //   };
  // }

  ngOnInit() {
    this._slaDataService.getSlaData('swm').then(data=>{
      this.slaData = data;
      this.rfid = this.slaData.filter(item=>item.subVertical === 'RFID')[0]
      this.gps = this.slaData.filter(item=>item.subVertical === 'GPS')[0]
      this.weightSensors = this.slaData.filter(item=>item.subVertical === 'WEIGHT SENSORS')[0]
      this.swmApplication = this.slaData.filter(item=>item.subVertical === 'SWM APPLICATION')[0]

      this.rfidTimeSeriesData = this.slaData.filter(item=>item.subVertical === 'RFID')[0].timeSeriesData
      this.gpsTimeSeriesData = this.slaData.filter(item=>item.subVertical === 'GPS')[0].timeSeriesData
      this.weightSensorsTimeSeriesData = this.slaData.filter(item=>item.subVertical === 'WEIGHT SENSORS')[0].timeSeriesData
      this.swmApplicationTimeSeriesData = this.slaData.filter(item=>item.subVertical === 'SWM APPLICATION')[0].timeSeriesData

    }).catch(err=>{
      console.log(err)
    });
  }

  onClickPrint(){
    this._slaDataService.passDataForPrinting.next(this.slaData);
    // [routerLink]="'/smartcity/sla/swm/report'"
    this.router.navigate(['/smartcity/sla/swm/report']);
  }

}
