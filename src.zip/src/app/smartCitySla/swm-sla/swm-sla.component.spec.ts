import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SwmSlaComponent } from './swm-sla.component';

describe('SwmSlaComponent', () => {
  let component: SwmSlaComponent;
  let fixture: ComponentFixture<SwmSlaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SwmSlaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SwmSlaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
