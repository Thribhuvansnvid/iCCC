import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SlaSwmTimechatComponent } from './sla-swm-timechat.component';

describe('SlaSwmTimechatComponent', () => {
  let component: SlaSwmTimechatComponent;
  let fixture: ComponentFixture<SlaSwmTimechatComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SlaSwmTimechatComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SlaSwmTimechatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
