import { Component, Input, OnInit, ViewChild } from "@angular/core";
import {
  ApexAxisChartSeries,
  ApexChart,
  ChartComponent,
  ApexDataLabels,
  ApexPlotOptions,
  ApexYAxis,
  ApexLegend,
  ApexStroke,
  ApexXAxis,
  ApexFill,
  ApexTooltip,
  ApexTheme,
  ApexTitleSubtitle,
  ApexGrid
} from "ng-apexcharts";

export type ChartOptions = {
  series: ApexAxisChartSeries;
  chart: ApexChart;
  dataLabels: ApexDataLabels;
  plotOptions: ApexPlotOptions;
  yaxis: ApexYAxis;
  xaxis: ApexXAxis;
  fill: ApexFill;
  tooltip: ApexTooltip;
  stroke: ApexStroke;
  legend: ApexLegend;
  theme: ApexTheme;
  title: ApexTitleSubtitle;
  grid: ApexGrid
};

@Component({
  selector: 'sla-swm-timechat',
  templateUrl: './sla-swm-timechat.component.html',
  styleUrls: ['./sla-swm-timechat.component.scss']
})
export class SlaSwmTimechatComponent implements OnInit {

  @Input() slaTimeSeriesData: any;
  @Input() chartname: string;

  @ViewChild("chart", { static: true }) chart: ChartComponent;
  public chartOptions: Partial<ChartOptions>;

  ngOnInit() {
    this.initiateChart()
  }


  constructor() {

  }

  initiateChart(){
    this.chartOptions = {
      series: [
        {
          name: "Total Time",
          // data: [10, 10, 10, 10]
          data: this.slaTimeSeriesData.totalTimeHrsArray
        },
        {
          name: "Total Up Time",
          // data: [106, 41, 36, 26]
          data: this.slaTimeSeriesData.totalUpTimeHrsArray

        },
        {
          name: "Down Time",
          // data: [109, 85, 101, 98]
          data: this.slaTimeSeriesData.totalDownTimeHrsArray

        },
        {
          name: "Maintenance Time",
          // data: [115, 41, 36, 26]
          data: this.slaTimeSeriesData.totalMaintenanceTimeHrsArray

        },

      ],
      legend: {
        fontSize: '10px',
        fontWeight: 400,
        position: 'bottom',
        horizontalAlign: 'center',
      },
      // grid: {
      //   row: {
      //     colors: undefined,
      //     opacity: 0.5
      //   },
      //   // yaxis: {
      //   //   lines: {
      //   //     show: false
      //   //   }
      //   // },
      //   padding: {
      //     top: 0,
      //     right: 0,
      //     bottom: 0,
      //     left: 0,
      //   },
      // },
      title: {
        text: `${this.chartname} Week wise Data`,
        align: 'center',
        margin: 10,
        offsetX: 0,
        offsetY: 0,
        floating: false,
        style: {
          fontSize: '12px',
          fontWeight: '500',
          fontFamily: undefined,
          color: '#CDCDCD'
        },
      },
      theme: {
        mode: "dark",
        palette: "palette5",
        monochrome: {
          enabled: false,
          color: "#255aee",
          shadeTo: "light",
          shadeIntensity: 0.65,
        },
      },
      chart: {
        type: "bar",
        height: 250,
        toolbar: {
          show: false
        }
      },
      plotOptions: {
        bar: {
          horizontal: false,
          columnWidth: "55%",
          // endingShape: "rounded"
        }
      },
      dataLabels: {
        enabled: false
      },
      stroke: {
        show: true,
        width: 2,
        colors: ["transparent"]
      },
      xaxis: {
        categories: [
          "1st Week",
          "2nd Week",
          "3rd Week",
          "4th Week",
        ]
      },
      yaxis: {
        title: {
          text: "Time(Hrs)"
        }
      },

      fill: {
        opacity: 1
      },
      tooltip: {
        y: {
          formatter: function (val) {
            return + val + " hrs";
          }
        }
      }
    };
  }
}

