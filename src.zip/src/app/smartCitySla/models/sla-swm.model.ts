// export interface Sla{
//     vertical:string,
//     subVertical:string,
//     slaValue:number,
//     penalty:number,
//     severityLevel:number,
//     totalTimeHrs:number,
//     totalDownTimeHrs:number,
//     totalMaintenanceTimeHrs:number,
//     totalUpTimeHrs:number,
//     timeSeriesData:[
//         {
//             label:string,
//             value:string
//         }
//     ]
// }