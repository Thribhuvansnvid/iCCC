import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SwmBillReportComponent } from './swm-bill-report.component';

describe('SwmBillReportComponent', () => {
  let component: SwmBillReportComponent;
  let fixture: ComponentFixture<SwmBillReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SwmBillReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SwmBillReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
