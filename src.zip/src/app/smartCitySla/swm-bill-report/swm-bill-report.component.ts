import { Component, OnInit } from '@angular/core';
// import domtoimage from 'dom-to-image';
// import * as jsPDF from 'jspdf';
import jspdf from 'jspdf';

// import * as jspdf from 'jspdf';
import html2canvas from 'html2canvas';
import { SLADataService } from '../services/sla.data.service';

@Component({
  selector: 'app-swm-bill-report',
  templateUrl: './swm-bill-report.component.html',
  styleUrls: ['./swm-bill-report.component.scss']
})
export class SwmBillReportComponent implements OnInit {
  slaData:any = null;
  penaltyAmount:number[] = []
  amountAfterPenaltyDeduction:number[] = []
  totalAmountAfterPenaltyDeduction = 0;
  totakPenaltyAmount = 0;
  constructor(private _slaDataService: SLADataService) { }

  ngOnInit() {
    this._slaDataService.passDataForPrinting.subscribe(data => {
      this.slaData = data;
      this.penaltyAmount[0] = 2500 * (this.slaData[0].penalty /100)
      this.penaltyAmount[1] = 2500 * (this.slaData[1].penalty /100)
      this.penaltyAmount[2] = 2500 * (this.slaData[2].penalty /100)
      this.penaltyAmount[3] = 2500 * (this.slaData[3].penalty /100)
      
      this.totakPenaltyAmount = this.penaltyAmount.reduce((acc, val)=> { return acc + val; }, 0)
      
      this.amountAfterPenaltyDeduction[0] = 2500 - this.penaltyAmount[0]
      this.amountAfterPenaltyDeduction[1] = 2500 - this.penaltyAmount[1]
      this.amountAfterPenaltyDeduction[2] = 2500 - this.penaltyAmount[2]
      this.amountAfterPenaltyDeduction[3] = 2500 - this.penaltyAmount[3]

      this.totalAmountAfterPenaltyDeduction = this.amountAfterPenaltyDeduction.reduce((acc, val)=> { return acc + val; }, 0)

      console.log(data)
    }, err => {
      console.log(err)
      // slaValue
    })
  }

  generatePDF() {
    var data = document.getElementById('contentToConvert');
    html2canvas(data).then(canvas => {
      var imgWidth = 208;
      var imgHeight = canvas.height * imgWidth / canvas.width;
      const contentDataURL = canvas.toDataURL('image/png')
      let pdf = new jspdf('p', 'mm', 'a4');
      var position = 0;
      pdf.addImage(contentDataURL, 'PNG', 0, position, imgWidth, imgHeight)
      pdf.save('newPDF.pdf');
    });
  }


  // downloadPDF() {

  //   var node = document.getElementById('print-page');

  //   var img;
  //   var filename;
  //   var newImage;


  //   domtoimage.toPng(node, { bgcolor: '#fff' })

  //     .then(function (dataUrl) {

  //       img = new Image();
  //       img.src = dataUrl;
  //       newImage = img.src;

  //       img.onload = function () {

  //         var pdfWidth = img.width;
  //         var pdfHeight = img.height;

  //         // FileSaver.saveAs(dataUrl, 'my-pdfimage.png'); // Save as Image

  //         var doc;

  //         if (pdfWidth > pdfHeight) {
  //           // doc = new jsPDF('l', 'px', [pdfWidth, pdfHeight]);
  //           doc = new jspdf('p', 'mm', 'a4');
  //         }
  //         else {
  //           // doc = new jsPDF('p', 'px', [pdfWidth, pdfHeight]);
  //           doc = new jspdf('p', 'mm', 'a4');
  //         }


  //         var width = doc.internal.pageSize.getWidth();
  //         var height = doc.internal.pageSize.getHeight();


  //         doc.addImage(newImage, 'PNG', 10, 10, width, height);
  //         filename = 'mypdf_' + '.pdf';
  //         doc.save(filename);

  //       };


  //     })
  //     .catch(function (error) {

  //       // Error Handling

  //     });
  // }

}
