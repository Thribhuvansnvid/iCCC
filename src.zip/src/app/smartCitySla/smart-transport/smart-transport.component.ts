// import { Chart } from "chart.js";
import * as Chart from "chart.js";
import { SmartTransportReportService } from "../services/smart_transport.service";
import { Component, OnInit, ElementRef, ViewChild, Input } from "@angular/core";
import * as jspdf from "jspdf";
import html2canvas from "html2canvas";
import ChartDataLabels from "chartjs-plugin-datalabels";
import * as moment from "moment";

@Component({
  selector: "app-smart-transport",
  templateUrl: "./smart-transport.component.html",
  styleUrls: ["./smart-transport.component.scss"],
})
export class SmartTransportComponent implements OnInit {
  // fromdate = "1592892702";
  // todate = "1592910746";

  currentDateTime = moment().format('MMM Do, YYYY HH:MM:ss');
  reportGenerateDuration = '';

  loadingVehicleData = true;
  loadingGPSData = true;
  @Input() fromdate: string = "";
  @Input() todate: string = "";

  vehiclebreakdownStats = {
    // total: 497,
    // swm: { count: 191, percentage: "38.43" },
    // bus: { count: 127, percentage: "25.55" },
    // fire_engines: { count: 6, percentage: "1.21" },
    // ambulance: { count: 173, percentage: "34.81" },
  };

  gpsFailureStats = {
    // total: 4972,
    // swm: { count: 1294, percentage: "26.03" },
    // bus: { count: 1202, percentage: "24.18" },
    // fire_engines: { count: 246, percentage: "4.95" },
    // ambulance: { count: 2230, percentage: "44.85" },
  };

  labels: string[] = [];
  dataVehicleBreakDown: number[] = [];
  dataGpsFailure: number[] = [];
  myChart1: any;
  myChart2: any;

  graphid = "";
  constructor(
    private smartTransportReportService: SmartTransportReportService,
    private elementRef: ElementRef
  ) {}


  calculateReportDuration(fromdate,todate){
    const d1 = moment(new Date(Number(fromdate) * 1000));
    const d2 = moment(new Date(Number(todate) * 1000));
    d2.diff(d1, 'days') // 1

    this.reportGenerateDuration = `${d2.diff(d1, 'days')} days From ${d1.format('MMM Do, YYYY HH:MM:ss')}`
    console.log(`from ${d1}`)
    console.log(`to ${d2}`)

    console.log(`diff ${d2.diff(d1, 'days')}`)
  }
  ngOnInit() {
    this.calculateReportDuration(this.fromdate,this.todate)
    this.labels = [
      "SWM Vehicle",
      "Transport Vehicle",
      "Fire Engines Vehicle",
      "Ambulance Vehicle",
    ];
    this.fetchChartData2(this.fromdate, this.todate);

    this.smartTransportReportService.notifyOnChange.subscribe((data) => {
      this.fromdate = data.fromDate.toString();
      this.todate = data.toDate.toString();

      this.calculateReportDuration(this.fromdate,this.todate)
      this.fetchChartData2(this.fromdate, this.todate);
    });


  }

  onSelectionSmartVertical() {
    // const fromDatetime = parseInt(String(moment(this.fromdate).valueOf()/1000))
    // const toDatetime = parseInt(String(moment(this.todate).valueOf()/1000))
    // console.log(fromDatetime)
    // console.log(toDatetime)
  }

  async fetchChartData2(fromDatetime,toDatetime) {

    this.loadingVehicleData = true;
    this.loadingGPSData = true;

    this.fetchVehicleBreakdownData(fromDatetime, toDatetime);
    this.fetchGPSFailure(fromDatetime, toDatetime);
  }

  async fetchVehicleBreakdownData(fromDatetime, toDatetime) {

    const promiseVehicleBreakdown1 = this.smartTransportReportService.getvehicleBreakDownStats(
      fromDatetime,
      toDatetime,
      1
    );
    const promiseVehicleBreakdown2 = this.smartTransportReportService.getvehicleBreakDownStats(
      fromDatetime,
      toDatetime,
      2
    );
    const promiseVehicleBreakdown3 = this.smartTransportReportService.getvehicleBreakDownStats(
      fromDatetime,
      toDatetime,
      3
    );
    const promiseVehicleBreakdown4 = this.smartTransportReportService.getvehicleBreakDownStats(
      fromDatetime,
      toDatetime,
      4
    );
    const [veh1, veh2, veh3, veh4]: any[] = await Promise.all([
      promiseVehicleBreakdown1,
      promiseVehicleBreakdown2,
      promiseVehicleBreakdown3,
      promiseVehicleBreakdown4,
    ]);
    // console.log(veh1.length,veh2.length)
    this.loadingVehicleData = false;
    this.dataVehicleBreakDown = [];
    this.dataVehicleBreakDown.push(
      veh1.length,
      veh2.length,
      veh3.length,
      veh4.length
    );
    setTimeout(() => {
      this.createLineChart1();
    }, 100);
  }

  async fetchGPSFailure(fromDatetime, toDatetime) {
    const promiseGPSFailure1 = this.smartTransportReportService.getGpsFailureStats(
      fromDatetime,
      toDatetime,
      1
    );
    const promiseGPSFailure2 = this.smartTransportReportService.getGpsFailureStats(
      fromDatetime,
      toDatetime,
      2
    );
    const promiseGPSFailure3 = this.smartTransportReportService.getGpsFailureStats(
      fromDatetime,
      toDatetime,
      3
    );
    const promiseGPSFailure4 = this.smartTransportReportService.getGpsFailureStats(
      fromDatetime,
      toDatetime,
      4
    );
    const [gps1, gps2, gps3, gps4]: any[] = await Promise.all([
      promiseGPSFailure1,
      promiseGPSFailure2,
      promiseGPSFailure3,
      promiseGPSFailure4,
    ]);
    // console.log(gps1.length,gps2.length)
    this.loadingGPSData = false;
    this.dataGpsFailure = [];
    this.dataGpsFailure.push(
      gps1.length,
      gps2.length,
      gps3.length,
      gps4.length
    );
    setTimeout(() => {
      this.createLineChart2();
    }, 100);
  }

  // fetchChartData() {
  //   const fromDatetime = parseInt(
  //     String(moment(this.fromdate).valueOf() / 1000)
  //   );
  //   const toDatetime = parseInt(String(moment(this.todate).valueOf() / 1000));
  //   // console.log(fromDatetime)
  //   // console.log(toDatetime)

  //   Promise.all([
  //     this.smartTransportReportService.getvehicleBreakDownStats(
  //       fromDatetime,
  //       toDatetime,
  //       1
  //     ),
  //     this.smartTransportReportService.getvehicleBreakDownStats(
  //       fromDatetime,
  //       toDatetime,
  //       2
  //     ),
  //     this.smartTransportReportService.getvehicleBreakDownStats(
  //       fromDatetime,
  //       toDatetime,
  //       3
  //     ),
  //     this.smartTransportReportService.getvehicleBreakDownStats(
  //       fromDatetime,
  //       toDatetime,
  //       4
  //     ),
  //   ])
  //     .then((result) => {
  //       this.loadingVehicleData = false;
  //       console.log(result);
  //       this.dataVehicleBreakDown = [];
  //       result.forEach((item: any) => {
  //         this.dataVehicleBreakDown.push(item.length);
  //       });

  //       // if(this.dataVehicleBreakDown.length){
  //       setTimeout(() => {
  //         this.createLineChart1();
  //       }, 500);
  //       // }
  //     })
  //     .catch((err) => {
  //       console.log(err);
  //     });

  //   Promise.all([
  //     this.smartTransportReportService.getGpsFailureStats(
  //       fromDatetime,
  //       toDatetime,
  //       1
  //     ),
  //     this.smartTransportReportService.getGpsFailureStats(
  //       fromDatetime,
  //       toDatetime,
  //       2
  //     ),
  //     this.smartTransportReportService.getGpsFailureStats(
  //       fromDatetime,
  //       toDatetime,
  //       3
  //     ),
  //     this.smartTransportReportService.getGpsFailureStats(
  //       fromDatetime,
  //       toDatetime,
  //       4
  //     ),
  //   ])
  //     .then((result) => {
  //       this.loadingGPSData = false;
  //       console.log(result);
  //       this.dataGpsFailure = [];
  //       result.forEach((item: any) => {
  //         this.dataGpsFailure.push(item.length);
  //       });

  //       // if(this.dataGpsFailure.length){
  //       setTimeout(() => {
  //         this.createLineChart2();
  //       }, 500);
  //       // }
  //     })
  //     .catch((err) => {
  //       console.log(err);
  //     });
  // }

  // generateReports() {
  //   const fromDatetime = parseInt(
  //     String(moment(this.fromdate).valueOf() / 1000)
  //   );
  //   const toDatetime = parseInt(String(moment(this.todate).valueOf() / 1000));
  //   console.log(`From time : ${fromDatetime}`);
  //   console.log(`To time : ${toDatetime}`);

  //   this.loadingGPSData = true;
  //   this.loadingVehicleData = true;

  //   this.fetchChartData2();
  // }

  getTotalVehiclesBrokeDown() {
    return this.dataVehicleBreakDown
      ? this.dataVehicleBreakDown.reduce((a, b) => a + b, 0)
      : 0;
  }

  getTotalGPSFailure() {
    return this.dataGpsFailure
      ? this.dataGpsFailure.reduce((a, b) => a + b, 0)
      : 0;
  }

  createLineChart1() {
    if (typeof this.myChart1 != "undefined") {
      this.myChart1.destroy();
    }

    const chartLabel = `Mode of Operation`;
    const colors = [
      "rgb(255, 99, 132)",
      "rgb(0, 255, 0)",
      "rgb(255, 99, 132)",
      "rgb(128, 255, 0)",
      "rgb(0, 255, 255)",
      "rgb(255, 255, 0)",
      "rgb(255, 255, 128)",
      "rgb(0, 150, 255)",
      "rgb(128, 255, 0)",
      "rgb(111, 255, 128)",
    ];
    const htmlRef = this.elementRef.nativeElement.querySelector(`#container1`);

    this.myChart1 = new Chart(htmlRef, {
      plugins: [ChartDataLabels],
      type: "doughnut",
      data: {
        labels: this.labels,
        datasets: [
          {
            data: this.dataVehicleBreakDown, // Specify the data values array
            backgroundColor: [
              // "#2196f38c", "#f443368c", "#3f51b570", "#00968896",
              "#01acc18c",
              "#f044358c",
              "#f7b80ae8",
              "#ff71438c",
              // // '#ff7143'
            ], // Add custom color background (Points and Fill)
            borderWidth: 0, // Specify bar border width
          },
        ],
      },
      options: {
        // segmentShowStroke: false,
        animation: {
          duration: 0,
        },
        legend: {
          position: "bottom",
        },
        elements: {
          arc: {
            borderWidth: 0,
          },
        },
        plugins: {
          datalabels: {
            formatter: (value, ctx) => {
              let sum = 0;
              let dataArr = ctx.chart.data.datasets[0].data;
              dataArr.forEach((data) => (sum += data));
              let percentage = ((value * 100) / sum).toFixed(2) + "%";
              return percentage;
            },
            display: "auto",
          },
        },
        responsive: true, // Instruct chart js to respond nicely.
        maintainAspectRatio: false, // Add to prevent default behaviour of full-width/height
      },
    });

    this.myChart1.update();
  }

  createLineChart2() {
    if (typeof this.myChart2 != "undefined") {
      this.myChart2.destroy();
    }

    const chartLabel = `Mode of Operation`;
    const colors = [
      "rgb(255, 99, 132)",
      "rgb(0, 255, 0)",
      "rgb(255, 99, 132)",
      "rgb(128, 255, 0)",
      "rgb(0, 255, 255)",
      "rgb(255, 255, 0)",
      "rgb(255, 255, 128)",
      "rgb(0, 150, 255)",
      "rgb(128, 255, 0)",
      "rgb(111, 255, 128)",
    ];
    const htmlRef = this.elementRef.nativeElement.querySelector(`#container2`);

    this.myChart2 = new Chart(htmlRef, {
      plugins: [ChartDataLabels],
      type: "doughnut",
      data: {
        labels: this.labels,
        datasets: [
          {
            data: this.dataGpsFailure, // Specify the data values array

            // borderColor: ["#2196f38c", "#f443368c", "#3f51b570", "#00968896"], // Add custom color border
            backgroundColor: [
              // "#2196f38c", "#f443368c", "#3f51b570", "#00968896",
              "#01acc18c",
              "#f044358c",
              "#f7b80ae8",
              "#ff71438c",
              // // '#ff7143'
            ], // Add custom color background (Points and Fill)
            borderWidth: 0, // Specify bar border width
          },
        ],
      },
      options: {
        // segmentShowStroke: false,
        animation: {
          duration: 0,
        },
        legend: {
          position: "bottom",
        },
        elements: {
          arc: {
            borderWidth: 0,
          },
        },
        plugins: {
          datalabels: {
            formatter: (value, ctx) => {
              let sum = 0;
              let dataArr = ctx.chart.data.datasets[0].data;
              dataArr.forEach((data) => (sum += data));
              let percentage = ((value * 100) / sum).toFixed(2) + "%";
              return percentage;
            },
            display: "auto",
          },
        },
        responsive: true, // Instruct chart js to respond nicely.
        maintainAspectRatio: false, // Add to prevent default behaviour of full-width/height
      },
    });
    this.myChart2.update();
  }
}
