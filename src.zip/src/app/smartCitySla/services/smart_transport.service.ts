import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { BehaviorSubject, Subject } from 'rxjs';

@Injectable({
  providedIn: "root",
})
export class SmartTransportReportService {

  notifyOnChange = new Subject<{fromDate:number,toDate:number}>();


  authorizationData = "Basic " + btoa("cisco:cisco#2019");
  headerOptions = {
    headers: new HttpHeaders({
      "Content-Type": "application/json",
      Authorization: this.authorizationData,
    }),
  };

  private URL1 = `http://localhost:4200/api/Transport/GetVehicleBreakdownRecentData`;
  private URL2 = `http://localhost:4200/api/Transport/GetGPSFailureRecentData`;

  constructor(private http: HttpClient) {}

  getvehicleBreakDownStats(fromdate, todate, vehicleType) {
    let promise = new Promise((resolve, reject) => {
      const endpoint = `${this.URL1}?FromDt=${fromdate}&ToDt=${todate}&VTypeId=${vehicleType}`;

      this.http
        .get(endpoint, this.headerOptions)
        .toPromise()
        .then(
          (res) => {
            resolve(res);
          },
          (msg) => {
            reject(msg);
          }
        );
    });
    return promise;
  }

  // getAllVehicleBreakDownStats(fromDatetime, toDatetime, vehicleType){
  //   Promise.all([
  //     this.getvehicleBreakDownStats(
  //       fromDatetime,
  //       toDatetime,
  //       1
  //     ),
  //     this.getvehicleBreakDownStats(
  //       fromDatetime,
  //       toDatetime,
  //       2
  //     ),
  //     this.getvehicleBreakDownStats(
  //       fromDatetime,
  //       toDatetime,
  //       3
  //     ),
  //     this.getvehicleBreakDownStats(
  //       fromDatetime,
  //       toDatetime,
  //       4
  //     ),
  //   ])
  //     .then((result) => {
  //       result.forEach((item: any,index) => {
  //         this.dataVehicleBreakDown.push(item.length);
  //       });

  //     })
  //     .catch((err) => {
  //       console.log(err);
  //     });
  // }

  getGpsFailureStats(fromdate, todate, vehicleType) {
    let promise = new Promise((resolve, reject) => {
      const endpoint = `${this.URL2}?FromDt=${fromdate}&ToDt=${todate}&VTypeId=${vehicleType}`;

      this.http
        .get(endpoint, this.headerOptions)
        .toPromise()
        .then(
          (res) => {
            resolve(res);
          },
          (msg) => {
            reject(msg);
          }
        );
    });
    return promise;
  }


}
