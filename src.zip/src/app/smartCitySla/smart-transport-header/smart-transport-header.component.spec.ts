import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SmartTransportHeaderComponent } from './smart-transport-header.component';

describe('SmartTransportHeaderComponent', () => {
  let component: SmartTransportHeaderComponent;
  let fixture: ComponentFixture<SmartTransportHeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SmartTransportHeaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SmartTransportHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
