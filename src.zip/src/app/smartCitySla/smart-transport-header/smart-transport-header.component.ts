import { Component, OnInit } from "@angular/core";
import * as jspdf from "jspdf";
import html2canvas from "html2canvas";
import { SmartTransportReportService } from "../services/smart_transport.service";
import * as moment from "moment";

interface Food {
  value: string;
  viewValue: string;
}

@Component({
  selector: "app-smart-transport-header",
  templateUrl: "./smart-transport-header.component.html",
  styleUrls: ["./smart-transport-header.component.scss"],
})
export class SmartTransportHeaderComponent implements OnInit {
  fromdate = new Date(new Date().getTime() - 2 * 24 * 60 * 60 * 1000);
  todate = new Date();

  foods: Food[] = [
    {value: 'steak-0', viewValue: 'Steak'},
    {value: 'pizza-1', viewValue: 'Pizza'},
    {value: 'tacos-2', viewValue: 'Tacos'}
  ];
  
  numberFromdate = parseInt(String(moment(this.fromdate).valueOf() / 1000));
  numberTodate = parseInt(String(moment(this.todate).valueOf() / 1000));

  
  smartVerticalSelected = "Smart Transport";

  smartVerticalsList = [
    "Smart Transport",
    "Smart Water",
    "Smart Energy",
    "Smart Env",
  ];

  constructor(
    private smartTransportReportService: SmartTransportReportService
  ) {}

  ngOnInit() {
    console.log(`numberFromdate : ${this.numberFromdate} numberTodate : ${this.numberTodate}`)
  }

  generateReports() {
    const fromDate = parseInt(String(moment(this.fromdate).valueOf() / 1000));
    const toDate = parseInt(String(moment(this.todate).valueOf() / 1000));
    this.smartTransportReportService.notifyOnChange.next({ fromDate, toDate });
  }

  onSelectionSmartVertical() {
  }

  public exportToPDF() {
    var data = document.getElementById("smart-transport-container");
    html2canvas(data).then((canvas) => {
      // Few necessary setting options
      var imgWidth = 208;
      var pageHeight = 295;
      var imgHeight = (canvas.height * imgWidth) / canvas.width;
      var heightLeft = imgHeight;

      const contentDataURL = canvas.toDataURL("image/png");
      let pdf = new jspdf.jsPDF("p", "mm", "a4"); // A4 size page of PDF
      var position = 0;
      pdf.addImage(contentDataURL, "PNG", 0, position, imgWidth, imgHeight);
      pdf.save("MYPdf.pdf"); // Generated PDF
    });
  }
}
