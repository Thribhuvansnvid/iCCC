import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sla-dashboard',
  templateUrl: './sla-dashboard.component.html',
  styleUrls: ['./sla-dashboard.component.css']
})
export class SlaDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
