import { Component, Input, OnInit, ViewChild } from '@angular/core';

// import {
//   ApexNonAxisChartSeries,
//   ApexPlotOptions,
//   ApexChart,
//   ChartComponent
// } from "ng-apexcharts";

// export type ChartOptions = {
//   series: ApexNonAxisChartSeries;
//   chart: ApexChart;
//   labels: string[];
//   plotOptions: ApexPlotOptions;
// };

import {
  ApexNonAxisChartSeries,
  ApexPlotOptions,
  ApexChart,
  ApexFill,
  ChartComponent,
  ApexStroke,
  ApexGrid,
  ApexTheme
} from "ng-apexcharts";

export type ChartOptions = {
  series: ApexNonAxisChartSeries;
  chart: ApexChart;
  labels: string[];
  plotOptions: ApexPlotOptions;
  fill: ApexFill;
  stroke: ApexStroke;
  grid: ApexGrid;
  theme: ApexTheme;
};

@Component({
  selector: 'sla-swm-card-component',
  templateUrl: './sla-card-component.component.html',
  styleUrls: ['./sla-card-component.component.scss']
})
export class SlaCardComponentComponent implements OnInit {

  @Input() slaData: any;

  @ViewChild("chart", { static: true }) chart: ChartComponent;
  public chartOptions: Partial<ChartOptions>;

  constructor() {

  }

  // @ViewChild("chart",{static: true}) chart: ChartComponent;
  // public chartOptions: Partial<ChartOptions>;

  // constructor() {
  //   this.chartOptions = {
  //     series: [67],
  //     chart: {
  //       height: 200,
  //       type: "radialBar",
  //       offsetY: -10
  //     },
  //     plotOptions: {
  //       radialBar: {
  //         startAngle: -135,
  //         endAngle: 135,
  //         dataLabels: {
  //           name: {
  //             fontSize: "16px",
  //             color: undefined,
  //             offsetY: 120
  //           },
  //           value: {
  //             offsetY: 76,
  //             fontSize: "22px",
  //             color: undefined,
  //             formatter: function(val) {
  //               return val + "%";
  //             }
  //           }
  //         }
  //       }
  //     },
  //     fill: {
  //       type: "gradient",
  //       gradient: {
  //         shade: "dark",
  //         shadeIntensity: 0.15,
  //         inverseColors: false,
  //         opacityFrom: 1,
  //         opacityTo: 1,
  //         stops: [0, 50, 65, 91]
  //       }
  //     },
  //     stroke: {
  //       dashArray: 4
  //     },
  //     labels: ["Median Ratio"]
  //   };
  // }

  ngOnInit() {
    this.initializeChartData()
  }

  getSeverityColor(severity) {
    let className = ''
    let color = ''
    switch (severity) {
      case 1:
        className = "severity-level-1"
        color = '#47D447'
        break;
      case 2:
        className = "severity-level-2"
        color = '#47D447'
        break;
      case 3:
        className = "severity-level-3"
        color = '#3CC8C8'
        break;
      case 4:
        className = "severity-level-4"
        color = '#3CC8C8'
        break;
      case 5:
        className = "severity-level-5"
        color = '#FFFF00'
        break;
      case 6:
        className = "severity-level-6"
        color = '#FFFF00'
        break;
      case 7:
        className = "severity-level-7"
        color = '#EE6161'
        break;
      case 8:
        className = "severity-level-8"
        color = '#EE6161'
        break;
      case 9:
        className = "severity-level-9"
        color = '#EE6161'
        break;

      default:
        break;
    }
    return color;
  }

  initializeChartData() {
    const severityColor = this.getSeverityColor(this.slaData.severityLevel);
    // this.chartOptions = {
    //   series: [this.slaData.slaValue],
    //   theme: {
    //     mode: "dark",
    //     palette: "palette5",
    //     monochrome: {
    //       enabled: false,
    //       color: '#3CC8C8',
    //       shadeTo: "light",
    //       shadeIntensity: 0.65,
    //     },
    //   },
    //   chart: {
    //     height: 150,
    //     type: "radialBar"
    //   },
    //   grid: {
    //     // borderColor: '#EE6161',
    //     padding: {
    //       top: 0,
    //       right: 0,
    //       bottom: 0,
    //       left: 0,
    //     },
    //   },
    //   plotOptions: {
    //     radialBar: {
    //       hollow: {
    //         size: "60%"
    //       }
    //     }
    //   },
    //   // labels: [this.slaData.subVertical]
    //   labels: ["SLA"]
    // };

    this.chartOptions = {
      chart: {
        height: 200,
        type: "radialBar"
      },
      
      series: [this.slaData.slaValue],
      
      plotOptions: {
        radialBar: {
          // track: {
          //   background: '#1cbd00'
          // },
          // color:'#1cbd00',
          // fill: "#1cbd00",
          hollow: {
            margin: 15,
            background: 'transparent',
            size: "65%"
          },
         
          dataLabels: {
            // showOn: "always",
            name: {
              offsetY: -10,
              show: false,
              color: "#888",
              fontSize: "13px"
            },
            value: {
              color: "#fff",
              fontSize: "22px",
              show: true
            }
          }
        }
      },
    
      stroke: {
        lineCap: "round",
      },
      labels: ["SLA"]
    };
  }

}
