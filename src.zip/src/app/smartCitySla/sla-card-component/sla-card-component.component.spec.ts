import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SlaCardComponentComponent } from './sla-card-component.component';

describe('SlaCardComponentComponent', () => {
  let component: SlaCardComponentComponent;
  let fixture: ComponentFixture<SlaCardComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SlaCardComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SlaCardComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
