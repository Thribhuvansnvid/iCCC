import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SmartTransportComponent } from './smart-transport/smart-transport.component';
import { SmartTransportHeaderComponent } from './smart-transport-header/smart-transport-header.component';
import { SwmSlaComponent } from './swm-sla/swm-sla.component';
import { SlaDashboardComponent } from './sla-dashboard/sla-dashboard.component';
import { SwmBillReportComponent } from './swm-bill-report/swm-bill-report.component';

const pagesRoutes: Routes = [
  { path: 'dashboard', component: SlaDashboardComponent },
  { path: 'swm', component: SwmSlaComponent },
  { path: 'swm/report', component: SwmBillReportComponent },
];

@NgModule({
  imports: [
    RouterModule.forChild(pagesRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class SmartCitySlaRoutes { }