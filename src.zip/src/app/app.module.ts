import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
// import { CoreModule } from "./core/core.module";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { LazyLoadModule } from './lazy-load/lazy-load.module';
import { SmartTransportModule } from './SmartTransportRreports/smartTransportReport.module';
import { SmartTransportServerSideReportComponent } from './serverSideReports/smart-transport-server-side-report/smart-transport-server-side-report.component';

@NgModule({
  declarations: [
    AppComponent,
    SmartTransportServerSideReportComponent,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    BrowserAnimationsModule,
    LazyLoadModule,
    SmartTransportModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
