import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { SmartTransportRoutes } from './smartTransportReport.routes';
import { SmartTransportComponent } from './smart-transport/smart-transport.component';
import { DoughnutChartComponent } from './doughnut-chart/doughnut-chart.component';
import { MaterialModule } from '../shared/material.module';
import { SmartTransportHeaderComponent } from './smart-transport-header/smart-transport-header.component';

@NgModule({
  imports: [CommonModule, FormsModule, ReactiveFormsModule, HttpClientModule,SmartTransportRoutes, MaterialModule],
  declarations: [SmartTransportComponent, DoughnutChartComponent, SmartTransportHeaderComponent],

  providers: [],
  entryComponents: [],
  exports:[SmartTransportComponent]
})
export class SmartTransportModule {}
