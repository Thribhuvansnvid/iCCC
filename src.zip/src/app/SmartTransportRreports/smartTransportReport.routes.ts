import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SmartTransportComponent } from './smart-transport/smart-transport.component';
import { SmartTransportHeaderComponent } from './smart-transport-header/smart-transport-header.component';

const pagesRoutes: Routes = [

  // { path: '', component:  SmartTransportComponent },
  {
    path: '', 
    component: SmartTransportHeaderComponent,
    children: [
      { path: 'sla', loadChildren: '../smartCitySla/smartCitySla.module#SmartCitySlaModule' },
      // {
      //   path: 'sla', loadChildren: () =>
      //     import(`../smartCitySla/smartCitySla.module`).then(
      //       (m) => m.SmartCitySlaModule
      //     ),
      // }
    ]
  },


];

@NgModule({
  imports: [
    RouterModule.forChild(pagesRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class SmartTransportRoutes { }