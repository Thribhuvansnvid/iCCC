import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { map, tap, take } from "rxjs/operators";

@Component({
  selector: "app-smart-transport-server-side-report",
  templateUrl: "./smart-transport-server-side-report.component.html",
  styleUrls: ["./smart-transport-server-side-report.component.css"],
})
export class SmartTransportServerSideReportComponent implements OnInit {
  fromDate = "";
  toDate = "";
  constructor(private activatedRoute: ActivatedRoute) {}

  ngOnInit() {
    this.activatedRoute.params.pipe(take(1)).subscribe((params) => {
      //Params from routes
      this.fromDate = params["fromDate"];
      this.toDate = params["toDate"];

      console.log(`From : ${this.fromDate} To : ${this.toDate}`);
    });
  }
}
