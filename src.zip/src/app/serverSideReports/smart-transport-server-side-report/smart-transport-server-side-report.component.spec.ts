import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SmartTransportServerSideReportComponent } from './smart-transport-server-side-report.component';

describe('SmartTransportServerSideReportComponent', () => {
  let component: SmartTransportServerSideReportComponent;
  let fixture: ComponentFixture<SmartTransportServerSideReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SmartTransportServerSideReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SmartTransportServerSideReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
